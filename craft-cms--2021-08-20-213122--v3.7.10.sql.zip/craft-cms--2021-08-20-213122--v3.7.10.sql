--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS fk_zvynuobptdmklsesnpixggbolodvnkuqgvut;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_zqqeoerktxwqmsjuaatpooqoefbyknscjaaf;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_zotjryttfurumkbpkztsxjsvnerofxnxyujx;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_zmvnnomsrnoettgcgcidszpjslyvvjtcdhrs;
ALTER TABLE IF EXISTS ONLY public.widgets DROP CONSTRAINT IF EXISTS fk_zmmqyeabxgvybmfcrcdhaarefagxmlfouhnj;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS fk_zaefdgalobzpbsmmbjzysolznozbtayoevsg;
ALTER TABLE IF EXISTS ONLY public.userpreferences DROP CONSTRAINT IF EXISTS fk_yvkiysdtrpvpxkgibcxlafydeappyponaxkz;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS fk_yvbhlotpisehkijlewmisogugfqkbagooooi;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS fk_yurtmdkdpzsxmrfnsewpfoqvevmrrfucjyby;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS fk_ypltwezcmgpftiaucxucgwduhonidsbfpddt;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS fk_ygvywmvffkcptcuyjubzwsbbrvwqzglravjy;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_yetyuoopmmtpogsgsopvhpynmprvglgjdcns;
ALTER TABLE IF EXISTS ONLY public.assetindexdata DROP CONSTRAINT IF EXISTS fk_yadqfkcdthefjducjecxxknixwxagdvdqmuz;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS fk_xuekehbkpnykgsylpklrhgpobsjeghxlripr;
ALTER TABLE IF EXISTS ONLY public.templatecaches DROP CONSTRAINT IF EXISTS fk_xfetygmslslakvhthfwvyhnycdpkskqopogk;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS fk_xatrztzvcsjhjiwgiojkeqywzhrotxeijody;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_whodbooinwmvqcegyryqhssncurxmndljafe;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_whnvgusapbazwmetxsbzuusbvnckqjiwijjx;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_whklxdrrduxsufxpotuabyssnlmiohozdcsh;
ALTER TABLE IF EXISTS ONLY public.fieldlayouttabs DROP CONSTRAINT IF EXISTS fk_vihzqihjzqguuzicqsrugfixmhghuojxwfmg;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS fk_vgmhbqsuhfcoucvxojvdhnhozazeasdbjter;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS fk_urbngthzeficfsichcfrxidjcewvnmwhhvdm;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS fk_unfrhsspkbbsngfghhmaajrekexiozxlxbss;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS fk_umlfohxobvrqetcbiimtagbcnfhgdfugkhgs;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_uldjwarpoccvkhhynbzwjnzudetualfjiakp;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_tramutmeimtjhtvokwfitjdlchnjfsuamops;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS fk_tcnurdcjhddlewwhqewitguptqtgkhnnvtxd;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_svwysmmpuvvugselvlkudekgkerplhntdhpw;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_stksspvxpvtooinomkyhkvmoygjynlakruhr;
ALTER TABLE IF EXISTS ONLY public.shunnedmessages DROP CONSTRAINT IF EXISTS fk_srfgiddvjymfbflxftbpgepmzjhsvkefwjrw;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS fk_skpmedomozgqqizdjspcbldhqbiodqfieugp;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_sargbrtjmttpatxcahawzpyfbjnclzyucyjd;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_rxwsgrrabqauobtniihhfdtvhokpeopieczb;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_rgzsifmejgakkmwhqnljdgsltjnayvbyfxnp;
ALTER TABLE IF EXISTS ONLY public.taggroups DROP CONSTRAINT IF EXISTS fk_rfbvlyvomaomvcrkunqrlujnutydirvfkexw;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS fk_quleicrlgcrlsppiwiwmnnjujchundmjdzds;
ALTER TABLE IF EXISTS ONLY public.sections DROP CONSTRAINT IF EXISTS fk_qjnmqaoysnsclstuelzmnfqgjllftubspnqh;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS fk_qaufqqbzvcihylotynbhaklkkxcvqgxcexeb;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS fk_pwslbpmqxenyjfumtcyygpohjrgzltnzvgsv;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS fk_pmcnfhddlfacarmsefpsmmqtnmbjrfahwyoq;
ALTER TABLE IF EXISTS ONLY public.templatecachequeries DROP CONSTRAINT IF EXISTS fk_pbyhvxitbspbjzopgznzkineutulhhqrwrlg;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_paboxjelhgvqweoyxdozedjapmtccjiiidge;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_ozzvxvqatugjglpimzlafgflpakcgashswjn;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_okiwlyljoydzqfiopxvngyeqjbxghcacxcrk;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_nxjvvnrctnaddmmjbhlvrjcbjzzsrvrrmkek;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS fk_nvdotwjasidwkjpaectcqnpkuuuselhwcyqa;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS fk_njwqhymentkgvlkbbhzaionwizykpnlbepiq;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS fk_nidumidsiewxyyvfeffxiysufknpidxmyaiy;
ALTER TABLE IF EXISTS ONLY public.volumes DROP CONSTRAINT IF EXISTS fk_ngkwaoeabestgpagxvtoyrlhpvlbkqncljca;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS fk_mvgvnxgvxxwgblfwrwauyvzoicmiodtgmrak;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS fk_mjmihenbuiplvjnjbkkjbnehsfoowgdbmrix;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS fk_mbrpcdjyixpjaclqtacfxgapapganijfvihb;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_lykkzcggrzxkebcubncsghvidodtnfihoers;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS fk_luuuohfvmninboviwxbaxigfsjphnehtktdg;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS fk_lmwtlwlesouzqwxduvqdpnnsuhhmpntflejd;
ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS fk_kyxvjybqatiboxovylyccwwdgtpadjffbnxa;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_juqebdmscimmiogexdqfqrlfjjnewabokejn;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fk_jpcmtvjjpkdrafzehyygtdpgdwmbfxvedoni;
ALTER TABLE IF EXISTS ONLY public.fields DROP CONSTRAINT IF EXISTS fk_irykroikqevghkdfgurvfznkuunkauoqckak;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS fk_ijljjnfztrnlsxttpvmzxobhgpbimsmltqjh;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS fk_ihffzyarvylcdxjqtztsbocxiiocuptndpit;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_ihfcnwawoqjzaijqgztewgqwywaoyalwpifd;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS fk_ihddupgmwdnrjcbqoonifablkinnxzklxgyw;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS fk_hsorrkdacyfdyxqjniiotqotqvzgwumppkxy;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS fk_hsgednwmaycmgfsrievnpdihpfsevebebfjp;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_gevyffdvstntnbrzspcmajwxsckosufgwdog;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS fk_ftlmhdvefpjntamiwgikkmmkddkwonxoxccw;
ALTER TABLE IF EXISTS ONLY public.craftidtokens DROP CONSTRAINT IF EXISTS fk_fnujdicqutvwpcgbjxgcgwswcyldckwbfdnq;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_ffyxmtwbhynjfinrmhtzpipgywipdrnjkzsi;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS fk_ejdhpplhwrbcesjmymdioewfedmgmvobxccj;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS fk_eauzwwyfbiufjgihuvesygiggiglkyudypnp;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_eakuvzxchuuizmcnrsexgmizzvmbrueunaii;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_dvjplsnmokhjwrsdnuzgwesirubuhrcqnpxq;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS fk_dtpqozepdpwgwmhnhjqvflmvcybugcajmhpz;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS fk_drvumycnkerapzddxgecojmxzmbwgdzvpykn;
ALTER TABLE IF EXISTS ONLY public.gqltokens DROP CONSTRAINT IF EXISTS fk_dinqaqcuwxnxqgkxrvisnogmczgwnjmssfbh;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS fk_dckbwthohmaoegcgukalfcoihqmlpfkusmgg;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS fk_cklazsukyavnwlommqgjwvopeweiqrtoxxrt;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_cjmymlkzyrgymygzxobesfrsvrkamgaelhqr;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS fk_ciuscxxowyxxrlmegebzlpgbgxmilwvoaghz;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS fk_bqpwrdpiyxkczswqmdozzobppbplxlzhkcis;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS fk_bmgvjpjtnlquiaoelnjkvnbudenuqkikvkgw;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS fk_aupfoqlwgvqamhpurhvdcsjxankhocowumeu;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS fk_aqmxuaqdnpqimrscvsxvmcbyizuuczhxudzt;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS fk_akouzaohvrzqpqgrvfcpnicypybtjfqmogho;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS fk_agbiywalnzxvrrkcwgkmvjzsmzhurjpzzgfu;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS fk_acxaxfxcjexqtjjlqjmioqezznvewzuqlpie;
DROP INDEX IF EXISTS public.idx_zqadmxtwxlzrwahqgkclwxvqrqhantxwqvax;
DROP INDEX IF EXISTS public.idx_yyhkcpjhwonhkpvdoicpygicnyxtexhfrnmp;
DROP INDEX IF EXISTS public.idx_ywxwhdyrmyknlblslokhyldhcyzlwrmarmle;
DROP INDEX IF EXISTS public.idx_ytlnjnojfzjkmtvdnuurowellxetzkqjlexv;
DROP INDEX IF EXISTS public.idx_yqntepvveambublqrksqpqxsmvxilrmdfqjp;
DROP INDEX IF EXISTS public.idx_ykakevfyobvrgycbdqwgiewgrhjztxjnjzyh;
DROP INDEX IF EXISTS public.idx_ydxoopluvdoyyofdqiszzwbezpxdhlgmvqzq;
DROP INDEX IF EXISTS public.idx_yamkpkbxdtrncvnohpuzgxmtxrdbqurpjmfx;
DROP INDEX IF EXISTS public.idx_xzbrulybudlpgsfqszwtfumwrgdugqsjecjy;
DROP INDEX IF EXISTS public.idx_xyqscjfqyyuafajwbvwjiwgfmrcunvysgucp;
DROP INDEX IF EXISTS public.idx_xyjyprzroemfoyllvmvdqoiijbxthdtvltmc;
DROP INDEX IF EXISTS public.idx_xtdqlpnfavznmiauairmgjftpyejngdduijm;
DROP INDEX IF EXISTS public.idx_xstwolkzpxbdqrmxuuziwraiisgzhzjaqgyg;
DROP INDEX IF EXISTS public.idx_xrprccotimoblwfwyemhmqktqvhzlmpfjjnl;
DROP INDEX IF EXISTS public.idx_xojqpuoqcrjedlduenaryioxvskpyobrecex;
DROP INDEX IF EXISTS public.idx_xndzbzwfzdxiyhlqvjottadaomwwpyzxhkig;
DROP INDEX IF EXISTS public.idx_xlgfbqwqrlitolfzlmnwsrpeowinbelfgncb;
DROP INDEX IF EXISTS public.idx_xirzomftbpjhfecnslsiilfvstfswgareoej;
DROP INDEX IF EXISTS public.idx_xbbcahcgpxyxgffjohojujdqsuaqugbbarse;
DROP INDEX IF EXISTS public.idx_wzwphqhrgmzviidjrvxiicpunilbcriifgdz;
DROP INDEX IF EXISTS public.idx_wyvykvdlpwbhmndaqruxutgiccmhwwjigjip;
DROP INDEX IF EXISTS public.idx_wudtahqpnhfqwmileunxdehzirnvmddioopt;
DROP INDEX IF EXISTS public.idx_wmrraimoymibwruhjxzxbdignrkzjhrxgfuc;
DROP INDEX IF EXISTS public.idx_wcmmgawmjvoghklvtjhbtjdjamvltbiehsbz;
DROP INDEX IF EXISTS public.idx_vtcodandmiqvisbtexbnxlzfszblrjnzdzjz;
DROP INDEX IF EXISTS public.idx_vrosdkggvoasnufkijbmtyhckvmaxdjqzqyg;
DROP INDEX IF EXISTS public.idx_voehxymzaotizojzoxxoeogziilbuaardzel;
DROP INDEX IF EXISTS public.idx_vbuwbemncjgzwneyvcpinzbbupddtmrnswfc;
DROP INDEX IF EXISTS public.idx_vbsjppxjimssvrwkdkyraviysvehjuqbhldn;
DROP INDEX IF EXISTS public.idx_uzfzfdxdnknkfpdbkrjniegkiurxqqhvovsd;
DROP INDEX IF EXISTS public.idx_uzfbpowhilgcjgzjcvxccpjgaoavduvwvrzd;
DROP INDEX IF EXISTS public.idx_uybmgtwrbyatnvtgvowjryztxdlctovyahww;
DROP INDEX IF EXISTS public.idx_uxyzzjwkukollazkicvfiwdrdyjbuvrlpofl;
DROP INDEX IF EXISTS public.idx_uurgsjjvlgtinhxkcmaxuihocicvisbxsosb;
DROP INDEX IF EXISTS public.idx_uunffbawrcvtfnkzbxgtherwvahsedcwsekx;
DROP INDEX IF EXISTS public.idx_usapvhlmwzsjnuljgtbbkkeolmaiwjihhkie;
DROP INDEX IF EXISTS public.idx_uomuhedyanuuhiqdgiubgoquhphkmriajbzu;
DROP INDEX IF EXISTS public.idx_unxmctilqwkanjqvnkvfxfhvezuzxkajqjet;
DROP INDEX IF EXISTS public.idx_umyprmiqvnrisycyxrhaqbnjmivqzcycwaqi;
DROP INDEX IF EXISTS public.idx_umfvhfcvvdakxmyyonedvgdkafgmootdreid;
DROP INDEX IF EXISTS public.idx_ujmplkrqaoimshrqftfubdmgzrfgnkfajrze;
DROP INDEX IF EXISTS public.idx_udzevqhgwykahmuprgvnvozxiryrcjzyoooo;
DROP INDEX IF EXISTS public.idx_trmweyzlkmdhghfeuqxflxbaulymbdljeres;
DROP INDEX IF EXISTS public.idx_tpeotmnlszktiwwsxzdmajfbedhwyxgqjdpe;
DROP INDEX IF EXISTS public.idx_toimpgoukwavcugxvcdiazcnptrxffbxjyol;
DROP INDEX IF EXISTS public.idx_tiqggukgcnjxzevjlxzrboibspvadjotdunf;
DROP INDEX IF EXISTS public.idx_tgedkofguqefchmrmoenfgntgoiloyrayfnv;
DROP INDEX IF EXISTS public.idx_tdvmjlnduphebhwtioypjxtnjbuefpdtnvci;
DROP INDEX IF EXISTS public.idx_tdteebduzzmipyztytpgygmvkjjembmeqkun;
DROP INDEX IF EXISTS public.idx_ssqttaiaqauuzuluuiypotrmgrwrnilrpvbu;
DROP INDEX IF EXISTS public.idx_snhjebtbjdxcwjdmcpwwhjndzehwrcuxfbjy;
DROP INDEX IF EXISTS public.idx_slilohfkahojaryfutwvgpjnbwyroetdteoz;
DROP INDEX IF EXISTS public.idx_shzasyftbadjwevyzubqwcucqspvlhxhvedp;
DROP INDEX IF EXISTS public.idx_sfwwrptoytyrkleqfjsaoqeaurbwwfzcwdiy;
DROP INDEX IF EXISTS public.idx_rzkbyuadbiqnnakdxvikszqasfvudosbiekq;
DROP INDEX IF EXISTS public.idx_rwvbnrkbbhqfjvwcmirpiktavsyewpqfbezq;
DROP INDEX IF EXISTS public.idx_rnmxmoweswyjbrfzcosdtinoviekrhllobem;
DROP INDEX IF EXISTS public.idx_qmfjtqnyritieinfbvdabzawjjsmbekltqtl;
DROP INDEX IF EXISTS public.idx_qilybbcmbtlytzsimlaparxxpjbazknkmtgl;
DROP INDEX IF EXISTS public.idx_qglmrbaxvrxfelgjegtdtctvjvdjiubrweum;
DROP INDEX IF EXISTS public.idx_pzktsgnluceskzrmmrrpkrnisqsdhggxlgiu;
DROP INDEX IF EXISTS public.idx_pxvqncndpcudahepdsckbbqitlxvlyhrumtg;
DROP INDEX IF EXISTS public.idx_pxqanwqpaumhrfdrsszklgjowutzzxxybwdl;
DROP INDEX IF EXISTS public.idx_pbdogcfzlxuqatdceszvaozccnmimkatggjv;
DROP INDEX IF EXISTS public.idx_oncgvprxnjsqtlukxkjjmjtyxjgbzegbbege;
DROP INDEX IF EXISTS public.idx_okfhoqsdmexbfdjpnyienhcvldmyiugcwufj;
DROP INDEX IF EXISTS public.idx_ohohitqsplgrvvnxqpmkeqkanlerzyqmdmep;
DROP INDEX IF EXISTS public.idx_nzcxxrleidrbykmmmxyojitmlnyvdmllkjrm;
DROP INDEX IF EXISTS public.idx_nqtmkmjvwdqysreaomxkvpaudzgxppjscwne;
DROP INDEX IF EXISTS public.idx_miotdqnyerlmzbkohhkgpmbqjswqyvkhidmf;
DROP INDEX IF EXISTS public.idx_mdivjpshfexnoeccshvgldndoykxfpgoecsg;
DROP INDEX IF EXISTS public.idx_maoprfwuymediebrdhioqccaymuvzawiplox;
DROP INDEX IF EXISTS public.idx_lzntkktxhpwswdmzirbeuqwsprhdadeubghf;
DROP INDEX IF EXISTS public.idx_lxbytxaestgbfbcojjaznrpxapqhljzpclel;
DROP INDEX IF EXISTS public.idx_lwrtfcfjmrydetkqovvfwmqhacdxlsamddpr;
DROP INDEX IF EXISTS public.idx_lsyavkwssdqrpqkfkeaiwamwfglzraxronss;
DROP INDEX IF EXISTS public.idx_lrugquecjunehwusyvlxcbxqhkywjfjtndci;
DROP INDEX IF EXISTS public.idx_lqdeemjdcuwiwkewncruodjmgjoqnloajpyj;
DROP INDEX IF EXISTS public.idx_lpnvqxlggxekkmezrlgovqtcdnhfbgkfrdkv;
DROP INDEX IF EXISTS public.idx_lotdhyddwyzytyoewptqccirqorirjcyqvaq;
DROP INDEX IF EXISTS public.idx_loqmakpvlmxearwzghrikpddlsznbejkksxw;
DROP INDEX IF EXISTS public.idx_lofyskigbqyvvcmyayazgjdmxrphfgwdgxho;
DROP INDEX IF EXISTS public.idx_lnrlzrorxplvgupqdtijxeqbgqwthlwbjehw;
DROP INDEX IF EXISTS public.idx_leftdauzswnaslnqzqjnbisvvjiaxdhzhjvm;
DROP INDEX IF EXISTS public.idx_kzsomffzftnkfhrvxfwvkijcokvpmluexili;
DROP INDEX IF EXISTS public.idx_khqnhvcekhvxbgfkbmloecczpefnteddaaow;
DROP INDEX IF EXISTS public.idx_keggstrqeypbtgxbfrlluezlzulnwsktjsaa;
DROP INDEX IF EXISTS public.idx_kafzrgxeubythshkzoogqjhrgfgaqkzywffa;
DROP INDEX IF EXISTS public.idx_jvgskrxchxcdylmfhphvhgvcjwfeqwrsnntt;
DROP INDEX IF EXISTS public.idx_juofosqfrphwpyxpkcqmstyfdtgtemqnfglg;
DROP INDEX IF EXISTS public.idx_jslhgluglumqcgpzjmrhlmicclxdzytuqrzq;
DROP INDEX IF EXISTS public.idx_jmndaqjlrackpaffmveupyixazddblsouboi;
DROP INDEX IF EXISTS public.idx_jjvqpzrdwweuafviksqyzhilcafqzcozxxtv;
DROP INDEX IF EXISTS public.idx_izqnxarobohqobjomrjrgapzfxaguqjmhqvc;
DROP INDEX IF EXISTS public.idx_iyxkhtltfiwivktvcnyqyjcnphhixkweumnn;
DROP INDEX IF EXISTS public.idx_itafxogxqvlpdcoajunkpnwsjkcoyymalnqd;
DROP INDEX IF EXISTS public.idx_irqivmyljtefuzynayjiyafhwbydkyroqtcw;
DROP INDEX IF EXISTS public.idx_ildmakbmhffylczmmbfqshzhkeevqlinjajc;
DROP INDEX IF EXISTS public.idx_iavnelshsolycbtrulyfhrkdzhyjsefuzihj;
DROP INDEX IF EXISTS public.idx_hzgrdlxqdavyqbeaubbcjcnequazfaxpbkfx;
DROP INDEX IF EXISTS public.idx_hyjxifwjvaltokjyvmmqdqrtxaoxlhrrmvai;
DROP INDEX IF EXISTS public.idx_hxkpxdeqfrbtfhosejlvtafinuupldouapsy;
DROP INDEX IF EXISTS public.idx_hpotqclhzulbggtbfyuhuympvaqpzwxxjnym;
DROP INDEX IF EXISTS public.idx_hnheotxfcgcynncwmzasysxpswddmdfjtuak;
DROP INDEX IF EXISTS public.idx_hhzxoosmzbejagvvxwferwkvheggtiiniomx;
DROP INDEX IF EXISTS public.idx_gxzbwqglkssessfjavhzzgbagcfnmzfurdlr;
DROP INDEX IF EXISTS public.idx_gxxqyutgiaogncdltigjljfgeggokantouwt;
DROP INDEX IF EXISTS public.idx_gttipdcrtsjghsqzttqwlfmrslifkyodkhcv;
DROP INDEX IF EXISTS public.idx_goslsuiqkfsjnvbriqgqnwaqaquuemkpdzar;
DROP INDEX IF EXISTS public.idx_ftnmhvczjzvxaeicixrgkdhbixfxrqsxwucg;
DROP INDEX IF EXISTS public.idx_fswwkqqgeqvrxzvehjvpymckvqxpelwyhwsp;
DROP INDEX IF EXISTS public.idx_fljjfgrmvyoksdoycrsynnvfiwsrxxxsnssy;
DROP INDEX IF EXISTS public.idx_famqwxurogmmuzutasbjqdpqigmeogcsiqhm;
DROP INDEX IF EXISTS public.idx_eyjwvzelugchhebebztjrspfajrlzvsatyxa;
DROP INDEX IF EXISTS public.idx_ewssijividkftrhvzhgpxabvvzqtrduiifgm;
DROP INDEX IF EXISTS public.idx_etzqogdcxcgwexqtovvpddlewsgdzrbfubal;
DROP INDEX IF EXISTS public.idx_ernuvwxtjockcblchpldamyoezhvebxdhexl;
DROP INDEX IF EXISTS public.idx_eqevvxgnaujkrelegkvfqkowmrqxzligvazz;
DROP INDEX IF EXISTS public.idx_emskzfriytrpbuwjnqgkiylvrxyivxzezses;
DROP INDEX IF EXISTS public.idx_emehdrkrjfnpnbhfqjtnrpnejiupusgrughm;
DROP INDEX IF EXISTS public.idx_eftdqlzgyzrncrmysmjhtuoakvpmfspobzrw;
DROP INDEX IF EXISTS public.idx_dzobedqmaiqxonovdbhdfcqpqqocvgicxtwy;
DROP INDEX IF EXISTS public.idx_dxrmcskbxdrukmymvfiqjweibkdrwyycmxwm;
DROP INDEX IF EXISTS public.idx_dofsxexcjyftcfbbhaqhrjjkcxhzrfoqkfvg;
DROP INDEX IF EXISTS public.idx_dodysouwkehovsgwogrkqubfxowplbkhzemg;
DROP INDEX IF EXISTS public.idx_dfxqwtxflpxvqcspbsqyybcwlzgttihkqrks;
DROP INDEX IF EXISTS public.idx_cxskooujykspcnmsrqvvflbsiugptdowrrlo;
DROP INDEX IF EXISTS public.idx_cswvaoeejrerveigvixzizamflydergbsrir;
DROP INDEX IF EXISTS public.idx_cirxtreveaiwltftmnmmmkmwdkimxkltiffx;
DROP INDEX IF EXISTS public.idx_cinjooiyxumvediajklxcvdexmhkxwjpvyln;
DROP INDEX IF EXISTS public.idx_cancftkzagegenrhfuvzykegddclibsrbgsa;
DROP INDEX IF EXISTS public.idx_bzitmtiiulwyzpnlbjtsawmsmqajazvoeiap;
DROP INDEX IF EXISTS public.idx_bzdxlbzgeyfwbzmbzhqlbbciocufunjxjmmr;
DROP INDEX IF EXISTS public.idx_blatprmfwfxmjttxovdaeculjuwebqvdhkmv;
DROP INDEX IF EXISTS public.idx_bgpahqqmldplfufvwvimoyevcoylfwhbirlz;
DROP INDEX IF EXISTS public.idx_befklnaefkalmdtsavcshikdvtyertsizbcv;
DROP INDEX IF EXISTS public.idx_awwxzokovltwkfqubtsuyluekrljkhvrllms;
DROP INDEX IF EXISTS public.idx_atjljoezaomqserpqalvxlnisetdheagpzfp;
DROP INDEX IF EXISTS public.idx_asqkfmiraftlpsuktgwtorreraunpffhhemo;
DROP INDEX IF EXISTS public.idx_aqrbvrnfllfbztqttkxiaqujzbvctuynyggk;
DROP INDEX IF EXISTS public.idx_agaimwknvpnmrktuootvfdaelzqvjsdouipr;
DROP INDEX IF EXISTS public.idx_afadosesuwygibqhejkctatpdftlmjojqdnn;
DROP INDEX IF EXISTS public.idx_aemmowovqjhuspotfthsighrclpmwfmyhhfj;
DROP INDEX IF EXISTS public.idx_acfekksukhczdowfiyfncngnjihgcmbfqcpc;
DROP INDEX IF EXISTS public.idx_aaazqdilqjcyrpypaifjjsqopmzebxmaecua;
ALTER TABLE IF EXISTS ONLY public.widgets DROP CONSTRAINT IF EXISTS widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.volumes DROP CONSTRAINT IF EXISTS volumes_pkey;
ALTER TABLE IF EXISTS ONLY public.volumefolders DROP CONSTRAINT IF EXISTS volumefolders_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.userpreferences DROP CONSTRAINT IF EXISTS userpreferences_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions_users DROP CONSTRAINT IF EXISTS userpermissions_users_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions_usergroups DROP CONSTRAINT IF EXISTS userpermissions_usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.userpermissions DROP CONSTRAINT IF EXISTS userpermissions_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroups_users DROP CONSTRAINT IF EXISTS usergroups_users_pkey;
ALTER TABLE IF EXISTS ONLY public.usergroups DROP CONSTRAINT IF EXISTS usergroups_pkey;
ALTER TABLE IF EXISTS ONLY public.tokens DROP CONSTRAINT IF EXISTS tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecaches DROP CONSTRAINT IF EXISTS templatecaches_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecachequeries DROP CONSTRAINT IF EXISTS templatecachequeries_pkey;
ALTER TABLE IF EXISTS ONLY public.templatecacheelements DROP CONSTRAINT IF EXISTS templatecacheelements_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.taggroups DROP CONSTRAINT IF EXISTS taggroups_pkey;
ALTER TABLE IF EXISTS ONLY public.systemmessages DROP CONSTRAINT IF EXISTS systemmessages_pkey;
ALTER TABLE IF EXISTS ONLY public.structures DROP CONSTRAINT IF EXISTS structures_pkey;
ALTER TABLE IF EXISTS ONLY public.structureelements DROP CONSTRAINT IF EXISTS structureelements_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sitegroups DROP CONSTRAINT IF EXISTS sitegroups_pkey;
ALTER TABLE IF EXISTS ONLY public.shunnedmessages DROP CONSTRAINT IF EXISTS shunnedmessages_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sequences DROP CONSTRAINT IF EXISTS sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.sections_sites DROP CONSTRAINT IF EXISTS sections_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.sections DROP CONSTRAINT IF EXISTS sections_pkey;
ALTER TABLE IF EXISTS ONLY public.revisions DROP CONSTRAINT IF EXISTS revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.resourcepaths DROP CONSTRAINT IF EXISTS resourcepaths_pkey;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS relations_pkey;
ALTER TABLE IF EXISTS ONLY public.queue DROP CONSTRAINT IF EXISTS queue_pkey;
ALTER TABLE IF EXISTS ONLY public.projectconfig DROP CONSTRAINT IF EXISTS projectconfig_pkey;
ALTER TABLE IF EXISTS ONLY public.plugins DROP CONSTRAINT IF EXISTS plugins_pkey;
ALTER TABLE IF EXISTS ONLY public.searchindex DROP CONSTRAINT IF EXISTS pk_ibqfaejfbtcyyyfuhikpcmevxmibaxwetohk;
ALTER TABLE IF EXISTS ONLY public.migrations DROP CONSTRAINT IF EXISTS migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.matrixblocktypes DROP CONSTRAINT IF EXISTS matrixblocktypes_pkey;
ALTER TABLE IF EXISTS ONLY public.matrixblocks DROP CONSTRAINT IF EXISTS matrixblocks_pkey;
ALTER TABLE IF EXISTS ONLY public.info DROP CONSTRAINT IF EXISTS info_pkey;
ALTER TABLE IF EXISTS ONLY public.gqltokens DROP CONSTRAINT IF EXISTS gqltokens_pkey;
ALTER TABLE IF EXISTS ONLY public.gqlschemas DROP CONSTRAINT IF EXISTS gqlschemas_pkey;
ALTER TABLE IF EXISTS ONLY public.globalsets DROP CONSTRAINT IF EXISTS globalsets_pkey;
ALTER TABLE IF EXISTS ONLY public.gatsby_deletedelements DROP CONSTRAINT IF EXISTS gatsby_deletedelements_pkey;
ALTER TABLE IF EXISTS ONLY public.fields DROP CONSTRAINT IF EXISTS fields_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayouttabs DROP CONSTRAINT IF EXISTS fieldlayouttabs_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayouts DROP CONSTRAINT IF EXISTS fieldlayouts_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldlayoutfields DROP CONSTRAINT IF EXISTS fieldlayoutfields_pkey;
ALTER TABLE IF EXISTS ONLY public.fieldgroups DROP CONSTRAINT IF EXISTS fieldgroups_pkey;
ALTER TABLE IF EXISTS ONLY public.entrytypes DROP CONSTRAINT IF EXISTS entrytypes_pkey;
ALTER TABLE IF EXISTS ONLY public.entries DROP CONSTRAINT IF EXISTS entries_pkey;
ALTER TABLE IF EXISTS ONLY public.elements_sites DROP CONSTRAINT IF EXISTS elements_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.elements DROP CONSTRAINT IF EXISTS elements_pkey;
ALTER TABLE IF EXISTS ONLY public.elementindexsettings DROP CONSTRAINT IF EXISTS elementindexsettings_pkey;
ALTER TABLE IF EXISTS ONLY public.drafts DROP CONSTRAINT IF EXISTS drafts_pkey;
ALTER TABLE IF EXISTS ONLY public.deprecationerrors DROP CONSTRAINT IF EXISTS deprecationerrors_pkey;
ALTER TABLE IF EXISTS ONLY public.craftidtokens DROP CONSTRAINT IF EXISTS craftidtokens_pkey;
ALTER TABLE IF EXISTS ONLY public.content DROP CONSTRAINT IF EXISTS content_pkey;
ALTER TABLE IF EXISTS ONLY public.changedfields DROP CONSTRAINT IF EXISTS changedfields_pkey;
ALTER TABLE IF EXISTS ONLY public.changedattributes DROP CONSTRAINT IF EXISTS changedattributes_pkey;
ALTER TABLE IF EXISTS ONLY public.categorygroups_sites DROP CONSTRAINT IF EXISTS categorygroups_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.categorygroups DROP CONSTRAINT IF EXISTS categorygroups_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.assettransforms DROP CONSTRAINT IF EXISTS assettransforms_pkey;
ALTER TABLE IF EXISTS ONLY public.assettransformindex DROP CONSTRAINT IF EXISTS assettransformindex_pkey;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS assets_pkey;
ALTER TABLE IF EXISTS ONLY public.assetindexdata DROP CONSTRAINT IF EXISTS assetindexdata_pkey;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS announcements_pkey;
ALTER TABLE IF EXISTS public.widgets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.volumes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.volumefolders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpreferences ALTER COLUMN "userId" DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions_usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.userpermissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.usergroups_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.usergroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecaches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecachequeries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.templatecacheelements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.taggroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.systemmessages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.structures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.structureelements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sitegroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.shunnedmessages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sections_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.revisions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.relations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.queue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plugins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.matrixblocktypes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.info ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gqltokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gqlschemas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.globalsets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gatsby_deletedelements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayouttabs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayouts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldlayoutfields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fieldgroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.entrytypes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.elementindexsettings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.drafts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deprecationerrors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.craftidtokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.content ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categorygroups_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categorygroups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assettransforms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assettransformindex ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assetindexdata ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.announcements ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.widgets_id_seq;
DROP TABLE IF EXISTS public.widgets;
DROP SEQUENCE IF EXISTS public.volumes_id_seq;
DROP TABLE IF EXISTS public.volumes;
DROP SEQUENCE IF EXISTS public.volumefolders_id_seq;
DROP TABLE IF EXISTS public.volumefolders;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public."userpreferences_userId_seq";
DROP TABLE IF EXISTS public.userpreferences;
DROP SEQUENCE IF EXISTS public.userpermissions_users_id_seq;
DROP TABLE IF EXISTS public.userpermissions_users;
DROP SEQUENCE IF EXISTS public.userpermissions_usergroups_id_seq;
DROP TABLE IF EXISTS public.userpermissions_usergroups;
DROP SEQUENCE IF EXISTS public.userpermissions_id_seq;
DROP TABLE IF EXISTS public.userpermissions;
DROP SEQUENCE IF EXISTS public.usergroups_users_id_seq;
DROP TABLE IF EXISTS public.usergroups_users;
DROP SEQUENCE IF EXISTS public.usergroups_id_seq;
DROP TABLE IF EXISTS public.usergroups;
DROP SEQUENCE IF EXISTS public.tokens_id_seq;
DROP TABLE IF EXISTS public.tokens;
DROP SEQUENCE IF EXISTS public.templatecaches_id_seq;
DROP TABLE IF EXISTS public.templatecaches;
DROP SEQUENCE IF EXISTS public.templatecachequeries_id_seq;
DROP TABLE IF EXISTS public.templatecachequeries;
DROP SEQUENCE IF EXISTS public.templatecacheelements_id_seq;
DROP TABLE IF EXISTS public.templatecacheelements;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.taggroups_id_seq;
DROP TABLE IF EXISTS public.taggroups;
DROP SEQUENCE IF EXISTS public.systemmessages_id_seq;
DROP TABLE IF EXISTS public.systemmessages;
DROP SEQUENCE IF EXISTS public.structures_id_seq;
DROP TABLE IF EXISTS public.structures;
DROP SEQUENCE IF EXISTS public.structureelements_id_seq;
DROP TABLE IF EXISTS public.structureelements;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP SEQUENCE IF EXISTS public.sitegroups_id_seq;
DROP TABLE IF EXISTS public.sitegroups;
DROP SEQUENCE IF EXISTS public.shunnedmessages_id_seq;
DROP TABLE IF EXISTS public.shunnedmessages;
DROP SEQUENCE IF EXISTS public.sessions_id_seq;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.sequences;
DROP SEQUENCE IF EXISTS public.sections_sites_id_seq;
DROP TABLE IF EXISTS public.sections_sites;
DROP SEQUENCE IF EXISTS public.sections_id_seq;
DROP TABLE IF EXISTS public.sections;
DROP TABLE IF EXISTS public.searchindex;
DROP SEQUENCE IF EXISTS public.revisions_id_seq;
DROP TABLE IF EXISTS public.revisions;
DROP TABLE IF EXISTS public.resourcepaths;
DROP SEQUENCE IF EXISTS public.relations_id_seq;
DROP TABLE IF EXISTS public.relations;
DROP SEQUENCE IF EXISTS public.queue_id_seq;
DROP TABLE IF EXISTS public.queue;
DROP TABLE IF EXISTS public.projectconfig;
DROP SEQUENCE IF EXISTS public.plugins_id_seq;
DROP TABLE IF EXISTS public.plugins;
DROP SEQUENCE IF EXISTS public.migrations_id_seq;
DROP TABLE IF EXISTS public.migrations;
DROP SEQUENCE IF EXISTS public.matrixblocktypes_id_seq;
DROP TABLE IF EXISTS public.matrixblocktypes;
DROP TABLE IF EXISTS public.matrixblocks;
DROP SEQUENCE IF EXISTS public.info_id_seq;
DROP TABLE IF EXISTS public.info;
DROP SEQUENCE IF EXISTS public.gqltokens_id_seq;
DROP TABLE IF EXISTS public.gqltokens;
DROP SEQUENCE IF EXISTS public.gqlschemas_id_seq;
DROP TABLE IF EXISTS public.gqlschemas;
DROP SEQUENCE IF EXISTS public.globalsets_id_seq;
DROP TABLE IF EXISTS public.globalsets;
DROP SEQUENCE IF EXISTS public.gatsby_deletedelements_id_seq;
DROP TABLE IF EXISTS public.gatsby_deletedelements;
DROP SEQUENCE IF EXISTS public.fields_id_seq;
DROP TABLE IF EXISTS public.fields;
DROP SEQUENCE IF EXISTS public.fieldlayouttabs_id_seq;
DROP TABLE IF EXISTS public.fieldlayouttabs;
DROP SEQUENCE IF EXISTS public.fieldlayouts_id_seq;
DROP TABLE IF EXISTS public.fieldlayouts;
DROP SEQUENCE IF EXISTS public.fieldlayoutfields_id_seq;
DROP TABLE IF EXISTS public.fieldlayoutfields;
DROP SEQUENCE IF EXISTS public.fieldgroups_id_seq;
DROP TABLE IF EXISTS public.fieldgroups;
DROP SEQUENCE IF EXISTS public.entrytypes_id_seq;
DROP TABLE IF EXISTS public.entrytypes;
DROP TABLE IF EXISTS public.entries;
DROP SEQUENCE IF EXISTS public.elements_sites_id_seq;
DROP TABLE IF EXISTS public.elements_sites;
DROP SEQUENCE IF EXISTS public.elements_id_seq;
DROP TABLE IF EXISTS public.elements;
DROP SEQUENCE IF EXISTS public.elementindexsettings_id_seq;
DROP TABLE IF EXISTS public.elementindexsettings;
DROP SEQUENCE IF EXISTS public.drafts_id_seq;
DROP TABLE IF EXISTS public.drafts;
DROP SEQUENCE IF EXISTS public.deprecationerrors_id_seq;
DROP TABLE IF EXISTS public.deprecationerrors;
DROP SEQUENCE IF EXISTS public.craftidtokens_id_seq;
DROP TABLE IF EXISTS public.craftidtokens;
DROP SEQUENCE IF EXISTS public.content_id_seq;
DROP TABLE IF EXISTS public.content;
DROP TABLE IF EXISTS public.changedfields;
DROP TABLE IF EXISTS public.changedattributes;
DROP SEQUENCE IF EXISTS public.categorygroups_sites_id_seq;
DROP TABLE IF EXISTS public.categorygroups_sites;
DROP SEQUENCE IF EXISTS public.categorygroups_id_seq;
DROP TABLE IF EXISTS public.categorygroups;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.assettransforms_id_seq;
DROP TABLE IF EXISTS public.assettransforms;
DROP SEQUENCE IF EXISTS public.assettransformindex_id_seq;
DROP TABLE IF EXISTS public.assettransformindex;
DROP TABLE IF EXISTS public.assets;
DROP SEQUENCE IF EXISTS public.assetindexdata_id_seq;
DROP TABLE IF EXISTS public.assetindexdata;
DROP SEQUENCE IF EXISTS public.announcements_id_seq;
DROP TABLE IF EXISTS public.announcements;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "pluginId" integer,
    heading character varying(255) NOT NULL,
    body text NOT NULL,
    unread boolean DEFAULT true NOT NULL,
    "dateRead" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: assetindexdata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assetindexdata (
    id integer NOT NULL,
    "sessionId" character varying(36) DEFAULT ''::character varying NOT NULL,
    "volumeId" integer NOT NULL,
    uri text,
    size bigint,
    "timestamp" timestamp(0) without time zone,
    "recordId" integer,
    "inProgress" boolean DEFAULT false,
    completed boolean DEFAULT false,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assetindexdata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assetindexdata_id_seq OWNED BY public.assetindexdata.id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    "volumeId" integer,
    "folderId" integer NOT NULL,
    "uploaderId" integer,
    filename character varying(255) NOT NULL,
    kind character varying(50) DEFAULT 'unknown'::character varying NOT NULL,
    width integer,
    height integer,
    size bigint,
    "focalPoint" character varying(13) DEFAULT NULL::character varying,
    "deletedWithVolume" boolean,
    "keptFile" boolean,
    "dateModified" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assettransformindex; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assettransformindex (
    id integer NOT NULL,
    "assetId" integer NOT NULL,
    filename character varying(255),
    format character varying(255),
    location character varying(255) NOT NULL,
    "volumeId" integer,
    "fileExists" boolean DEFAULT false NOT NULL,
    "inProgress" boolean DEFAULT false NOT NULL,
    error boolean DEFAULT false NOT NULL,
    "dateIndexed" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assettransformindex_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assettransformindex_id_seq OWNED BY public.assettransformindex.id;


--
-- Name: assettransforms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assettransforms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    mode character varying(255) DEFAULT 'crop'::character varying NOT NULL,
    "position" character varying(255) DEFAULT 'center-center'::character varying NOT NULL,
    width integer,
    height integer,
    format character varying(255),
    quality integer,
    interlace character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "dimensionChangeTime" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT assettransforms_interlace_check CHECK (((interlace)::text = ANY ((ARRAY['none'::character varying, 'line'::character varying, 'plane'::character varying, 'partition'::character varying])::text[]))),
    CONSTRAINT assettransforms_mode_check CHECK (((mode)::text = ANY ((ARRAY['stretch'::character varying, 'fit'::character varying, 'crop'::character varying])::text[]))),
    CONSTRAINT assettransforms_position_check CHECK ((("position")::text = ANY ((ARRAY['top-left'::character varying, 'top-center'::character varying, 'top-right'::character varying, 'center-left'::character varying, 'center-center'::character varying, 'center-right'::character varying, 'bottom-left'::character varying, 'bottom-center'::character varying, 'bottom-right'::character varying])::text[])))
);


--
-- Name: assettransforms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assettransforms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assettransforms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assettransforms_id_seq OWNED BY public.assettransforms.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "parentId" integer,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: categorygroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorygroups (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "defaultPlacement" character varying(255) DEFAULT 'end'::character varying NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "categorygroups_defaultPlacement_check" CHECK ((("defaultPlacement")::text = ANY ((ARRAY['beginning'::character varying, 'end'::character varying])::text[])))
);


--
-- Name: categorygroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categorygroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categorygroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categorygroups_id_seq OWNED BY public.categorygroups.id;


--
-- Name: categorygroups_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categorygroups_sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categorygroups_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categorygroups_sites_id_seq OWNED BY public.categorygroups_sites.id;


--
-- Name: changedattributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changedattributes (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    attribute character varying(255) NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


--
-- Name: changedfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changedfields (
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    propagated boolean NOT NULL,
    "userId" integer
);


--
-- Name: content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    title character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    "field_siteDescription_pzqpdxwe" text,
    "field_mainMenu_cygqxalw" text
);


--
-- Name: content_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_id_seq OWNED BY public.content.id;


--
-- Name: craftidtokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.craftidtokens (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "accessToken" text NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.craftidtokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.craftidtokens_id_seq OWNED BY public.craftidtokens.id;


--
-- Name: deprecationerrors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deprecationerrors (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    "lastOccurrence" timestamp(0) without time zone NOT NULL,
    file character varying(255) NOT NULL,
    line smallint,
    message text,
    traces text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deprecationerrors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deprecationerrors_id_seq OWNED BY public.deprecationerrors.id;


--
-- Name: drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drafts (
    id integer NOT NULL,
    "sourceId" integer,
    "creatorId" integer,
    provisional boolean DEFAULT false NOT NULL,
    name character varying(255) NOT NULL,
    notes text,
    "trackChanges" boolean DEFAULT false NOT NULL,
    "dateLastMerged" timestamp(0) without time zone,
    saved boolean DEFAULT true NOT NULL
);


--
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drafts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drafts_id_seq OWNED BY public.drafts.id;


--
-- Name: elementindexsettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elementindexsettings (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    settings text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elementindexsettings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elementindexsettings_id_seq OWNED BY public.elementindexsettings.id;


--
-- Name: elements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements (
    id integer NOT NULL,
    "canonicalId" integer,
    "draftId" integer,
    "revisionId" integer,
    "fieldLayoutId" integer,
    type character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateLastMerged" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_id_seq OWNED BY public.elements.id;


--
-- Name: elements_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.elements_sites (
    id integer NOT NULL,
    "elementId" integer NOT NULL,
    "siteId" integer NOT NULL,
    slug character varying(255),
    uri character varying(255),
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: elements_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.elements_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: elements_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.elements_sites_id_seq OWNED BY public.elements_sites.id;


--
-- Name: entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "parentId" integer,
    "typeId" integer NOT NULL,
    "authorId" integer,
    "postDate" timestamp(0) without time zone,
    "expiryDate" timestamp(0) without time zone,
    "deletedWithEntryType" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: entrytypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entrytypes (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "hasTitleField" boolean DEFAULT true NOT NULL,
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    "titleFormat" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: entrytypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.entrytypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entrytypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.entrytypes_id_seq OWNED BY public.entrytypes.id;


--
-- Name: fieldgroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldgroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldgroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldgroups_id_seq OWNED BY public.fieldgroups.id;


--
-- Name: fieldlayoutfields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayoutfields (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    "tabId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    required boolean DEFAULT false NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayoutfields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayoutfields_id_seq OWNED BY public.fieldlayoutfields.id;


--
-- Name: fieldlayouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayouts (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayouts_id_seq OWNED BY public.fieldlayouts.id;


--
-- Name: fieldlayouttabs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fieldlayouttabs (
    id integer NOT NULL,
    "layoutId" integer NOT NULL,
    name character varying(255) NOT NULL,
    elements text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fieldlayouttabs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fieldlayouttabs_id_seq OWNED BY public.fieldlayouttabs.id;


--
-- Name: fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fields (
    id integer NOT NULL,
    "groupId" integer,
    name character varying(255) NOT NULL,
    handle character varying(64) NOT NULL,
    context character varying(255) DEFAULT 'global'::character varying NOT NULL,
    "columnSuffix" character(8),
    instructions text,
    searchable boolean DEFAULT true NOT NULL,
    "translationMethod" character varying(255) DEFAULT 'none'::character varying NOT NULL,
    "translationKeyFormat" text,
    type character varying(255) NOT NULL,
    settings text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fields_id_seq OWNED BY public.fields.id;


--
-- Name: gatsby_deletedelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gatsby_deletedelements (
    id integer NOT NULL,
    "elementId" integer,
    "siteId" integer NOT NULL,
    "typeName" character varying(255) NOT NULL,
    "dateDeleted" timestamp(0) without time zone NOT NULL
);


--
-- Name: gatsby_deletedelements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gatsby_deletedelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gatsby_deletedelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gatsby_deletedelements_id_seq OWNED BY public.gatsby_deletedelements.id;


--
-- Name: globalsets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.globalsets (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: globalsets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.globalsets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: globalsets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.globalsets_id_seq OWNED BY public.globalsets.id;


--
-- Name: gqlschemas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gqlschemas (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    scope text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gqlschemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gqlschemas_id_seq OWNED BY public.gqlschemas.id;


--
-- Name: gqltokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gqltokens (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "accessToken" character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "lastUsed" timestamp(0) without time zone,
    "schemaId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: gqltokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gqltokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gqltokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gqltokens_id_seq OWNED BY public.gqltokens.id;


--
-- Name: info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.info (
    id integer NOT NULL,
    version character varying(50) NOT NULL,
    "schemaVersion" character varying(15) NOT NULL,
    maintenance boolean DEFAULT false NOT NULL,
    "configVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "fieldVersion" character(12) DEFAULT '000000000000'::bpchar NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: info_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.info_id_seq OWNED BY public.info.id;


--
-- Name: matrixblocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matrixblocks (
    id integer NOT NULL,
    "ownerId" integer NOT NULL,
    "fieldId" integer NOT NULL,
    "typeId" integer NOT NULL,
    "sortOrder" smallint,
    "deletedWithOwner" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: matrixblocktypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matrixblocktypes (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matrixblocktypes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matrixblocktypes_id_seq OWNED BY public.matrixblocktypes.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    track character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "applyTime" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    id integer NOT NULL,
    handle character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    "schemaVersion" character varying(255) NOT NULL,
    "licenseKeyStatus" character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    "licensedEdition" character varying(255),
    "installDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "plugins_licenseKeyStatus_check" CHECK ((("licenseKeyStatus")::text = ANY ((ARRAY['valid'::character varying, 'trial'::character varying, 'invalid'::character varying, 'mismatched'::character varying, 'astray'::character varying, 'unknown'::character varying])::text[])))
);


--
-- Name: plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plugins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plugins_id_seq OWNED BY public.plugins.id;


--
-- Name: projectconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projectconfig (
    path character varying(255) NOT NULL,
    value text NOT NULL
);


--
-- Name: queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queue (
    id integer NOT NULL,
    channel character varying(255) DEFAULT 'queue'::character varying NOT NULL,
    job bytea NOT NULL,
    description text,
    "timePushed" integer NOT NULL,
    ttr integer NOT NULL,
    delay integer DEFAULT 0 NOT NULL,
    priority integer DEFAULT 1024 NOT NULL,
    "dateReserved" timestamp(0) without time zone,
    "timeUpdated" integer,
    progress smallint DEFAULT 0 NOT NULL,
    "progressLabel" character varying(255),
    attempt integer,
    fail boolean DEFAULT false,
    "dateFailed" timestamp(0) without time zone,
    error text
);


--
-- Name: queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queue_id_seq OWNED BY public.queue.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relations (
    id integer NOT NULL,
    "fieldId" integer NOT NULL,
    "sourceId" integer NOT NULL,
    "sourceSiteId" integer,
    "targetId" integer NOT NULL,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: resourcepaths; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resourcepaths (
    hash character varying(255) NOT NULL,
    path character varying(255) NOT NULL
);


--
-- Name: revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.revisions (
    id integer NOT NULL,
    "sourceId" integer NOT NULL,
    "creatorId" integer,
    num integer NOT NULL,
    notes text
);


--
-- Name: revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.revisions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: revisions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.revisions_id_seq OWNED BY public.revisions.id;


--
-- Name: searchindex; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.searchindex (
    "elementId" integer NOT NULL,
    attribute character varying(25) NOT NULL,
    "fieldId" integer NOT NULL,
    "siteId" integer NOT NULL,
    keywords text NOT NULL,
    keywords_vector tsvector NOT NULL
);


--
-- Name: sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections (
    id integer NOT NULL,
    "structureId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    type character varying(255) DEFAULT 'channel'::character varying NOT NULL,
    "enableVersioning" boolean DEFAULT false NOT NULL,
    "propagationMethod" character varying(255) DEFAULT 'all'::character varying NOT NULL,
    "defaultPlacement" character varying(255) DEFAULT 'end'::character varying NOT NULL,
    "previewTargets" text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL,
    CONSTRAINT "sections_defaultPlacement_check" CHECK ((("defaultPlacement")::text = ANY ((ARRAY['beginning'::character varying, 'end'::character varying])::text[]))),
    CONSTRAINT sections_type_check CHECK (((type)::text = ANY ((ARRAY['single'::character varying, 'channel'::character varying, 'structure'::character varying])::text[])))
);


--
-- Name: sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sections_id_seq OWNED BY public.sections.id;


--
-- Name: sections_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sections_sites (
    id integer NOT NULL,
    "sectionId" integer NOT NULL,
    "siteId" integer NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    "uriFormat" text,
    template character varying(500),
    "enabledByDefault" boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sections_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sections_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sections_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sections_sites_id_seq OWNED BY public.sections_sites.id;


--
-- Name: sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sequences (
    name character varying(255) NOT NULL,
    next integer DEFAULT 1 NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token character(100) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: shunnedmessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shunnedmessages (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    message character varying(255) NOT NULL,
    "expiryDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shunnedmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shunnedmessages_id_seq OWNED BY public.shunnedmessages.id;


--
-- Name: sitegroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sitegroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sitegroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sitegroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sitegroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sitegroups_id_seq OWNED BY public.sitegroups.id;


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "primary" boolean NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    language character varying(12) NOT NULL,
    "hasUrls" boolean DEFAULT false NOT NULL,
    "baseUrl" character varying(255),
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: structureelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structureelements (
    id integer NOT NULL,
    "structureId" integer NOT NULL,
    "elementId" integer,
    root integer,
    lft integer NOT NULL,
    rgt integer NOT NULL,
    level smallint NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: structureelements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.structureelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: structureelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.structureelements_id_seq OWNED BY public.structureelements.id;


--
-- Name: structures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.structures (
    id integer NOT NULL,
    "maxLevels" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: structures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.structures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.structures_id_seq OWNED BY public.structures.id;


--
-- Name: systemmessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.systemmessages (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    key character varying(255) NOT NULL,
    subject text NOT NULL,
    body text NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: systemmessages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.systemmessages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: systemmessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.systemmessages_id_seq OWNED BY public.systemmessages.id;


--
-- Name: taggroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    "fieldLayoutId" integer,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: taggroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.taggroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taggroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.taggroups_id_seq OWNED BY public.taggroups.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "deletedWithGroup" boolean,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: templatecacheelements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecacheelements (
    id integer NOT NULL,
    "cacheId" integer NOT NULL,
    "elementId" integer NOT NULL
);


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecacheelements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecacheelements_id_seq OWNED BY public.templatecacheelements.id;


--
-- Name: templatecachequeries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecachequeries (
    id integer NOT NULL,
    "cacheId" integer NOT NULL,
    type character varying(255) NOT NULL,
    query text NOT NULL
);


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecachequeries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecachequeries_id_seq OWNED BY public.templatecachequeries.id;


--
-- Name: templatecaches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.templatecaches (
    id integer NOT NULL,
    "siteId" integer NOT NULL,
    "cacheKey" character varying(255) NOT NULL,
    path character varying(255),
    "expiryDate" timestamp(0) without time zone NOT NULL,
    body text NOT NULL
);


--
-- Name: templatecaches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.templatecaches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templatecaches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.templatecaches_id_seq OWNED BY public.templatecaches.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id integer NOT NULL,
    token character(32) NOT NULL,
    route text,
    "usageLimit" smallint,
    "usageCount" smallint,
    "expiryDate" timestamp(0) without time zone NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    description text,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usergroups_id_seq OWNED BY public.usergroups.id;


--
-- Name: usergroups_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usergroups_users (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.usergroups_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.usergroups_users_id_seq OWNED BY public.usergroups_users.id;


--
-- Name: userpermissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_id_seq OWNED BY public.userpermissions.id;


--
-- Name: userpermissions_usergroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions_usergroups (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "groupId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_usergroups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_usergroups_id_seq OWNED BY public.userpermissions_usergroups.id;


--
-- Name: userpermissions_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpermissions_users (
    id integer NOT NULL,
    "permissionId" integer NOT NULL,
    "userId" integer NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.userpermissions_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.userpermissions_users_id_seq OWNED BY public.userpermissions_users.id;


--
-- Name: userpreferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.userpreferences (
    "userId" integer NOT NULL,
    preferences text
);


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."userpreferences_userId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."userpreferences_userId_seq" OWNED BY public.userpreferences."userId";


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    "photoId" integer,
    "firstName" character varying(100),
    "lastName" character varying(100),
    email character varying(255) NOT NULL,
    password character varying(255),
    admin boolean DEFAULT false NOT NULL,
    locked boolean DEFAULT false NOT NULL,
    suspended boolean DEFAULT false NOT NULL,
    pending boolean DEFAULT false NOT NULL,
    "lastLoginDate" timestamp(0) without time zone,
    "lastLoginAttemptIp" character varying(45),
    "invalidLoginWindowStart" timestamp(0) without time zone,
    "invalidLoginCount" smallint,
    "lastInvalidLoginDate" timestamp(0) without time zone,
    "lockoutDate" timestamp(0) without time zone,
    "hasDashboard" boolean DEFAULT false NOT NULL,
    "verificationCode" character varying(255),
    "verificationCodeIssuedDate" timestamp(0) without time zone,
    "unverifiedEmail" character varying(255),
    "passwordResetRequired" boolean DEFAULT false NOT NULL,
    "lastPasswordChangeDate" timestamp(0) without time zone,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumefolders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volumefolders (
    id integer NOT NULL,
    "parentId" integer,
    "volumeId" integer,
    name character varying(255) NOT NULL,
    path character varying(255),
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumefolders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.volumefolders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: volumefolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.volumefolders_id_seq OWNED BY public.volumefolders.id;


--
-- Name: volumes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volumes (
    id integer NOT NULL,
    "fieldLayoutId" integer,
    name character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    "hasUrls" boolean DEFAULT true NOT NULL,
    url character varying(255),
    "titleTranslationMethod" character varying(255) DEFAULT 'site'::character varying NOT NULL,
    "titleTranslationKeyFormat" text,
    settings text,
    "sortOrder" smallint,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    "dateDeleted" timestamp(0) without time zone DEFAULT NULL::timestamp without time zone,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: volumes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.volumes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: volumes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.volumes_id_seq OWNED BY public.volumes.id;


--
-- Name: widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.widgets (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    type character varying(255) NOT NULL,
    "sortOrder" smallint,
    colspan smallint,
    settings text,
    enabled boolean DEFAULT true NOT NULL,
    "dateCreated" timestamp(0) without time zone NOT NULL,
    "dateUpdated" timestamp(0) without time zone NOT NULL,
    uid character(36) DEFAULT '0'::bpchar NOT NULL
);


--
-- Name: widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.widgets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.widgets_id_seq OWNED BY public.widgets.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: assetindexdata id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata ALTER COLUMN id SET DEFAULT nextval('public.assetindexdata_id_seq'::regclass);


--
-- Name: assettransformindex id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransformindex ALTER COLUMN id SET DEFAULT nextval('public.assettransformindex_id_seq'::regclass);


--
-- Name: assettransforms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransforms ALTER COLUMN id SET DEFAULT nextval('public.assettransforms_id_seq'::regclass);


--
-- Name: categorygroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_id_seq'::regclass);


--
-- Name: categorygroups_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites ALTER COLUMN id SET DEFAULT nextval('public.categorygroups_sites_id_seq'::regclass);


--
-- Name: content id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content ALTER COLUMN id SET DEFAULT nextval('public.content_id_seq'::regclass);


--
-- Name: craftidtokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens ALTER COLUMN id SET DEFAULT nextval('public.craftidtokens_id_seq'::regclass);


--
-- Name: deprecationerrors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deprecationerrors ALTER COLUMN id SET DEFAULT nextval('public.deprecationerrors_id_seq'::regclass);


--
-- Name: drafts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts ALTER COLUMN id SET DEFAULT nextval('public.drafts_id_seq'::regclass);


--
-- Name: elementindexsettings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elementindexsettings ALTER COLUMN id SET DEFAULT nextval('public.elementindexsettings_id_seq'::regclass);


--
-- Name: elements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements ALTER COLUMN id SET DEFAULT nextval('public.elements_id_seq'::regclass);


--
-- Name: elements_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites ALTER COLUMN id SET DEFAULT nextval('public.elements_sites_id_seq'::regclass);


--
-- Name: entrytypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes ALTER COLUMN id SET DEFAULT nextval('public.entrytypes_id_seq'::regclass);


--
-- Name: fieldgroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldgroups ALTER COLUMN id SET DEFAULT nextval('public.fieldgroups_id_seq'::regclass);


--
-- Name: fieldlayoutfields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields ALTER COLUMN id SET DEFAULT nextval('public.fieldlayoutfields_id_seq'::regclass);


--
-- Name: fieldlayouts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouts ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouts_id_seq'::regclass);


--
-- Name: fieldlayouttabs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs ALTER COLUMN id SET DEFAULT nextval('public.fieldlayouttabs_id_seq'::regclass);


--
-- Name: fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields ALTER COLUMN id SET DEFAULT nextval('public.fields_id_seq'::regclass);


--
-- Name: gatsby_deletedelements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gatsby_deletedelements ALTER COLUMN id SET DEFAULT nextval('public.gatsby_deletedelements_id_seq'::regclass);


--
-- Name: globalsets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets ALTER COLUMN id SET DEFAULT nextval('public.globalsets_id_seq'::regclass);


--
-- Name: gqlschemas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqlschemas ALTER COLUMN id SET DEFAULT nextval('public.gqlschemas_id_seq'::regclass);


--
-- Name: gqltokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens ALTER COLUMN id SET DEFAULT nextval('public.gqltokens_id_seq'::regclass);


--
-- Name: info id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.info ALTER COLUMN id SET DEFAULT nextval('public.info_id_seq'::regclass);


--
-- Name: matrixblocktypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes ALTER COLUMN id SET DEFAULT nextval('public.matrixblocktypes_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: plugins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins ALTER COLUMN id SET DEFAULT nextval('public.plugins_id_seq'::regclass);


--
-- Name: queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue ALTER COLUMN id SET DEFAULT nextval('public.queue_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: revisions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions ALTER COLUMN id SET DEFAULT nextval('public.revisions_id_seq'::regclass);


--
-- Name: sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections ALTER COLUMN id SET DEFAULT nextval('public.sections_id_seq'::regclass);


--
-- Name: sections_sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites ALTER COLUMN id SET DEFAULT nextval('public.sections_sites_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: shunnedmessages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages ALTER COLUMN id SET DEFAULT nextval('public.shunnedmessages_id_seq'::regclass);


--
-- Name: sitegroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sitegroups ALTER COLUMN id SET DEFAULT nextval('public.sitegroups_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: structureelements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements ALTER COLUMN id SET DEFAULT nextval('public.structureelements_id_seq'::regclass);


--
-- Name: structures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structures ALTER COLUMN id SET DEFAULT nextval('public.structures_id_seq'::regclass);


--
-- Name: systemmessages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemmessages ALTER COLUMN id SET DEFAULT nextval('public.systemmessages_id_seq'::regclass);


--
-- Name: taggroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups ALTER COLUMN id SET DEFAULT nextval('public.taggroups_id_seq'::regclass);


--
-- Name: templatecacheelements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements ALTER COLUMN id SET DEFAULT nextval('public.templatecacheelements_id_seq'::regclass);


--
-- Name: templatecachequeries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries ALTER COLUMN id SET DEFAULT nextval('public.templatecachequeries_id_seq'::regclass);


--
-- Name: templatecaches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches ALTER COLUMN id SET DEFAULT nextval('public.templatecaches_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups ALTER COLUMN id SET DEFAULT nextval('public.usergroups_id_seq'::regclass);


--
-- Name: usergroups_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users ALTER COLUMN id SET DEFAULT nextval('public.usergroups_users_id_seq'::regclass);


--
-- Name: userpermissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_id_seq'::regclass);


--
-- Name: userpermissions_usergroups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_usergroups_id_seq'::regclass);


--
-- Name: userpermissions_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users ALTER COLUMN id SET DEFAULT nextval('public.userpermissions_users_id_seq'::regclass);


--
-- Name: userpreferences userId; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences ALTER COLUMN "userId" SET DEFAULT nextval('public."userpreferences_userId_seq"'::regclass);


--
-- Name: volumefolders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders ALTER COLUMN id SET DEFAULT nextval('public.volumefolders_id_seq'::regclass);


--
-- Name: volumes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes ALTER COLUMN id SET DEFAULT nextval('public.volumes_id_seq'::regclass);


--
-- Name: widgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets ALTER COLUMN id SET DEFAULT nextval('public.widgets_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (33, 3, 5, 1, 'milesfortune_jackmountain_hotdogporkchop_-112-of-283.jpg', 'image', 750, 750, 160364, NULL, NULL, NULL, '2021-08-20 03:55:34', '2021-08-20 03:55:34', '2021-08-20 03:55:34', 'cc6422e2-a649-4a63-a085-8d39c4f352ba');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (34, 3, 5, 1, 'jack-mountain-meats.jpeg', 'image', 502, 502, 53067, NULL, NULL, NULL, '2021-08-20 03:55:42', '2021-08-20 03:55:42', '2021-08-20 03:55:42', '48763aa2-a3ec-431b-9c37-590832ecbd9e');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (35, 3, 5, 1, 'parfait-ice-cream.png', 'image', 1010, 1010, 941031, NULL, NULL, NULL, '2021-08-20 03:55:51', '2021-08-20 03:55:51', '2021-08-20 03:55:51', '0ec6b138-c74e-43cf-9fa1-074cdae93b77');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (36, 3, 5, 1, 'john-fornander-VedLcUfLi74-unsplash.jpg', 'image', 3870, 5802, 3844902, NULL, NULL, NULL, '2021-08-20 03:56:06', '2021-08-20 03:56:07', '2021-08-20 03:56:07', '3bf53909-85aa-429d-8582-7e80dde1ba5d');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (37, 3, 5, 1, 'chad-montano-GFCYhoRe48-unsplash.jpg', 'image', 3183, 4384, 1297798, NULL, NULL, NULL, '2021-08-20 03:56:20', '2021-08-20 03:56:20', '2021-08-20 03:56:20', 'aadbc8d4-c31a-4c35-bd52-c69b3edb923e');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (31, 3, 5, 1, 'gsb-breakfast.jpg', 'image', 1920, 1358, 612019, NULL, false, false, '2021-08-20 03:55:10', '2021-08-20 03:55:10', '2021-08-20 03:55:10', 'a7b2f77a-1aa8-49a8-a9b3-5811b45a1482');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (32, 3, 5, 1, 'GSB-Hero-1-Extended-2.6.jpg', 'image', 2000, 1255, 262864, NULL, false, false, '2021-08-20 03:55:24', '2021-08-20 03:55:24', '2021-08-20 03:55:24', '7162c4ff-57ae-41de-af56-bc4675226b25');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (39, 3, 5, 1, 'GSB-hero-1-extended.png', 'image', 1363, 1255, 1766063, NULL, false, false, '2021-08-20 13:28:14', '2021-08-20 13:28:14', '2021-08-20 13:28:14', 'c0c80a7a-9a92-4fac-b924-5b1608960c75');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (38, 3, 5, 1, 'gsb-breakfast.png', 'image', 1771, 1365, 3124709, NULL, false, false, '2021-08-20 13:28:03', '2021-08-20 13:28:03', '2021-08-20 13:28:03', '426f2d1f-8b8c-43b9-b094-543103250eb2');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (40, 3, 5, 1, 'gsb-breakfast.png', 'image', 1338, 1365, 2397885, NULL, NULL, NULL, '2021-08-20 13:37:18', '2021-08-20 13:37:18', '2021-08-20 13:37:18', '44ae9d50-9a30-4cf2-b313-3117e7653dba');
INSERT INTO public.assets (id, "volumeId", "folderId", "uploaderId", filename, kind, width, height, size, "focalPoint", "deletedWithVolume", "keptFile", "dateModified", "dateCreated", "dateUpdated", uid) VALUES (41, 3, 5, 1, 'GSB-hero-1-extended.png', 'image', 1155, 1255, 1604792, NULL, NULL, NULL, '2021-08-20 13:37:26', '2021-08-20 13:37:26', '2021-08-20 13:37:26', '8f03f9a3-4a18-4b68-8fed-87f8b2c3e17b');


--
-- Data for Name: assettransforms; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categories (id, "groupId", "parentId", "deletedWithGroup", "dateCreated", "dateUpdated", uid) VALUES (19, 1, NULL, NULL, '2021-08-20 01:28:17', '2021-08-20 01:28:17', '7d7c9cb2-3037-44f1-bdd8-e2096dc1abd7');


--
-- Data for Name: categorygroups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categorygroups (id, "structureId", "fieldLayoutId", name, handle, "defaultPlacement", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, 6, 'test', 'test', 'end', '2021-08-19 22:21:34', '2021-08-19 22:21:34', NULL, 'c0efc2ac-2e91-45ea-8b95-f3f243a893d8');


--
-- Data for Name: categorygroups_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categorygroups_sites (id, "groupId", "siteId", "hasUrls", "uriFormat", template, "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, true, 'test/{slug}', NULL, '2021-08-19 22:21:35', '2021-08-19 22:21:35', 'cadbfcf7-83e8-44dc-8bff-f106072286ed');


--
-- Data for Name: changedattributes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (5, 1, 'slug', '2021-08-19 19:04:34', false, 1);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (5, 1, 'uri', '2021-08-19 19:04:34', false, 1);
INSERT INTO public.changedattributes ("elementId", "siteId", attribute, "dateUpdated", propagated, "userId") VALUES (5, 1, 'title', '2021-08-19 19:04:34', false, 1);


--
-- Data for Name: changedfields; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (13, 1, 2, '2021-08-20 15:26:56', false, 1);
INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (15, 1, 2, '2021-08-20 15:27:01', false, 1);
INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (7, 1, 2, '2021-08-20 15:27:06', false, 1);
INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (17, 1, 2, '2021-08-20 15:27:13', false, 1);
INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (9, 1, 2, '2021-08-20 15:27:18', false, 1);
INSERT INTO public.changedfields ("elementId", "siteId", "fieldId", "dateUpdated", propagated, "userId") VALUES (11, 1, 2, '2021-08-20 15:27:23', false, 1);


--
-- Data for Name: content; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (1, 1, 1, NULL, '2021-08-19 17:44:41', '2021-08-19 17:44:41', '1b42d39a-def9-4eef-87ce-3449237456e5', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (2, 2, 1, NULL, '2021-08-19 18:35:46', '2021-08-19 18:46:39', '67988c01-89c2-44c6-9987-fb2e0302b4b9', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (4, 4, 1, 'test-1', '2021-08-19 18:50:36', '2021-08-19 18:50:36', '43d28860-cdae-42ca-bb0c-e93676ec5527', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (3, 3, 1, 'test-1', '2021-08-19 18:50:36', '2021-08-19 18:50:36', 'c292fee1-2a61-4dbd-bcbc-82623a77a457', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (34, 34, 1, 'Jack mountain meats', '2021-08-20 03:55:42', '2021-08-20 03:55:42', '2e474b3f-4a29-4729-b5e1-163f57adc498', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (5, 5, 1, 'First blog post', '2021-08-19 19:04:27', '2021-08-19 19:04:35', 'b31a14e0-47cf-4a73-a37d-cf0b53a67c43', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (6, 6, 1, 'First blog post', '2021-08-19 19:04:35', '2021-08-19 19:04:35', '1abaac52-2b64-4f15-9994-faa089090153', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (8, 8, 1, 'Home', '2021-08-19 23:22:51', '2021-08-19 23:22:51', 'baa92b6a-29b9-4c46-ad16-828ae1b25eb1', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (10, 10, 1, 'Locations', '2021-08-19 23:23:09', '2021-08-19 23:23:09', 'fee66ad5-0720-493d-8d35-234eb9581c9a', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (35, 35, 1, 'Parfait ice cream', '2021-08-20 03:55:50', '2021-08-20 03:55:50', '086e49b8-5c88-46cd-9ed0-8f1248331ffc', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (12, 12, 1, 'Menu', '2021-08-19 23:23:21', '2021-08-19 23:23:21', 'e7c3b713-be89-4659-b32a-deea9ad49007', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (61, 61, 1, 'About', '2021-08-20 14:50:52', '2021-08-20 14:50:52', '8cda3421-66f2-4404-a719-72d561e1f4bd', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (14, 14, 1, 'About', '2021-08-19 23:23:34', '2021-08-19 23:23:34', 'f840cdc4-e5d2-4dd2-900d-98d78f8c4ff7', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (36, 36, 1, 'John fornander Ved Lc Uf Li74 unsplash', '2021-08-20 03:56:00', '2021-08-20 03:56:00', 'f6df2747-7176-451b-bd05-aa9a359a72f3', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (16, 16, 1, 'Catering', '2021-08-19 23:24:22', '2021-08-19 23:24:22', 'b9b3c6a4-2b79-49a7-9936-85b291a57d1d', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (37, 37, 1, 'Chad montano GFC Yho Re48 unsplash', '2021-08-20 03:56:16', '2021-08-20 03:56:16', 'b285f6f5-f802-435f-a501-def06535bc7a', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (18, 18, 1, 'Jobs', '2021-08-19 23:24:35', '2021-08-19 23:24:35', '2c20852f-33eb-4f85-99ae-3b6cac684c8c', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (38, 38, 1, 'Gsb breakfast', '2021-08-20 13:28:01', '2021-08-20 13:28:01', '0a7a844a-1c01-4145-aba8-b89e12a368e7', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (19, 19, 1, 'main-menu', '2021-08-20 01:28:17', '2021-08-20 01:28:17', 'f58d6247-cfd9-41a7-96cc-478d8a3f7986', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (39, 39, 1, 'GSB hero 1 extended', '2021-08-20 13:28:13', '2021-08-20 13:28:13', '3e36ab03-7caa-4573-9cbf-b10a5305e79e', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (20, 20, 1, 'Jobs', '2021-08-20 01:33:23', '2021-08-20 01:33:23', '2ee0bb6b-36c4-4332-9e31-df3329d3711f', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (40, 40, 1, 'Gsb breakfast', '2021-08-20 13:37:16', '2021-08-20 13:37:16', 'd35ec0cd-ec50-4bd9-8343-e36eae34f74e', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (21, 21, 1, 'Catering', '2021-08-20 01:33:34', '2021-08-20 01:33:34', '4cf2a936-7ec2-4aa6-a33e-4f655333d49a', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (22, 22, 1, 'Locations', '2021-08-20 01:33:45', '2021-08-20 01:33:45', '2d82c389-aeb8-4260-b4b6-1e99d9d61308', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (41, 41, 1, 'GSB hero 1 extended', '2021-08-20 13:37:25', '2021-08-20 13:37:25', 'e14d74d0-b274-4ecd-91eb-677f2a3522ff', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (65, 65, 1, 'About', '2021-08-20 15:01:15', '2021-08-20 15:01:15', 'f9a49560-1004-437b-9344-66ba72aa4cb6', NULL, '[]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (42, 42, 1, 'Home', '2021-08-20 14:27:17', '2021-08-20 14:27:17', '02dc5cb4-ffd6-4e5b-b1ba-19e3a799a028', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (51, 51, 1, 'About', '2021-08-20 14:31:26', '2021-08-20 14:31:26', '5549df15-1779-4eb4-ba58-b2c659f4410d', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (11, 11, 1, 'Menu', '2021-08-19 23:23:21', '2021-08-20 15:27:23', 'a5913739-bae6-4600-b87e-f1c3101ea7b5', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (24, 24, 1, 'Jobs', '2021-08-20 01:48:56', '2021-08-20 01:48:56', '9fe619df-dd9b-4df4-99bf-337d815354d6', NULL, 'true');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (43, 43, 1, 'Menu', '2021-08-20 14:28:10', '2021-08-20 14:28:10', 'a08b7ffb-792b-426e-aaa6-3422f48fb10c', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (54, 54, 1, 'Home', '2021-08-20 14:31:40', '2021-08-20 14:31:40', 'f4f43bc6-6b81-4d05-83ae-acc5fa7b0cad', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (26, 26, 1, 'Catering', '2021-08-20 01:49:13', '2021-08-20 01:49:13', '979311f9-1638-4424-8a7b-e6cda1badac1', NULL, 'true');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (58, 58, 1, 'Locations', '2021-08-20 14:31:52', '2021-08-20 14:31:52', '19f402fb-b6eb-4e5d-8085-a63cfc96f18e', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (27, 27, 1, 'About', '2021-08-20 01:49:40', '2021-08-20 01:49:40', 'f6922f7d-a9e5-49c4-bae5-4848ab9b9c5b', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (28, 28, 1, 'About', '2021-08-20 01:50:15', '2021-08-20 01:50:15', '7fee2a1a-aac9-4664-934e-50e9657e0636', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (45, 45, 1, 'Menu', '2021-08-20 14:28:22', '2021-08-20 14:28:22', 'f57bffd5-f0a8-483f-95f4-ba80813e34b2', NULL, 'true');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (30, 30, 1, 'About', '2021-08-20 01:50:26', '2021-08-20 01:50:26', '7d91ef6a-914d-4dcd-9613-e6194f721e1a', NULL, 'true');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (31, 31, 1, 'Gsb breakfast', '2021-08-20 03:55:09', '2021-08-20 03:55:09', '86b76a84-617e-4608-b732-c2e8b67db91f', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (32, 32, 1, 'GSB Hero 1 Extended 2 6', '2021-08-20 03:55:23', '2021-08-20 03:55:23', '62ca6583-a553-43bf-a858-94567b8a3fe4', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (33, 33, 1, 'Milesfortune jackmountain hotdogporkchop 112 of 283', '2021-08-20 03:55:34', '2021-08-20 03:55:34', 'a6ff2fe7-2a6b-42cf-bbdb-ff25794a05ae', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (69, 69, 1, 'Jobs', '2021-08-20 15:06:33', '2021-08-20 15:06:33', '1ce3419a-87cb-426f-a4ce-49f955edf988', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (53, 53, 1, 'Catering', '2021-08-20 14:31:35', '2021-08-20 14:31:35', 'ffbf24f5-ba58-4d78-acf9-75d07346e043', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (62, 62, 1, 'About', '2021-08-20 14:50:53', '2021-08-20 14:50:53', '86027542-735d-4426-b40a-6393a006a5b9', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (47, 47, 1, 'Locations', '2021-08-20 14:28:35', '2021-08-20 14:28:35', '2826e96b-f8fd-43d5-b600-64e0e4cb1bf3', NULL, 'true');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (48, 48, 1, 'Home', '2021-08-20 14:30:29', '2021-08-20 14:30:29', 'a02913fb-43b0-4845-88b2-a36e5279df15', NULL, NULL);
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (56, 56, 1, 'Jobs', '2021-08-20 14:31:46', '2021-08-20 14:31:46', '3a824ac3-e9e2-4480-8de6-b0b13fcd7ad0', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (9, 9, 1, 'Locations', '2021-08-19 23:23:09', '2021-08-20 15:27:18', '65f7a76b-5432-4856-abed-6db1308cf361', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (60, 60, 1, 'Menu', '2021-08-20 14:31:58', '2021-08-20 14:31:58', '94e188ba-b3f0-491e-9bcc-4e218ba990a5', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (63, 63, 1, 'About', '2021-08-20 15:01:07', '2021-08-20 15:01:07', '2bd32a2c-9850-4fa9-b2bc-49dfebc24f0c', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (66, 66, 1, 'Catering', '2021-08-20 15:06:08', '2021-08-20 15:06:08', '8e48a345-2da9-4d56-a5a8-a00789b3ed4e', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (68, 68, 1, 'Catering', '2021-08-20 15:06:17', '2021-08-20 15:06:17', '68e6f9a2-1ce1-4767-a200-0bcd9f5c8f64', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (71, 71, 1, 'Jobs', '2021-08-20 15:06:41', '2021-08-20 15:06:41', '55901f3b-5ddf-43f1-85ee-7f0d21721641', NULL, '["mainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (13, 13, 1, 'About', '2021-08-19 23:23:34', '2021-08-20 15:26:56', 'f1d905ea-ba14-4668-ad92-f68e890171fd', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (73, 73, 1, 'About', '2021-08-20 15:26:56', '2021-08-20 15:26:56', '1d983b39-eeb5-4d86-bad0-f41d08c12a6d', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (15, 15, 1, 'Catering', '2021-08-19 23:24:22', '2021-08-20 15:27:01', '9c9e3348-cfd1-4636-b5c4-7fe6d88380e7', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (75, 75, 1, 'Catering', '2021-08-20 15:27:01', '2021-08-20 15:27:01', 'c6c204a9-4bf6-45a4-aa52-c66514ed6c76', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (7, 7, 1, 'Home', '2021-08-19 23:22:51', '2021-08-20 15:27:06', 'b3245e46-0eae-4e32-85ca-61aca095931e', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (77, 77, 1, 'Home', '2021-08-20 15:27:06', '2021-08-20 15:27:06', '4b6d3063-ebf8-41b3-befc-53e8a073c87a', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (17, 17, 1, 'Jobs', '2021-08-19 23:24:35', '2021-08-20 15:27:13', 'bc5b2827-38ce-4a16-8695-d1e041dd9336', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (79, 79, 1, 'Jobs', '2021-08-20 15:27:13', '2021-08-20 15:27:13', 'a11ad3c9-97dd-4431-83ab-af6a295aa9af', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (81, 81, 1, 'Locations', '2021-08-20 15:27:19', '2021-08-20 15:27:19', '46f9be92-2f4a-4aaf-b5f9-c9a95e5c8673', NULL, '["isMainMenu"]');
INSERT INTO public.content (id, "elementId", "siteId", title, "dateCreated", "dateUpdated", uid, "field_siteDescription_pzqpdxwe", "field_mainMenu_cygqxalw") VALUES (83, 83, 1, 'Menu', '2021-08-20 15:27:23', '2021-08-20 15:27:23', '19266bf4-a410-40c1-8856-e29771ecc3ad', NULL, '["isMainMenu"]');


--
-- Data for Name: craftidtokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: deprecationerrors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: elementindexsettings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: elements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (1, NULL, NULL, NULL, NULL, 'craft\elements\User', true, false, '2021-08-19 17:44:41', '2021-08-19 17:44:41', NULL, NULL, '7173a4d5-7627-4198-a902-145ee7e905cf');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (2, NULL, NULL, NULL, NULL, 'craft\elements\GlobalSet', true, false, '2021-08-19 18:35:46', '2021-08-19 18:46:39', NULL, NULL, '7f592455-840c-48d2-a416-99d62d097a6b');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (3, NULL, NULL, NULL, 2, 'craft\elements\Entry', true, false, '2021-08-19 18:50:36', '2021-08-19 18:50:36', NULL, NULL, 'fcdba5ad-d14d-4ff5-962a-599b40582f7e');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (4, 3, NULL, 1, 2, 'craft\elements\Entry', true, false, '2021-08-19 18:50:36', '2021-08-19 18:50:36', NULL, NULL, 'a30d93b7-7497-4a1f-a4f8-ffee61e97422');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (39, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 13:28:13', '2021-08-20 13:28:13', NULL, '2021-08-20 13:37:06', '71debde8-2898-4b61-a495-ab56a2250663');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (5, NULL, NULL, NULL, 3, 'craft\elements\Entry', true, false, '2021-08-19 19:04:27', '2021-08-19 19:04:35', NULL, NULL, '559ee446-6d33-48e0-99d4-7f6c09efd002');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (6, 5, NULL, 2, 3, 'craft\elements\Entry', true, false, '2021-08-19 19:04:35', '2021-08-19 19:04:35', NULL, NULL, '6dee8ab9-f601-4566-9f59-6c7d6feec3df');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (8, 7, NULL, 3, 7, 'craft\elements\Entry', true, false, '2021-08-19 23:22:51', '2021-08-19 23:22:51', NULL, NULL, '4060583d-6254-42dc-9aca-dc594c66a428');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (10, 9, NULL, 4, 8, 'craft\elements\Entry', true, false, '2021-08-19 23:23:09', '2021-08-19 23:23:09', NULL, NULL, 'e1787647-e1e7-432f-88ca-b90ae00447f8');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (12, 11, NULL, 5, 9, 'craft\elements\Entry', true, false, '2021-08-19 23:23:21', '2021-08-19 23:23:21', NULL, NULL, '3e969c74-a4bc-4a13-9e2b-c11cd6ed3b7a');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (14, 13, NULL, 6, 10, 'craft\elements\Entry', true, false, '2021-08-19 23:23:34', '2021-08-19 23:23:34', NULL, NULL, 'c0695ab4-d957-40dc-b197-72c26f5c0403');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (16, 15, NULL, 7, 11, 'craft\elements\Entry', true, false, '2021-08-19 23:24:22', '2021-08-19 23:24:22', NULL, NULL, '1e8c32d4-cd01-4770-ad86-369ae293a513');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (18, 17, NULL, 8, 12, 'craft\elements\Entry', true, false, '2021-08-19 23:24:35', '2021-08-19 23:24:35', NULL, NULL, '3ee3d5b0-3cfb-467a-a868-3fdff838f747');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (19, NULL, NULL, NULL, 6, 'craft\elements\Category', true, false, '2021-08-20 01:28:17', '2021-08-20 01:28:17', NULL, NULL, 'eda8a254-6311-48da-bb48-921c785a54cd');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (38, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 13:28:01', '2021-08-20 13:28:01', NULL, '2021-08-20 13:37:06', 'a2118458-50e3-4a7c-84e6-1a007a0c2a0d');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (20, 17, NULL, 9, 12, 'craft\elements\Entry', true, false, '2021-08-20 01:33:22', '2021-08-20 01:33:23', NULL, NULL, '1dae0188-2e53-46d4-a24e-1763a83d05d2');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (40, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 13:37:15', '2021-08-20 13:37:15', NULL, NULL, 'afca1f37-51bd-4321-8f87-db6179e85a6f');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (21, 15, NULL, 10, 11, 'craft\elements\Entry', true, false, '2021-08-20 01:33:34', '2021-08-20 01:33:34', NULL, NULL, '9d460fb4-de98-4245-894c-57c0cda032a2');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (48, 7, NULL, 21, 7, 'craft\elements\Entry', true, false, '2021-08-20 14:30:29', '2021-08-20 14:30:29', NULL, NULL, '47a9ec39-8ef6-49f8-b9c5-fcb38998d9f4');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (22, 9, NULL, 11, 8, 'craft\elements\Entry', true, false, '2021-08-20 01:33:45', '2021-08-20 01:33:45', NULL, NULL, '0320766c-e207-4ec9-83ee-8eadf6d257f6');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (41, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 13:37:25', '2021-08-20 13:37:25', NULL, NULL, '088fadc1-7efd-4b8e-a620-9d09fd9cfaa3');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (11, NULL, NULL, NULL, 9, 'craft\elements\Entry', true, false, '2021-08-19 23:23:21', '2021-08-20 15:27:23', NULL, NULL, 'a1e86396-3cef-4893-bdbf-9de68533305c');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (58, 9, NULL, 26, 8, 'craft\elements\Entry', true, false, '2021-08-20 14:31:52', '2021-08-20 14:31:52', NULL, NULL, '566d650c-1bcb-4e22-8f23-50be15359c44');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (24, 17, NULL, 12, 12, 'craft\elements\Entry', true, false, '2021-08-20 01:48:56', '2021-08-20 01:48:56', NULL, NULL, '022b2b82-8eeb-4df2-9422-57b85d979627');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (42, 7, NULL, 17, 7, 'craft\elements\Entry', true, false, '2021-08-20 14:27:17', '2021-08-20 14:27:17', NULL, NULL, '2ad6c5b0-af00-4f5b-a3be-b5dcfca92391');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (17, NULL, NULL, NULL, 12, 'craft\elements\Entry', true, false, '2021-08-19 23:24:35', '2021-08-20 15:27:13', NULL, NULL, '21be68c3-c928-4f4f-a7a5-6022e7c511fa');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (26, 15, NULL, 13, 11, 'craft\elements\Entry', true, false, '2021-08-20 01:49:13', '2021-08-20 01:49:13', NULL, NULL, 'aaa380f0-e532-4339-a677-9eec6999969a');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (43, 11, NULL, 18, 9, 'craft\elements\Entry', true, false, '2021-08-20 14:28:10', '2021-08-20 14:28:10', NULL, NULL, '72bfc52e-2b0f-4f53-b41c-b5b80e66b006');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (27, 13, NULL, 14, 10, 'craft\elements\Entry', true, false, '2021-08-20 01:49:40', '2021-08-20 01:49:40', NULL, NULL, 'e613800a-30d0-45f8-8c30-589edaf82c90');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (28, 13, NULL, 15, 10, 'craft\elements\Entry', true, false, '2021-08-20 01:50:15', '2021-08-20 01:50:15', NULL, NULL, '81afcd2c-ff90-413e-b0d7-4bf2138720c6');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (54, 7, NULL, 24, 7, 'craft\elements\Entry', true, false, '2021-08-20 14:31:40', '2021-08-20 14:31:40', NULL, NULL, '457dfba0-faab-4279-9dbb-2e7a7e70ea69');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (30, 13, NULL, 16, 10, 'craft\elements\Entry', true, false, '2021-08-20 01:50:26', '2021-08-20 01:50:26', NULL, NULL, 'e7324908-d5fb-4d2a-bd46-0f5618c85795');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (33, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:55:34', '2021-08-20 03:55:34', NULL, NULL, '5dd10b4a-96a0-4737-b113-99d7228b6f59');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (34, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:55:42', '2021-08-20 03:55:42', NULL, NULL, 'f142e289-67d8-40cd-8b3e-062c3beb653c');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (35, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:55:50', '2021-08-20 03:55:50', NULL, NULL, 'd9290c32-2e22-4924-a5a8-62b750b1d68f');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (36, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:56:00', '2021-08-20 03:56:00', NULL, NULL, '707d3c2c-2c8a-48f6-8305-8737445cc36f');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (37, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:56:16', '2021-08-20 03:56:16', NULL, NULL, '8ea887a0-0cdc-4716-928b-9926377d26b1');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (31, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:55:09', '2021-08-20 03:55:09', NULL, '2021-08-20 13:27:49', '1c4d6590-ccb7-4b55-b1ba-43ba9dfc2b3a');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (32, NULL, NULL, NULL, NULL, 'craft\elements\Asset', true, false, '2021-08-20 03:55:23', '2021-08-20 03:55:23', NULL, '2021-08-20 13:27:49', '50b8e498-9a17-47ad-a505-4d2be850eba5');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (61, 13, NULL, 28, 10, 'craft\elements\Entry', true, false, '2021-08-20 14:50:52', '2021-08-20 14:50:52', NULL, NULL, 'cafdc0f6-9777-4f2a-88dc-7dc1fd09e12e');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (45, 11, NULL, 19, 9, 'craft\elements\Entry', true, false, '2021-08-20 14:28:22', '2021-08-20 14:28:22', NULL, NULL, '04a2868a-99b9-45bf-958f-29d0fd270a66');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (51, 13, NULL, 22, 10, 'craft\elements\Entry', true, false, '2021-08-20 14:31:26', '2021-08-20 14:31:26', NULL, NULL, 'a812f1c9-fd45-4bec-8324-afd0e5db2351');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (66, 15, NULL, 32, 11, 'craft\elements\Entry', true, false, '2021-08-20 15:06:08', '2021-08-20 15:06:08', NULL, NULL, '643e7183-5dcf-4ac7-a950-9621bac79cb4');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (47, 9, NULL, 20, 8, 'craft\elements\Entry', true, false, '2021-08-20 14:28:35', '2021-08-20 14:28:35', NULL, NULL, 'bed6d69d-2411-4919-91ef-a93240aa3539');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (62, 13, NULL, 29, 10, 'craft\elements\Entry', true, false, '2021-08-20 14:50:53', '2021-08-20 14:50:53', NULL, NULL, 'e863cb65-9177-4785-ad5c-08f476ecc541');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (69, 17, NULL, 34, 12, 'craft\elements\Entry', true, false, '2021-08-20 15:06:33', '2021-08-20 15:06:33', NULL, NULL, 'd0fbf598-bbe0-4cd2-9a95-fe82bddb598c');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (53, 15, NULL, 23, 11, 'craft\elements\Entry', true, false, '2021-08-20 14:31:35', '2021-08-20 14:31:35', NULL, NULL, '52b91ec9-12f4-4be6-a20d-8ac7ce7c7f3d');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (56, 17, NULL, 25, 12, 'craft\elements\Entry', true, false, '2021-08-20 14:31:46', '2021-08-20 14:31:46', NULL, NULL, '78515431-a194-4e94-99c1-00674c15797f');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (63, 13, NULL, 30, 10, 'craft\elements\Entry', true, false, '2021-08-20 15:01:07', '2021-08-20 15:01:07', NULL, NULL, '2b39215a-4b70-4bbb-8401-6b2387383fb0');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (60, 11, NULL, 27, 9, 'craft\elements\Entry', true, false, '2021-08-20 14:31:58', '2021-08-20 14:31:58', NULL, NULL, '2c6cfd7e-389b-4ca4-a256-e42f6355bac2');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (65, 13, NULL, 31, 10, 'craft\elements\Entry', true, false, '2021-08-20 15:01:15', '2021-08-20 15:01:15', NULL, NULL, '6996db94-8eb3-4801-8526-abdeea1089e7');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (9, NULL, NULL, NULL, 8, 'craft\elements\Entry', true, false, '2021-08-19 23:23:09', '2021-08-20 15:27:18', NULL, NULL, 'e8e6a4b0-c51e-471c-8c82-b9f701ceba9c');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (68, 15, NULL, 33, 11, 'craft\elements\Entry', true, false, '2021-08-20 15:06:16', '2021-08-20 15:06:17', NULL, NULL, 'a4f6fd3d-08a1-46a0-89ce-eb6999d9f874');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (71, 17, NULL, 35, 12, 'craft\elements\Entry', true, false, '2021-08-20 15:06:41', '2021-08-20 15:06:41', NULL, NULL, '136dc01f-79c5-4691-8c07-ac1c4a496b24');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (13, NULL, NULL, NULL, 10, 'craft\elements\Entry', true, false, '2021-08-19 23:23:34', '2021-08-20 15:26:56', NULL, NULL, '5423ef44-6a8c-4be7-b0d4-5a3b5f61eae2');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (73, 13, NULL, 36, 10, 'craft\elements\Entry', true, false, '2021-08-20 15:26:56', '2021-08-20 15:26:56', NULL, NULL, '0c1349c0-18dc-46b3-b13b-37b60ed0a917');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (15, NULL, NULL, NULL, 11, 'craft\elements\Entry', true, false, '2021-08-19 23:24:22', '2021-08-20 15:27:01', NULL, NULL, 'bfa65b85-1798-474f-9f07-bd6cbba61e62');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (75, 15, NULL, 37, 11, 'craft\elements\Entry', true, false, '2021-08-20 15:27:01', '2021-08-20 15:27:01', NULL, NULL, '9a5a7a83-9419-4223-9703-cb175564ca64');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (7, NULL, NULL, NULL, 7, 'craft\elements\Entry', true, false, '2021-08-19 23:22:51', '2021-08-20 15:27:06', NULL, NULL, '74c992bb-1971-43a9-9975-d216724ea9a2');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (77, 7, NULL, 38, 7, 'craft\elements\Entry', true, false, '2021-08-20 15:27:06', '2021-08-20 15:27:06', NULL, NULL, '757744c5-bc11-4549-a872-e1cb10ee6da0');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (79, 17, NULL, 39, 12, 'craft\elements\Entry', true, false, '2021-08-20 15:27:13', '2021-08-20 15:27:13', NULL, NULL, 'de9551a2-ddea-44b4-a9c0-9160a7378265');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (81, 9, NULL, 40, 8, 'craft\elements\Entry', true, false, '2021-08-20 15:27:18', '2021-08-20 15:27:19', NULL, NULL, '617731c7-5c1f-4f71-92fd-305fa006d07d');
INSERT INTO public.elements (id, "canonicalId", "draftId", "revisionId", "fieldLayoutId", type, enabled, archived, "dateCreated", "dateUpdated", "dateLastMerged", "dateDeleted", uid) VALUES (83, 11, NULL, 41, 9, 'craft\elements\Entry', true, false, '2021-08-20 15:27:23', '2021-08-20 15:27:23', NULL, NULL, '745c2059-dc10-4c1f-a7a7-e47c0a364cbd');


--
-- Data for Name: elements_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, NULL, NULL, true, '2021-08-19 17:44:41', '2021-08-19 17:44:41', '929543e1-405c-4134-9930-fd1a52201a65');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 2, 1, NULL, NULL, true, '2021-08-19 18:35:46', '2021-08-19 18:35:46', '2ce13b42-b049-497b-bc0b-7e882a5d02e4');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 3, 1, 'test-1', 'test-1', true, '2021-08-19 18:50:36', '2021-08-19 18:50:36', '1cbb0b58-ba6e-4edd-a6bf-ae0777a5b471');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (4, 4, 1, 'test-1', 'test-1', true, '2021-08-19 18:50:36', '2021-08-19 18:50:36', 'd4735e15-327e-49e0-998d-28529e810964');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (5, 5, 1, 'first-blog-post', 'blog/first-blog-post', true, '2021-08-19 19:04:27', '2021-08-19 19:04:34', '67d48887-0ea9-4ac5-bdcc-3062485ada18');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (6, 6, 1, 'first-blog-post', 'blog/first-blog-post', true, '2021-08-19 19:04:35', '2021-08-19 19:04:35', 'd800ab2f-0e8d-4604-83af-e2d91ca15572');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (7, 7, 1, 'home', 'home', true, '2021-08-19 23:22:51', '2021-08-19 23:22:51', 'e6d0c9c1-88e8-4629-924a-01edd32ecb66');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (8, 8, 1, 'home', 'home', true, '2021-08-19 23:22:51', '2021-08-19 23:22:51', 'f83054df-a7ee-4cd7-8954-7c84364435ee');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (9, 9, 1, 'locations', 'locations', true, '2021-08-19 23:23:09', '2021-08-19 23:23:09', 'cf51cc53-6f88-4ba8-ad5b-6680e64910d5');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (10, 10, 1, 'locations', 'locations', true, '2021-08-19 23:23:09', '2021-08-19 23:23:09', 'c4a1f109-de33-42b9-9cc6-1a377d9e0a50');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (11, 11, 1, 'menu', 'menu', true, '2021-08-19 23:23:21', '2021-08-19 23:23:21', '0216e182-fbc7-4353-b76c-830df3d2c72e');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (12, 12, 1, 'menu', 'menu', true, '2021-08-19 23:23:21', '2021-08-19 23:23:21', '40931789-4d08-491b-9730-9c06a2642f76');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (13, 13, 1, 'about', 'about', true, '2021-08-19 23:23:34', '2021-08-19 23:23:34', 'ed0521d5-9cdd-4589-8362-88e656744633');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (14, 14, 1, 'about', 'about', true, '2021-08-19 23:23:34', '2021-08-19 23:23:34', '070e1e53-859f-4560-aacc-933f2a284a8e');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (15, 15, 1, 'catering', 'catering', true, '2021-08-19 23:24:22', '2021-08-19 23:24:22', '58b2c9bd-38c9-4211-9cd9-ff2b3552dd3b');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (16, 16, 1, 'catering', 'catering', true, '2021-08-19 23:24:22', '2021-08-19 23:24:22', '76402d5c-ca76-4ff5-bb76-a4d40e79b7f1');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (17, 17, 1, 'jobs', 'jobs', true, '2021-08-19 23:24:35', '2021-08-19 23:24:35', '66f0928c-f2ac-4865-afed-da70629577fc');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (18, 18, 1, 'jobs', 'jobs', true, '2021-08-19 23:24:35', '2021-08-19 23:24:35', 'cde20d66-28e3-4be9-a131-d9740718f569');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (19, 19, 1, 'main-menu', 'test/main-menu', true, '2021-08-20 01:28:17', '2021-08-20 01:28:18', '72471957-a96b-46a7-b56d-bdce597d9ff2');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (20, 20, 1, 'jobs', 'jobs', true, '2021-08-20 01:33:23', '2021-08-20 01:33:23', '704fdbb8-c435-4113-8b9f-b63de57100cc');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (21, 21, 1, 'catering', 'catering', true, '2021-08-20 01:33:34', '2021-08-20 01:33:34', '2c45ea71-20be-4854-88da-295266a96188');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (22, 22, 1, 'locations', 'locations', true, '2021-08-20 01:33:45', '2021-08-20 01:33:45', '93706605-f14a-4a8b-8165-87642ec0ea64');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (24, 24, 1, 'jobs', 'jobs', true, '2021-08-20 01:48:56', '2021-08-20 01:48:56', '8a123aa9-ba74-4bc8-ad0b-b38f8ece1a70');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (26, 26, 1, 'catering', 'catering', true, '2021-08-20 01:49:13', '2021-08-20 01:49:13', '5deccf5b-b53a-40f9-9cfc-3e33a7fe4748');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (27, 27, 1, 'about', 'about', true, '2021-08-20 01:49:40', '2021-08-20 01:49:40', '65fc04fa-2ce7-4a88-a09f-b169493449b5');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (28, 28, 1, 'about', 'about', true, '2021-08-20 01:50:15', '2021-08-20 01:50:15', '37225ea6-48cb-4604-a86d-6776f3460216');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (30, 30, 1, 'about', 'about', true, '2021-08-20 01:50:26', '2021-08-20 01:50:26', '5150e483-8176-4d13-b339-f6b316607416');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (31, 31, 1, NULL, NULL, true, '2021-08-20 03:55:09', '2021-08-20 03:55:09', '024128c1-3b48-4480-8644-735f1bae9223');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (32, 32, 1, NULL, NULL, true, '2021-08-20 03:55:23', '2021-08-20 03:55:23', '9f52e6d1-3074-4636-9196-4ecd4db3dd35');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (33, 33, 1, NULL, NULL, true, '2021-08-20 03:55:34', '2021-08-20 03:55:34', 'e8912f60-6f04-472f-8405-7f3b37b2c48b');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (34, 34, 1, NULL, NULL, true, '2021-08-20 03:55:42', '2021-08-20 03:55:42', 'c83bd516-cf0c-40e1-85e0-05fecb6788c8');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (35, 35, 1, NULL, NULL, true, '2021-08-20 03:55:50', '2021-08-20 03:55:50', '2d7ea0fb-337e-4f84-8dbb-ad1683b1c5ce');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (36, 36, 1, NULL, NULL, true, '2021-08-20 03:56:00', '2021-08-20 03:56:00', '7afb6aec-3466-4e9f-907e-a5185ffcb783');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (37, 37, 1, NULL, NULL, true, '2021-08-20 03:56:16', '2021-08-20 03:56:16', '8c913139-21b0-4938-aae6-f725610c8696');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (38, 38, 1, NULL, NULL, true, '2021-08-20 13:28:01', '2021-08-20 13:28:01', 'ea9e3f45-5667-4083-a01b-4dc86e6764de');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (39, 39, 1, NULL, NULL, true, '2021-08-20 13:28:13', '2021-08-20 13:28:13', 'a053fa71-67fc-47cd-8af7-5ee40d72c13d');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (40, 40, 1, NULL, NULL, true, '2021-08-20 13:37:16', '2021-08-20 13:37:16', '7817336c-8901-4e1e-b1a4-5e8aa1eef4cf');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (41, 41, 1, NULL, NULL, true, '2021-08-20 13:37:25', '2021-08-20 13:37:25', '3b7ff77e-dab1-4035-9dff-56a1b0dd5b20');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (42, 42, 1, 'home', 'home', true, '2021-08-20 14:27:17', '2021-08-20 14:27:17', '383ec288-7115-4adc-ac02-563306d13551');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (43, 43, 1, 'menu', 'menu', true, '2021-08-20 14:28:10', '2021-08-20 14:28:10', '28fd3656-d554-452a-b097-51cc9263756b');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (45, 45, 1, 'menu', 'menu', true, '2021-08-20 14:28:22', '2021-08-20 14:28:22', 'f81d0be9-247b-4894-bfe3-0b5df5f9e35f');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (47, 47, 1, 'locations', 'locations', true, '2021-08-20 14:28:35', '2021-08-20 14:28:35', '526391df-f71a-4ad5-ae6e-8d2c5e9b501f');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (48, 48, 1, 'home', 'home', true, '2021-08-20 14:30:29', '2021-08-20 14:30:29', 'ad2e5100-35be-447f-9ce7-6ed9b35f2ea2');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (51, 51, 1, 'about', 'about', true, '2021-08-20 14:31:26', '2021-08-20 14:31:26', 'dfa45760-5a20-49d4-8dde-d10429cb306d');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (53, 53, 1, 'catering', 'catering', true, '2021-08-20 14:31:35', '2021-08-20 14:31:35', 'c3b1db0c-7676-4c5d-a207-bc32d0ac7ec5');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (54, 54, 1, 'home', 'home', true, '2021-08-20 14:31:40', '2021-08-20 14:31:40', 'b3eba385-6daa-46bd-a24c-74f91dcc75a9');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (56, 56, 1, 'jobs', 'jobs', true, '2021-08-20 14:31:46', '2021-08-20 14:31:46', '0272b289-e547-426c-b499-f1fac6c0a190');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (58, 58, 1, 'locations', 'locations', true, '2021-08-20 14:31:52', '2021-08-20 14:31:52', 'f146fa72-408b-4e0b-a111-8050cd43fc0e');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (60, 60, 1, 'menu', 'menu', true, '2021-08-20 14:31:58', '2021-08-20 14:31:58', '3b964a14-c649-421f-97ea-e3344e1a7781');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (61, 61, 1, 'about', 'about', true, '2021-08-20 14:50:52', '2021-08-20 14:50:52', '38ca676f-bd0f-4979-aecb-53928ed7ec95');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (62, 62, 1, 'about', 'about', true, '2021-08-20 14:50:53', '2021-08-20 14:50:53', 'b3d5a9c4-62d7-46d3-aeb8-c8ea633b45d3');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (63, 63, 1, 'about', 'about', true, '2021-08-20 15:01:07', '2021-08-20 15:01:07', '8d0de2ec-0555-4641-ba95-879ef58ea697');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (65, 65, 1, 'about', 'about', true, '2021-08-20 15:01:15', '2021-08-20 15:01:15', 'b38d35b4-0949-474b-a433-befbad78a7d7');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (66, 66, 1, 'catering', 'catering', true, '2021-08-20 15:06:08', '2021-08-20 15:06:08', 'b37de80c-f54d-455d-b3ae-50151467845a');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (68, 68, 1, 'catering', 'catering', true, '2021-08-20 15:06:17', '2021-08-20 15:06:17', 'c7ce99eb-f939-48db-a298-5f8d6d97fcb1');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (69, 69, 1, 'jobs', 'jobs', true, '2021-08-20 15:06:33', '2021-08-20 15:06:33', '6973c3c1-a0c8-4a52-8ef5-93299217b77b');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (71, 71, 1, 'jobs', 'jobs', true, '2021-08-20 15:06:41', '2021-08-20 15:06:41', 'fc4e70e9-f560-489a-abf4-842b4be6aff7');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (73, 73, 1, 'about', 'about', true, '2021-08-20 15:26:56', '2021-08-20 15:26:56', '7178922b-184e-440f-992c-4ce2ab6fc0f8');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (75, 75, 1, 'catering', 'catering', true, '2021-08-20 15:27:01', '2021-08-20 15:27:01', '8145fdff-d10f-404c-b655-5c61803181ca');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (77, 77, 1, 'home', 'home', true, '2021-08-20 15:27:06', '2021-08-20 15:27:06', 'd1135103-2e7c-4cb0-b001-c791bc258963');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (79, 79, 1, 'jobs', 'jobs', true, '2021-08-20 15:27:13', '2021-08-20 15:27:13', 'f750cf46-d424-4df4-bb89-7bd53ad4f4a1');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (81, 81, 1, 'locations', 'locations', true, '2021-08-20 15:27:19', '2021-08-20 15:27:19', '6cdd019e-a8b9-4b49-913c-2906cbd473ee');
INSERT INTO public.elements_sites (id, "elementId", "siteId", slug, uri, enabled, "dateCreated", "dateUpdated", uid) VALUES (83, 83, 1, 'menu', 'menu', true, '2021-08-20 15:27:23', '2021-08-20 15:27:23', '4a7440f1-9e37-4fd6-aa39-067ea6821803');


--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (3, 1, NULL, 1, NULL, '2021-08-19 18:50:00', NULL, NULL, '2021-08-19 18:50:36', '2021-08-19 18:50:36', 'b22a1df4-6ddf-4507-b766-5a9e9eca1cdc');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (4, 1, NULL, 1, NULL, '2021-08-19 18:50:00', NULL, NULL, '2021-08-19 18:50:36', '2021-08-19 18:50:36', '231f9682-52d8-449d-b974-6eeb607ac70a');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (5, 2, NULL, 2, 1, '2021-08-19 19:04:00', NULL, NULL, '2021-08-19 19:04:27', '2021-08-19 19:04:27', '599f7983-2511-4427-b696-5b95d3f3cb5f');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (6, 2, NULL, 2, 1, '2021-08-19 19:04:00', NULL, NULL, '2021-08-19 19:04:35', '2021-08-19 19:04:35', 'f90f5394-d20c-4d97-bd1a-843db42e26a3');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (7, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-19 23:22:51', '2021-08-19 23:22:51', '929f13cc-e0dc-48e9-9087-a5cf9ceab730');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (8, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-19 23:22:51', '2021-08-19 23:22:51', '3a15ca76-2d26-41b3-b691-90a0d45d803d');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (9, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:09', '2021-08-19 23:23:09', '25ceb7b3-44f5-43d9-ab8a-49fdffe8a528');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (10, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:09', '2021-08-19 23:23:09', '8d23d294-c70b-4bd6-9933-b373a5737028');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (11, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:21', '2021-08-19 23:23:21', '2e83fe2c-15ab-429e-840c-d42a38281472');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (12, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:21', '2021-08-19 23:23:21', 'ad758df1-6d7e-48c9-8aec-acd19ad8e732');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (13, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:34', '2021-08-19 23:23:34', '1370af64-97f5-4f11-bd00-1bdeab88c38d');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (14, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-19 23:23:34', '2021-08-19 23:23:34', 'e534d121-19f2-4b71-a504-4b807d64e466');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (15, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-19 23:24:22', '2021-08-19 23:24:22', '969ba5cb-1c14-4b57-958c-7087b003c2a0');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (16, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-19 23:24:22', '2021-08-19 23:24:22', '4c1b1094-a8e8-4151-96f2-67850cc4fa75');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (17, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-19 23:24:35', '2021-08-19 23:24:35', 'dfae6167-0a6b-4b43-b624-b56d4d8f22d9');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (18, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-19 23:24:35', '2021-08-19 23:24:35', '7d800e9a-9f45-4078-a23b-e729b5fc163e');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (20, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 01:33:23', '2021-08-20 01:33:23', 'e4ba9f78-d823-4e0c-9f43-fe638159d2a0');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (21, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 01:33:34', '2021-08-20 01:33:34', 'e97c7c16-1554-4568-a026-2864cd074749');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (22, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 01:33:45', '2021-08-20 01:33:45', 'ef561873-4bdf-4136-bd6f-c30eeed21c47');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (24, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 01:48:56', '2021-08-20 01:48:56', '91a9aa11-7778-4056-8190-c523d1ad0f5a');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (66, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:06:08', '2021-08-20 15:06:08', '41528920-9ae6-4243-bb7b-7952469e6798');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (26, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 01:49:13', '2021-08-20 01:49:13', '101cab02-16c3-4cd8-98c0-908196dce791');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (27, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 01:49:40', '2021-08-20 01:49:40', '7b8ab97b-8b45-49a0-bb94-e2b4b55f1e0f');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (28, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 01:50:15', '2021-08-20 01:50:15', '898a4b53-a36a-4655-bd5f-a5a780c14f85');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (30, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 01:50:26', '2021-08-20 01:50:26', 'a8db082c-83b5-4e0a-8dde-4411e6925dc4');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (68, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:06:17', '2021-08-20 15:06:17', '03c9df11-e69c-4ad8-841a-79c88e33d323');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (42, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-20 14:27:17', '2021-08-20 14:27:17', '52a73a24-8c35-49e1-a3e3-116e2914a64d');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (43, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:28:10', '2021-08-20 14:28:10', '00c048b3-754d-4ae8-8437-ea621b6cf24a');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (45, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:28:22', '2021-08-20 14:28:22', '7df73c3a-4cbe-4f56-82d0-48083b35ce68');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (47, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:28:35', '2021-08-20 14:28:35', 'f5a9f4f7-d78b-4222-af61-b66d3d9df396');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (69, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:06:33', '2021-08-20 15:06:33', 'fe011dfa-43e8-49da-950f-83b68364369b');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (48, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-20 14:30:29', '2021-08-20 14:30:29', '773a25fa-7658-47c4-8679-262c5879fdab');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (51, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:31:26', '2021-08-20 14:31:26', '075feefd-82f2-4634-81c6-677189c26649');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (53, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 14:31:35', '2021-08-20 14:31:35', 'c09baa14-e900-47bd-ace9-a1fab5f7af31');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (71, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:06:41', '2021-08-20 15:06:41', '7835d39f-09ef-4fd8-85e7-2dbfdb90a43f');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (54, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-20 14:31:40', '2021-08-20 14:31:40', '35b1bb42-0979-4f57-a82a-ca86dd3909ab');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (56, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 14:31:46', '2021-08-20 14:31:46', 'c1dd1f09-de19-4d27-b8a0-476149cf9cee');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (58, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:31:52', '2021-08-20 14:31:52', 'dfb41b95-f661-40d4-b62c-b5535e7cb463');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (73, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 15:26:56', '2021-08-20 15:26:56', 'fa3a9233-1199-40a8-88dc-23b43df9d52a');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (60, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:31:58', '2021-08-20 14:31:58', '99cddcaa-df56-45fc-865e-6e54af63a060');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (83, 5, NULL, 6, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 15:27:23', '2021-08-20 15:27:23', 'f23c15d2-6330-4b8b-abfa-bc87c39af8c5');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (61, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:50:52', '2021-08-20 14:50:52', '693659b3-c8c9-41a3-990d-f18af5e1eb74');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (62, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 14:50:53', '2021-08-20 14:50:53', '5b19b96a-90e4-40b0-8481-e4c4be5f17bb');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (63, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 15:01:07', '2021-08-20 15:01:07', '79d64eaa-0d5e-4cac-9498-d0bb44c6f243');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (65, 6, NULL, 7, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 15:01:15', '2021-08-20 15:01:15', '50c33fdd-7123-4930-bf5d-e4f1aae4ae6e');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (75, 7, NULL, 8, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:27:01', '2021-08-20 15:27:01', '535895f2-8706-4449-a09e-fe2456b362b8');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (77, 3, NULL, 4, NULL, '2021-08-19 23:22:00', NULL, NULL, '2021-08-20 15:27:06', '2021-08-20 15:27:06', '2b2e9252-26c0-489c-8018-15eaa5dc8755');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (79, 8, NULL, 9, NULL, '2021-08-19 23:24:00', NULL, NULL, '2021-08-20 15:27:13', '2021-08-20 15:27:13', '5dd299b5-06a4-45fb-b629-eba2018746fc');
INSERT INTO public.entries (id, "sectionId", "parentId", "typeId", "authorId", "postDate", "expiryDate", "deletedWithEntryType", "dateCreated", "dateUpdated", uid) VALUES (81, 4, NULL, 5, NULL, '2021-08-19 23:23:00', NULL, NULL, '2021-08-20 15:27:19', '2021-08-20 15:27:19', 'b04f7afc-7eca-4cab-85a6-52a0dbb58e6f');


--
-- Data for Name: entrytypes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, 2, 'test-1', 'test1', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 18:50:36', '2021-08-19 18:50:36', NULL, '93ffb49d-4e2b-480c-afd2-0d96e7aa8039');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 2, 3, 'Default', 'default', true, 'site', NULL, NULL, 1, '2021-08-19 19:01:51', '2021-08-19 19:01:51', NULL, '95e76f85-a82d-45f9-a11b-5b94312c641f');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, 2, 4, 'first blog post', 'firstBlogPost', true, 'site', NULL, NULL, 2, '2021-08-19 19:02:24', '2021-08-19 19:02:24', '2021-08-19 19:04:02', '9cf06449-4097-4607-8bba-82b36aeebd6b');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (4, 3, 7, 'Home', 'home', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:22:51', '2021-08-19 23:22:51', NULL, '702b10c3-ac47-4464-93cc-f7ddda7c0d56');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (5, 4, 8, 'Locations', 'locations', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:23:09', '2021-08-19 23:23:09', NULL, '0802aec5-d8a5-4840-adfe-794b62ef580e');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (6, 5, 9, 'Menu', 'menu', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:23:21', '2021-08-19 23:23:21', NULL, '8f256bea-8070-4819-a31d-98b8f74a0317');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (7, 6, 10, 'About', 'about', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:23:34', '2021-08-19 23:23:34', NULL, 'f124a7e8-7872-4014-9550-ff289e764ed3');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (8, 7, 11, 'Catering', 'catering', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:24:22', '2021-08-19 23:24:22', NULL, '26af9948-63b1-456e-a6ac-553f5a3ea744');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (9, 8, 12, 'Jobs', 'jobs', false, 'site', NULL, '{section.name|raw}', 1, '2021-08-19 23:24:35', '2021-08-19 23:24:35', NULL, 'f5f578b7-ee25-4e95-a6ff-fd2040336720');
INSERT INTO public.entrytypes (id, "sectionId", "fieldLayoutId", name, handle, "hasTitleField", "titleTranslationMethod", "titleTranslationKeyFormat", "titleFormat", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (10, 9, 13, 'Default', 'default', true, 'site', NULL, NULL, 1, '2021-08-19 23:25:00', '2021-08-19 23:25:00', NULL, 'c428f464-3bf1-4f91-b39c-11360884c29c');


--
-- Data for Name: fieldgroups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldgroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 'Common', '2021-08-19 17:44:41', '2021-08-19 17:44:41', NULL, '899ec41f-a06b-4b99-b1ec-5535da4c0061');
INSERT INTO public.fieldgroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 'global-fields', '2021-08-19 18:51:40', '2021-08-19 18:51:40', NULL, 'c078a30a-5e1c-459a-9670-25e8932e68bd');


--
-- Data for Name: fieldlayoutfields; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (3, 8, 18, 2, false, 1, '2021-08-20 01:33:45', '2021-08-20 01:33:45', '029dc172-3ab8-4d20-9e78-7f85c5457f40');
INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (7, 9, 22, 2, false, 0, '2021-08-20 14:28:10', '2021-08-20 14:28:10', '512a1f41-b587-451a-a045-7fbe3ded55be');
INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (8, 7, 23, 2, false, 1, '2021-08-20 14:30:29', '2021-08-20 14:30:29', 'aae1a1f7-687f-466a-ade7-56d63d262423');
INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (12, 10, 26, 2, false, 1, '2021-08-20 15:01:07', '2021-08-20 15:01:07', '9a56e45d-6c8b-4868-a1d3-8d8218fbafdb');
INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (15, 11, 27, 2, false, 2, '2021-08-20 15:06:08', '2021-08-20 15:06:08', '06b54412-1509-41ba-ac89-ae6428709d69');
INSERT INTO public.fieldlayoutfields (id, "layoutId", "tabId", "fieldId", required, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (16, 12, 28, 2, false, 1, '2021-08-20 15:06:33', '2021-08-20 15:06:33', '96938de9-cdb4-41b0-a515-02dc94476045');


--
-- Data for Name: fieldlayouts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 'craft\elements\Entry', '2021-08-19 18:50:36', '2021-08-19 18:50:36', NULL, '713af9a6-efb9-403e-b7d6-b8a1b637fbd5');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, 'craft\elements\Entry', '2021-08-19 19:01:51', '2021-08-19 19:01:51', NULL, '83054daa-28ce-4c44-aa05-7246d9b5020c');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (4, 'craft\elements\Entry', '2021-08-19 19:02:24', '2021-08-19 19:02:24', '2021-08-19 19:04:02', '5dae5794-1155-4cf2-aae4-ac5eeb62390b');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 'craft\elements\Asset', '2021-08-19 18:33:27', '2021-08-19 18:33:27', '2021-08-19 19:07:20', 'eede087b-ce2c-4682-a897-ad51f7fe6a3a');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (5, 'craft\elements\Asset', '2021-08-19 19:08:08', '2021-08-19 19:08:08', NULL, 'dc2b1265-dabd-48d5-9daf-89d25d495d40');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (6, 'craft\elements\Category', '2021-08-19 22:21:34', '2021-08-19 22:21:34', NULL, 'cb544ea8-3f58-4552-a05d-a63457117d2e');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (7, 'craft\elements\Entry', '2021-08-19 23:22:51', '2021-08-19 23:22:51', NULL, 'f48be696-ca18-4162-961e-6bb9e62ae4b6');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (8, 'craft\elements\Entry', '2021-08-19 23:23:09', '2021-08-19 23:23:09', NULL, '1764e955-c45a-47fe-ac35-c1bbd169b1fa');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (9, 'craft\elements\Entry', '2021-08-19 23:23:21', '2021-08-19 23:23:21', NULL, '6ec2524d-3e22-463f-9545-a86da9fe2dc9');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (10, 'craft\elements\Entry', '2021-08-19 23:23:34', '2021-08-19 23:23:34', NULL, '13a718b2-6129-47ae-8f0b-3d62d9884f06');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (11, 'craft\elements\Entry', '2021-08-19 23:24:22', '2021-08-19 23:24:22', NULL, '63365d44-4ef7-4513-9e9c-92fcb6d095a1');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (12, 'craft\elements\Entry', '2021-08-19 23:24:35', '2021-08-19 23:24:35', NULL, '6afff9df-4370-4a1b-af5a-e02d53b4b74e');
INSERT INTO public.fieldlayouts (id, type, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (13, 'craft\elements\Entry', '2021-08-19 23:25:00', '2021-08-19 23:25:00', NULL, 'b9631a97-912f-4c16-b80d-c0e92c3e3456');


--
-- Data for Name: fieldlayouttabs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (1, 1, 'Content', '[{"type":"craft\\fieldlayoutelements\\AssetTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 18:33:27', '2021-08-19 18:33:27', 'e424c994-c764-4d57-be8e-f47ff7c8ad7c');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (2, 2, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 18:50:36', '2021-08-19 18:50:36', 'e0c571e6-7d2f-4071-a38d-eefd9de86c6e');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (5, 4, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 19:03:08', '2021-08-19 19:03:08', '059007f1-00c0-4b33-b273-e40c85d9e78a');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (6, 3, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 19:03:13', '2021-08-19 19:03:13', 'a5d89cae-d6c9-4f30-aaec-5171be871035');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (7, 5, 'Content', '[{"type":"craft\\fieldlayoutelements\\AssetTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 19:08:08', '2021-08-19 19:08:08', '7efb5580-4202-4a9f-b833-57bbf4523eac');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (8, 6, 'Content', '[{"type":"craft\\fieldlayoutelements\\TitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 22:21:34', '2021-08-19 22:21:34', '6f840cde-fc33-4ec8-b739-1d0fa7f94052');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (15, 13, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-19 23:25:00', '2021-08-19 23:25:00', '669a2ed0-0c39-4a48-afc5-c20f22cad2c9');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (18, 8, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"}]', 1, '2021-08-20 01:33:45', '2021-08-20 01:33:45', '77fb866a-5f87-46ea-a2c9-f539f0abe8af');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (22, 9, 'Content', '[{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"},{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100}]', 1, '2021-08-20 14:28:10', '2021-08-20 14:28:10', '25959ca1-fee8-4301-8958-36a12aba88e5');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (23, 7, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"a249b291-d114-4c6e-bdfb-0fd253d9fc76"}]', 1, '2021-08-20 14:30:29', '2021-08-20 14:30:29', 'e2d85d1f-c358-4844-a43f-b867c05dd7a9');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (26, 10, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"}]', 1, '2021-08-20 15:01:07', '2021-08-20 15:01:07', 'aa85d35e-bec7-4d74-b20e-3ad5f428e811');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (27, 11, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"}]', 1, '2021-08-20 15:06:08', '2021-08-20 15:06:08', 'ae2319da-723c-4ba0-84d1-c791372d652b');
INSERT INTO public.fieldlayouttabs (id, "layoutId", name, elements, "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (28, 12, 'Content', '[{"type":"craft\\fieldlayoutelements\\EntryTitleField","autocomplete":false,"class":null,"size":null,"name":null,"autocorrect":true,"autocapitalize":true,"disabled":false,"readonly":false,"title":null,"placeholder":null,"step":null,"min":null,"max":null,"requirable":false,"id":null,"containerAttributes":[],"inputContainerAttributes":[],"labelAttributes":[],"orientation":null,"label":null,"instructions":null,"tip":null,"warning":null,"width":100},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"8fdf0495-fa4a-4742-b84b-92de96b7ec42"},{"type":"craft\\fieldlayoutelements\\CustomField","label":null,"instructions":null,"tip":null,"warning":null,"required":false,"width":100,"fieldUid":"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"}]', 1, '2021-08-20 15:06:33', '2021-08-20 15:06:33', 'a6525a6c-187e-4138-aab2-a2a9445f9358');


--
-- Data for Name: fields; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fields (id, "groupId", name, handle, context, "columnSuffix", instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) VALUES (1, 2, 'Site Description', 'siteDescription', 'global', 'pzqpdxwe', '', false, 'none', NULL, 'craft\fields\PlainText', '{"byteLimit":null,"charLimit":null,"code":"","columnType":null,"initialRows":"4","multiline":"","placeholder":null,"uiMode":"normal"}', '2021-08-19 18:52:24', '2021-08-19 18:52:24', '7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c');
INSERT INTO public.fields (id, "groupId", name, handle, context, "columnSuffix", instructions, searchable, "translationMethod", "translationKeyFormat", type, settings, "dateCreated", "dateUpdated", uid) VALUES (2, 2, 'main menu', 'mainMenu', 'global', 'cygqxalw', '', false, 'none', NULL, 'craft\fields\Checkboxes', '{"multi":true,"options":[{"label":"isMainMenu","value":"isMainMenu","default":"1"}]}', '2021-08-20 01:32:55', '2021-08-20 15:26:16', '8fdf0495-fa4a-4742-b84b-92de96b7ec42');


--
-- Data for Name: gatsby_deletedelements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (1, 23, 1, 'jobs_jobs_Entry', '2021-08-20 01:48:56');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (2, 25, 1, 'catering_catering_Entry', '2021-08-20 01:49:13');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (3, 29, 1, 'about_about_Entry', '2021-08-20 01:50:26');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (4, 31, 1, 'featuredImages_Asset', '2021-08-20 13:27:49');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (5, 32, 1, 'featuredImages_Asset', '2021-08-20 13:27:49');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (6, 39, 1, 'featuredImages_Asset', '2021-08-20 13:37:06');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (7, 38, 1, 'featuredImages_Asset', '2021-08-20 13:37:06');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (8, 44, 1, 'menu_menu_Entry', '2021-08-20 14:28:23');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (9, 46, 1, 'locations_locations_Entry', '2021-08-20 14:28:35');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (10, 50, 1, 'about_about_Entry', '2021-08-20 14:31:26');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (11, 52, 1, 'catering_catering_Entry', '2021-08-20 14:31:35');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (12, 49, 1, 'home_home_Entry', '2021-08-20 14:31:41');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (13, 55, 1, 'jobs_jobs_Entry', '2021-08-20 14:31:46');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (14, 57, 1, 'locations_locations_Entry', '2021-08-20 14:31:53');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (15, 59, 1, 'menu_menu_Entry', '2021-08-20 14:31:58');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (16, 64, 1, 'about_about_Entry', '2021-08-20 15:01:15');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (17, 67, 1, 'catering_catering_Entry', '2021-08-20 15:06:17');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (18, 70, 1, 'jobs_jobs_Entry', '2021-08-20 15:06:41');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (19, 72, 1, 'about_about_Entry', '2021-08-20 15:26:56');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (20, 74, 1, 'catering_catering_Entry', '2021-08-20 15:27:01');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (21, 76, 1, 'home_home_Entry', '2021-08-20 15:27:06');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (22, 78, 1, 'jobs_jobs_Entry', '2021-08-20 15:27:13');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (23, 80, 1, 'locations_locations_Entry', '2021-08-20 15:27:19');
INSERT INTO public.gatsby_deletedelements (id, "elementId", "siteId", "typeName", "dateDeleted") VALUES (24, 82, 1, 'menu_menu_Entry', '2021-08-20 15:27:24');


--
-- Data for Name: globalsets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.globalsets (id, name, handle, "fieldLayoutId", "sortOrder", "dateCreated", "dateUpdated", uid) VALUES (2, 'main-menu', 'mainMenu', NULL, 1, '2021-08-19 18:35:46', '2021-08-19 18:35:46', '7f592455-840c-48d2-a416-99d62d097a6b');


--
-- Data for Name: gqlschemas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gqlschemas (id, name, scope, "isPublic", "dateCreated", "dateUpdated", uid) VALUES (1, 'Public Schema', '["elements.drafts:read","elements.revisions:read","elements.inactive:read","sections.066dc17d-bd30-44a7-8c3c-547610375203:read","entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:read","sections.302f217a-712b-4e95-aaae-d676f147788c:read","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:read","sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:read","entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:read","sections.f50713ee-7c2c-4ee1-882f-40373efb623e:read","entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:read","sections.53f0ffd8-c139-492a-aee7-aa9efce64503:read","entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:read","sections.1b633c96-41b8-4483-8799-e6a2ccae24de:read","entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:read","sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:read","entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:read","sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:read","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:read","sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:read","entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:read","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:read","globalsets.7f592455-840c-48d2-a416-99d62d097a6b:read","usergroups.everyone:read","categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:read","gatsby:read"]', true, '2021-08-19 17:48:49', '2021-08-20 01:44:33', '68cee898-956f-4bd4-bd76-b686d303eb7c');
INSERT INTO public.gqlschemas (id, name, scope, "isPublic", "dateCreated", "dateUpdated", uid) VALUES (2, 'gatsby', '["elements.drafts:read","elements.revisions:read","elements.inactive:read","sections.066dc17d-bd30-44a7-8c3c-547610375203:read","entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:read","sections.302f217a-712b-4e95-aaae-d676f147788c:read","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:read","sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:read","entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:read","sections.f50713ee-7c2c-4ee1-882f-40373efb623e:read","entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:read","sections.53f0ffd8-c139-492a-aee7-aa9efce64503:read","entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:read","sections.1b633c96-41b8-4483-8799-e6a2ccae24de:read","entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:read","sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:read","entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:read","sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:read","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:read","sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:read","entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:read","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:read","volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:read","globalsets.7f592455-840c-48d2-a416-99d62d097a6b:read","usergroups.everyone:read","categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:read","gatsby:read","sections.066dc17d-bd30-44a7-8c3c-547610375203:edit","entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:save","sections.302f217a-712b-4e95-aaae-d676f147788c:edit","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:edit","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:create","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:save","entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:delete","sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:edit","entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:save","sections.f50713ee-7c2c-4ee1-882f-40373efb623e:edit","entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:save","sections.53f0ffd8-c139-492a-aee7-aa9efce64503:edit","entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:save","sections.1b633c96-41b8-4483-8799-e6a2ccae24de:edit","entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:save","sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:edit","entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:save","sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:edit","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:edit","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:create","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:save","entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:delete","sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:edit","entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:save","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:edit","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:create","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:save","volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:delete","volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:edit","volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:create","volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:save","volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:delete","globalsets.7f592455-840c-48d2-a416-99d62d097a6b:edit","categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:edit","categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:save","categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:delete"]', false, '2021-08-19 17:49:34', '2021-08-20 04:10:37', '39aad2d7-86f9-4511-8367-37b64c6c3efc');


--
-- Data for Name: gqltokens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.gqltokens (id, name, "accessToken", enabled, "expiryDate", "lastUsed", "schemaId", "dateCreated", "dateUpdated", uid) VALUES (1, 'Public Token', '__PUBLIC__', true, NULL, NULL, 1, '2021-08-19 17:48:49', '2021-08-19 17:48:49', '38a47fbf-42cc-4038-bb57-5de8579d3870');
INSERT INTO public.gqltokens (id, name, "accessToken", enabled, "expiryDate", "lastUsed", "schemaId", "dateCreated", "dateUpdated", uid) VALUES (2, 'gatsby-site', 'ISZFz93MbG4JFmWZtqFoZnyzHGYauuVs', true, NULL, '2021-08-20 17:41:43', 2, '2021-08-19 17:49:05', '2021-08-20 17:41:43', 'f7818067-f9e5-43fc-9857-91c598e0bcb8');


--
-- Data for Name: info; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.info (id, version, "schemaVersion", maintenance, "configVersion", "fieldVersion", "dateCreated", "dateUpdated", uid) VALUES (1, '3.7.10', '3.7.7', false, 'clgawgagdevo', 'oifoyfltiuuc', '2021-08-19 17:44:41', '2021-08-20 15:26:48', 'faa1c40a-d3ee-46f4-bb98-9d188933e870');


--
-- Data for Name: matrixblocks; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: matrixblocktypes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (1, 'craft', 'Install', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '31f69413-d7cb-4301-88eb-272e249210c1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (2, 'craft', 'm150403_183908_migrations_table_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'cd922d32-f860-41d3-9ed7-c1375d90fbed');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (3, 'craft', 'm150403_184247_plugins_table_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'fe1b7b95-8aa6-4896-bdb5-a6701daefb67');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (4, 'craft', 'm150403_184533_field_version', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '43ff16e0-03f1-486b-9e5e-1a9c7dbe3f92');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (5, 'craft', 'm150403_184729_type_columns', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '9eda61b2-4ff1-49be-b0ac-6937ae5c13b6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (6, 'craft', 'm150403_185142_volumes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '67c9a852-b3e0-488a-8acc-bf5119ca8b99');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (7, 'craft', 'm150428_231346_userpreferences', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'a75f19c4-e9ca-474f-9ecb-692269eb6921');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (8, 'craft', 'm150519_150900_fieldversion_conversion', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4b8123ac-2d1e-4436-8eb5-ffa095fd3e92');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (9, 'craft', 'm150617_213829_update_email_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'a0f992c1-3cc4-4ea6-8f59-78337320134a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (10, 'craft', 'm150721_124739_templatecachequeries', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd184082f-25a9-47dd-9350-4c12ddba893a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (11, 'craft', 'm150724_140822_adjust_quality_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '6915fa7a-1880-46a1-bd3f-b5ee0afe42c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (12, 'craft', 'm150815_133521_last_login_attempt_ip', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '61d17cbf-1794-4a21-abf8-389b4b07a21f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (13, 'craft', 'm151002_095935_volume_cache_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7d405c10-92fc-4f8e-aae9-dd5fce260053');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (14, 'craft', 'm151005_142750_volume_s3_storage_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1a505d56-d2af-4018-b81c-1fb53ce29f6f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (15, 'craft', 'm151016_133600_delete_asset_thumbnails', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7ba0095b-8a3a-4d00-850e-0f80d30128a4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (16, 'craft', 'm151209_000000_move_logo', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'da306460-ed4d-4d1b-876e-2eae8eb9d42d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (17, 'craft', 'm151211_000000_rename_fileId_to_assetId', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '293b0292-8989-43e8-891e-4bf9a133ae4e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (18, 'craft', 'm151215_000000_rename_asset_permissions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '500a225d-774e-49c1-bc52-df45b93f1374');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (19, 'craft', 'm160707_000001_rename_richtext_assetsource_setting', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '333f33e3-310f-46d7-adb4-409614c9d0dc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (20, 'craft', 'm160708_185142_volume_hasUrls_setting', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'af3808a0-cecf-482e-96cd-25779a88b106');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (21, 'craft', 'm160714_000000_increase_max_asset_filesize', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '18cd0e65-0d1a-487e-a540-98e68b79ddd4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (22, 'craft', 'm160727_194637_column_cleanup', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'aeb4f7f3-37f3-44f6-a085-4e8ec081f74d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (23, 'craft', 'm160804_110002_userphotos_to_assets', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3ac4b65e-3dc3-4773-bb0c-7c4840aa7ccb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (24, 'craft', 'm160807_144858_sites', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '8ae1a477-d5d9-4197-a218-910c9a8e9fde');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (25, 'craft', 'm160829_000000_pending_user_content_cleanup', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '88594bff-8abb-43ac-8394-daecd97530e5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (26, 'craft', 'm160830_000000_asset_index_uri_increase', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3efb88d6-f3c2-4fc5-a755-d3ba44c6b4c7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (27, 'craft', 'm160912_230520_require_entry_type_id', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b7cafc31-bb49-48c9-be0a-a72e27645876');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (28, 'craft', 'm160913_134730_require_matrix_block_type_id', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'bb5572bc-aaf1-4572-a38f-35aaf31b4ffb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (29, 'craft', 'm160920_174553_matrixblocks_owner_site_id_nullable', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c0a82efd-5057-4289-b11a-101dd6fa130f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (30, 'craft', 'm160920_231045_usergroup_handle_title_unique', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'a25de9d0-930c-485b-9c5e-b96aafde72c4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (31, 'craft', 'm160925_113941_route_uri_parts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'fcdb8e0f-a341-4634-b1d8-46727c08f04a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (32, 'craft', 'm161006_205918_schemaVersion_not_null', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c4d32a67-99b6-4c95-b95d-5ea725a65bd7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (33, 'craft', 'm161007_130653_update_email_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'a23a6a6f-16a9-48d1-95d2-17a2047c822d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (34, 'craft', 'm161013_175052_newParentId', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '11c9c8ee-b3e3-4ecd-b6cc-88c83c3b3665');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (35, 'craft', 'm161021_102916_fix_recent_entries_widgets', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7edaa2e8-1247-45fe-ac0b-e9f13b91241b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (36, 'craft', 'm161021_182140_rename_get_help_widget', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'bddec0b5-4704-4b1d-85e6-10c18a0b5f5d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (37, 'craft', 'm161025_000000_fix_char_columns', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1fc25514-fd07-40bb-bf01-0c990afdd2a6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (38, 'craft', 'm161029_124145_email_message_languages', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3acf67e7-6c9f-4bc6-a2da-635ba9a93e46');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (39, 'craft', 'm161108_000000_new_version_format', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '912cb34e-7b13-4577-aaad-684ceab89d1c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (40, 'craft', 'm161109_000000_index_shuffle', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1cd33fac-60e6-48dc-bc5b-640a234c4900');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (41, 'craft', 'm161122_185500_no_craft_app', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '6fa8ddc5-bade-459b-9dc6-d0775f6543ec');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (42, 'craft', 'm161125_150752_clear_urlmanager_cache', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '6cfd1900-5648-4ac6-8f1e-9d245024a34a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (43, 'craft', 'm161220_000000_volumes_hasurl_notnull', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3a765d12-fa90-43b5-bf2b-7d25b4b21864');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (44, 'craft', 'm170114_161144_udates_permission', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c3d13116-373e-4df7-8af2-3481279f5fa2');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (45, 'craft', 'm170120_000000_schema_cleanup', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '580d12a9-7741-4d50-9c69-b8d3e8460d9d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (46, 'craft', 'm170126_000000_assets_focal_point', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '82915c0f-e040-45be-861a-8ee2e05dceee');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (47, 'craft', 'm170206_142126_system_name', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '398d817f-6fed-436f-99e7-e885cb8a20c7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (48, 'craft', 'm170217_044740_category_branch_limits', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '8ced00bf-c26d-4792-bc75-4b940175435e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (49, 'craft', 'm170217_120224_asset_indexing_columns', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '76673153-940c-4b20-98af-3528c84f2a04');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (50, 'craft', 'm170223_224012_plain_text_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'fadea11d-bc36-4f35-a2b5-70a4f3d8afbb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (51, 'craft', 'm170227_120814_focal_point_percentage', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b84f093e-7191-4659-a023-a2c326bc4bdb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (52, 'craft', 'm170228_171113_system_messages', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd224519c-89c5-4828-96bb-203571438118');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (53, 'craft', 'm170303_140500_asset_field_source_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '148fda65-7a00-41c1-b64e-cc3740f645bd');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (54, 'craft', 'm170306_150500_asset_temporary_uploads', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b4f9631f-a7c4-411a-aa4f-094cc6478d99');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (55, 'craft', 'm170523_190652_element_field_layout_ids', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'db4a0363-07ce-4233-aeac-52c0177f1579');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (56, 'craft', 'm170621_195237_format_plugin_handles', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '909ad60f-1e29-43e5-8494-4d36bdedcef6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (57, 'craft', 'm170630_161027_deprecation_line_nullable', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd726ddf9-412a-4334-800e-5bf82fc1fd3f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (58, 'craft', 'm170630_161028_deprecation_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'cabbb5a0-e029-47fd-8eb1-620c51b3edbe');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (59, 'craft', 'm170703_181539_plugins_table_tweaks', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'f5778cb0-e0c2-48fa-8035-7df966271543');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (60, 'craft', 'm170704_134916_sites_tables', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '0c463c8e-3ef2-4e1b-8248-43d5f9b28f19');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (61, 'craft', 'm170706_183216_rename_sequences', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1605ef09-c6ce-46ed-adaf-e1436985db23');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (62, 'craft', 'm170707_094758_delete_compiled_traits', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '73d685fb-5200-425e-83f8-6d23f11beea5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (63, 'craft', 'm170731_190138_drop_asset_packagist', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e0f3a09f-2182-4a8e-aedd-0376787bedad');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (64, 'craft', 'm170810_201318_create_queue_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd41ff703-ba6e-47c6-b84a-a97efd5cba71');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (65, 'craft', 'm170903_192801_longblob_for_queue_jobs', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '93fe70a6-b00a-41b3-8e5d-92380c72b75b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (66, 'craft', 'm170914_204621_asset_cache_shuffle', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1844e730-f349-4811-8168-57163c189dde');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (67, 'craft', 'm171011_214115_site_groups', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3978ba0b-4b66-4057-ba3e-09da862a858f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (68, 'craft', 'm171012_151440_primary_site', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c4905da4-b0ce-42c7-87f8-ee355063cbab');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (69, 'craft', 'm171013_142500_transform_interlace', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '386edfb1-e886-49a8-9204-9a14d8c319ad');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (70, 'craft', 'm171016_092553_drop_position_select', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e6f89c50-f769-4f17-8ee4-cb0492aa42d5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (71, 'craft', 'm171016_221244_less_strict_translation_method', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '01e75031-8ba9-4acb-ae03-aadc5e802bc1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (72, 'craft', 'm171107_000000_assign_group_permissions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'ed973bf8-201b-42e4-8c75-e57fea12525e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (73, 'craft', 'm171117_000001_templatecache_index_tune', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '8789c156-8374-4efc-b023-b00bbcfeaf4d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (74, 'craft', 'm171126_105927_disabled_plugins', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2d565376-5987-492d-acea-09b9eb6002be');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (75, 'craft', 'm171130_214407_craftidtokens_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '9268d0e2-c386-46a5-ac22-a61f2011c04f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (76, 'craft', 'm171202_004225_update_email_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '94086dae-47bf-4564-a166-06bbbd97ebae');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (77, 'craft', 'm171204_000001_templatecache_index_tune_deux', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c099a688-4da5-4007-bd99-af900544d69f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (78, 'craft', 'm171205_130908_remove_craftidtokens_refreshtoken_column', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4329f19b-a1ad-4d63-8276-c9e536e4324e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (79, 'craft', 'm171218_143135_longtext_query_column', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '592f7e20-d2cc-4ac6-b2bc-7f5dffecc582');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (80, 'craft', 'm171231_055546_environment_variables_to_aliases', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5bb44f47-adce-4661-be9b-e88b83c5dd10');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (81, 'craft', 'm180113_153740_drop_users_archived_column', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '28a190b3-0427-4f9f-9d84-e2050b5bba91');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (82, 'craft', 'm180122_213433_propagate_entries_setting', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd55d5020-de2c-49c3-b5ff-85030a791f6b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (83, 'craft', 'm180124_230459_fix_propagate_entries_values', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '0cda5777-d667-4aef-ac2e-2405152b6b19');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (84, 'craft', 'm180128_235202_set_tag_slugs', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '510c056a-1cc6-4ca1-9ada-60701a6e67cb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (85, 'craft', 'm180202_185551_fix_focal_points', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e6181e20-6c75-423c-9aaa-6445996b8172');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (86, 'craft', 'm180217_172123_tiny_ints', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '03c3276e-5ed0-4d53-8a89-379601727fa5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (87, 'craft', 'm180321_233505_small_ints', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7b8a00a6-3ce1-48d2-a4fb-d7e7580cf236');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (88, 'craft', 'm180404_182320_edition_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '44187553-7679-4caf-8b96-f9f0bc0b59c7');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (89, 'craft', 'm180411_102218_fix_db_routes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b28631cf-537a-46d3-b050-91e62a7989bc');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (90, 'craft', 'm180416_205628_resourcepaths_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '0e064573-1dd3-41a6-bb69-d847b25de721');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (91, 'craft', 'm180418_205713_widget_cleanup', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4090f24e-021a-458f-b161-e24acda1e7fe');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (92, 'craft', 'm180425_203349_searchable_fields', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5ffbd3e6-03a4-49b0-aba8-0444b4ff78eb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (93, 'craft', 'm180516_153000_uids_in_field_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '669e8ea2-cbea-4fa3-a6bd-02779068fc03');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (94, 'craft', 'm180517_173000_user_photo_volume_to_uid', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e135a32f-e001-42cc-8713-c8d8ce0f6be5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (95, 'craft', 'm180518_173000_permissions_to_uid', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b2b73961-10c7-40f2-9cd5-bc5ce4536a77');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (96, 'craft', 'm180520_173000_matrix_context_to_uids', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'f3b35c34-9fa0-4001-9758-57cecdb1e773');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (97, 'craft', 'm180521_172900_project_config_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7716d6c7-cf35-4720-93d1-854aa7b91713');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (98, 'craft', 'm180521_173000_initial_yml_and_snapshot', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '881e7833-b34a-44b0-8a31-6eb1ef105515');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (99, 'craft', 'm180731_162030_soft_delete_sites', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '260c5860-d89a-4c28-a7fa-c3d59c4e26ba');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (100, 'craft', 'm180810_214427_soft_delete_field_layouts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd5792e11-0786-472f-ba13-c87ff6e6e853');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (101, 'craft', 'm180810_214439_soft_delete_elements', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5c213de0-c77c-4664-80de-8e7c719dbbde');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (102, 'craft', 'm180824_193422_case_sensitivity_fixes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2530eb1f-62cf-4329-a090-28d0f41d29cf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (103, 'craft', 'm180901_151639_fix_matrixcontent_tables', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd7291791-7c08-4815-b1d0-0d2a41017709');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (104, 'craft', 'm180904_112109_permission_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '28b9ea0d-4e5a-49c6-9fc1-6269da5501b6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (105, 'craft', 'm180910_142030_soft_delete_sitegroups', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'fe36202b-eca0-4779-818c-089131416d3d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (106, 'craft', 'm181011_160000_soft_delete_asset_support', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7ae3e2d6-d1bb-49aa-b3db-46d085e89c1b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (107, 'craft', 'm181016_183648_set_default_user_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'dadfaea2-65cf-4936-93d3-4c571c8a669b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (108, 'craft', 'm181017_225222_system_config_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'eeeffaef-dee5-495c-b014-962bd4ce5564');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (109, 'craft', 'm181018_222343_drop_userpermissions_from_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e36fa525-d191-461b-8580-5a45542559d5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (110, 'craft', 'm181029_130000_add_transforms_routes_to_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '67589e61-1931-417d-8627-69764407f688');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (111, 'craft', 'm181112_203955_sequences_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'aace35e4-38f9-4082-8ac0-4276dab8e579');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (112, 'craft', 'm181121_001712_cleanup_field_configs', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '299575bc-d01b-49b2-b6bb-5c90a1f50877');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (113, 'craft', 'm181128_193942_fix_project_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'f9c4492c-b5d5-4ab7-a605-d73a4f229982');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (114, 'craft', 'm181130_143040_fix_schema_version', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '0944ad65-f956-44d2-b302-c277ed715112');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (115, 'craft', 'm181211_143040_fix_entry_type_uids', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '21b094f1-4b79-45b6-a32c-1bd423cb4c2c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (116, 'craft', 'm181217_153000_fix_structure_uids', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '9a8758a2-4e64-4a11-9473-45e986892e27');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (117, 'craft', 'm190104_152725_store_licensed_plugin_editions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5158f035-3cd8-48bb-a451-934e67f024fb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (118, 'craft', 'm190108_110000_cleanup_project_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3d92afde-b834-4521-8ab1-7807306b41bb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (119, 'craft', 'm190108_113000_asset_field_setting_change', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '592ce383-137b-4752-9c2e-3378b6b68220');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (120, 'craft', 'm190109_172845_fix_colspan', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '78298f3f-538d-4d48-af98-100474db5690');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (121, 'craft', 'm190110_150000_prune_nonexisting_sites', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '36f7bf69-ffd8-4089-b5e1-ac7ba8266ebb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (122, 'craft', 'm190110_214819_soft_delete_volumes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd20dd883-9848-49ca-8c4c-6f2033991265');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (123, 'craft', 'm190112_124737_fix_user_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4fd60544-45e0-491b-aa68-fa5089e9d4e9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (124, 'craft', 'm190112_131225_fix_field_layouts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '8755a03d-f780-4b2e-904b-2c50c06566eb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (125, 'craft', 'm190112_201010_more_soft_deletes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5abeb709-87d4-40dd-8c65-7e0b91e34440');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (126, 'craft', 'm190114_143000_more_asset_field_setting_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'df889f0b-c85b-4fec-87a5-5369146a6711');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (127, 'craft', 'm190121_120000_rich_text_config_setting', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e6eca10a-462f-4168-8eb9-dc47eb1edd2e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (128, 'craft', 'm190125_191628_fix_email_transport_password', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '5d8d6051-3b6e-429a-877b-094468c20c14');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (129, 'craft', 'm190128_181422_cleanup_volume_folders', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '97950a51-b6d9-4968-8bd4-8dbaf4c6d7e0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (130, 'craft', 'm190205_140000_fix_asset_soft_delete_index', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'bb126a88-6abe-402c-a943-6e29df861aae');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (131, 'craft', 'm190218_143000_element_index_settings_uid', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '55bea64f-b7b9-42e4-bbf1-908cf8fda9ab');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (132, 'craft', 'm190312_152740_element_revisions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd88cc1c6-2b04-4f8a-b67d-b3d4f5005585');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (133, 'craft', 'm190327_235137_propagation_method', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'efe92a1d-c83f-488d-abb6-5e135a4f4713');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (134, 'craft', 'm190401_223843_drop_old_indexes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e93a7d96-da11-43e1-8f60-98c195a39361');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (135, 'craft', 'm190416_014525_drop_unique_global_indexes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '00b7d8e3-cfe0-46d0-9358-9b0528e2998b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (136, 'craft', 'm190417_085010_add_image_editor_permissions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c25d9648-6f48-4270-9868-23f19e3e48ff');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (137, 'craft', 'm190502_122019_store_default_user_group_uid', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '27aa17d1-9bfd-4949-93ed-5c7c5a96f1d9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (138, 'craft', 'm190504_150349_preview_targets', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e3b434da-36f3-46c7-b7bd-febd5ed7fcca');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (139, 'craft', 'm190516_184711_job_progress_label', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '23a546ef-1b79-4982-9519-9e670416fda4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (140, 'craft', 'm190523_190303_optional_revision_creators', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '9cc469f0-6735-45e3-8549-c0ff3aa8217e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (141, 'craft', 'm190529_204501_fix_duplicate_uids', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7c08a202-dc20-4afb-8a8d-1415f03559e1');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (142, 'craft', 'm190605_223807_unsaved_drafts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '538b7f38-b7f7-4824-920d-45de5b7bbf58');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (143, 'craft', 'm190607_230042_entry_revision_error_tables', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'cb5cdd7a-1a5a-4a1b-8ea8-4d722c55fb97');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (144, 'craft', 'm190608_033429_drop_elements_uid_idx', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'f9d29738-21b3-49e8-ba74-fbba71cf98f6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (145, 'craft', 'm190617_164400_add_gqlschemas_table', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '21a07d2e-37e1-488d-b82d-06d93bf5b4ee');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (146, 'craft', 'm190624_234204_matrix_propagation_method', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c17b556e-a4e7-4659-80c1-2ceb9b97de04');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (147, 'craft', 'm190711_153020_drop_snapshots', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c163d26d-c705-463d-940d-17d8456069de');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (148, 'craft', 'm190712_195914_no_draft_revisions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4bc84ae2-ed5a-46b8-9fb8-a9a8da7ed572');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (149, 'craft', 'm190723_140314_fix_preview_targets_column', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'cec269df-f6c5-425c-a418-9687177434e3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (150, 'craft', 'm190820_003519_flush_compiled_templates', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '15fb415d-3078-4083-8215-9a7303bf14a3');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (151, 'craft', 'm190823_020339_optional_draft_creators', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'dca9175b-d63c-4d69-a3cc-89cdd9f0ab0c');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (152, 'craft', 'm190913_152146_update_preview_targets', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '46aa5f74-f812-4914-bd36-f9921074689a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (153, 'craft', 'm191107_122000_add_gql_project_config_support', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b340f7ee-27d6-4cbb-8475-5b943d4328a9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (154, 'craft', 'm191204_085100_pack_savable_component_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1ccbcde7-6fee-4b30-a9da-3d78ef624bbb');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (155, 'craft', 'm191206_001148_change_tracking', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '63ce6292-96d2-41a7-817e-389423d1291f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (156, 'craft', 'm191216_191635_asset_upload_tracking', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '06094158-9324-4314-bcc5-c014f53f47d9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (157, 'craft', 'm191222_002848_peer_asset_permissions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '3d510919-554e-4411-844b-3798fe8ad615');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (158, 'craft', 'm200127_172522_queue_channels', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '983ccd76-246b-4c10-b2c6-30c3db13c9cf');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (159, 'craft', 'm200211_175048_truncate_element_query_cache', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b9b786ac-b8be-4f72-8da8-9391ddc8c515');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (160, 'craft', 'm200213_172522_new_elements_index', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '6cc4d39e-0cd7-4e8d-b99f-a365a9d9b83b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (161, 'craft', 'm200228_195211_long_deprecation_messages', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'c3b68709-6efb-405e-ba16-626152ef46da');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (162, 'craft', 'm200306_054652_disabled_sites', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '9779d4a2-70b5-42d6-825c-0b262251e374');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (163, 'craft', 'm200522_191453_clear_template_caches', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '886dbc82-2cb6-4836-8cab-92b7cbdfaa8f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (164, 'craft', 'm200606_231117_migration_tracks', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '686ae5e2-6a3c-4312-8c76-b910b9138975');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (165, 'craft', 'm200619_215137_title_translation_method', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '4fd61f90-85d9-42f6-8e22-8a120dae208b');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (166, 'craft', 'm200620_005028_user_group_descriptions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '18b0a54f-20f5-49eb-8d3a-518afc262f7f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (167, 'craft', 'm200620_230205_field_layout_changes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '31287f33-b996-4f01-97f4-d33b193a61c9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (168, 'craft', 'm200625_131100_move_entrytypes_to_top_project_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '86167d79-acca-4639-8bb3-eff86cb46a25');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (169, 'craft', 'm200629_112700_remove_project_config_legacy_files', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'f6c67245-1948-4c7d-9cfc-c52ad13efb50');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (170, 'craft', 'm200630_183000_drop_configmap', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '00ea0303-2f68-4ecd-9d56-e5d99d9a569e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (171, 'craft', 'm200715_113400_transform_index_error_flag', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '6252a01c-a048-406a-888e-fbc7b0432464');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (172, 'craft', 'm200716_110900_replace_file_asset_permissions', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'e302846b-3155-4b1e-a58f-1aba29e8f38e');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (173, 'craft', 'm200716_153800_public_token_settings_in_project_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2ebe509f-6c3b-450f-af3c-135af085a805');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (174, 'craft', 'm200720_175543_drop_unique_constraints', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '270a1e4b-6166-4852-b036-3279ee9f798a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (175, 'craft', 'm200825_051217_project_config_version', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '02f5edc8-165c-4803-b319-828f1bbd85a4');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (176, 'craft', 'm201116_190500_asset_title_translation_method', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'd62220be-ceca-4d5c-9740-21e74b4a7ba0');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (177, 'craft', 'm201124_003555_plugin_trials', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '1f7d2416-e49f-44ed-b3d0-677911a9da93');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (178, 'craft', 'm210209_135503_soft_delete_field_groups', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '264fd26a-342f-4677-b404-a8be27dec42a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (179, 'craft', 'm210212_223539_delete_invalid_drafts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '8f21ac07-38e5-4b48-b078-d14ed4f78c47');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (180, 'craft', 'm210214_202731_track_saved_drafts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '36393c8d-ad53-4ba8-822b-5f43df37cf51');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (181, 'craft', 'm210223_150900_add_new_element_gql_schema_components', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '09a00af9-143b-4ae2-8a65-0599be13688f');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (182, 'craft', 'm210302_212318_canonical_elements', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '33ae4f7f-7cd8-4389-90a3-dcde25a37166');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (183, 'craft', 'm210326_132000_invalidate_projectconfig_cache', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'fa34bc95-9f0b-4191-b02a-deb107ebca98');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (184, 'craft', 'm210329_214847_field_column_suffixes', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '59a86901-f56e-4239-938f-aab534bda6a6');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (185, 'craft', 'm210331_220322_null_author', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '7d37172b-dac2-40d7-b27b-8dd650b9e11d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (186, 'craft', 'm210405_231315_provisional_drafts', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'b78817ca-855e-464a-87d5-e792f22cb39a');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (187, 'craft', 'm210602_111300_project_config_names_in_config', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '47c2de1f-f28b-410a-9e89-35d00dae7873');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (188, 'craft', 'm210611_233510_default_placement_settings', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '383e89c5-5589-4434-9597-c92d3ca6c6c5');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (189, 'craft', 'm210613_145522_sortable_global_sets', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '101e814d-49f6-499f-a03c-4a5e98043c93');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (190, 'craft', 'm210613_184103_announcements', '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-19 17:44:42', 'bd19c996-416e-4ef3-9dd4-8d4132bb0356');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (191, 'plugin:gatsby-helper', 'Install', '2021-08-19 17:48:20', '2021-08-19 17:48:20', '2021-08-19 17:48:20', 'a817c7d6-67d7-40a5-86f5-961b610a67e9');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (192, 'plugin:gatsby-helper', 'm201116_123000_settingname', '2021-08-19 17:48:20', '2021-08-19 17:48:20', '2021-08-19 17:48:20', 'fd298255-0852-4d50-99f4-3a9a1a5a264d');
INSERT INTO public.migrations (id, track, name, "applyTime", "dateCreated", "dateUpdated", uid) VALUES (193, 'plugin:gatsby-helper', 'm210419_173000_deletedElementSiteId', '2021-08-19 17:48:20', '2021-08-19 17:48:20', '2021-08-19 17:48:20', '76cd8e57-8309-4eb8-bd29-04f189436c15');


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.plugins (id, handle, version, "schemaVersion", "licenseKeyStatus", "licensedEdition", "installDate", "dateCreated", "dateUpdated", uid) VALUES (1, 'gatsby-helper', '1.0.4', '2.0.0', 'unknown', NULL, '2021-08-19 17:48:20', '2021-08-19 17:48:20', '2021-08-20 18:16:46', '8f1a8cd8-61e1-4267-a878-b59ff47269df');


--
-- Data for Name: projectconfig; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\AssetTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.fieldLayouts.dc2b1265-dabd-48d5-9daf-89d25d495d40.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.handle', '"blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.name', '"Blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('fieldGroups.899ec41f-a06b-4b99-b1ec-5535da4c0061.name', '"Common"');
INSERT INTO public.projectconfig (path, value) VALUES ('siteGroups.47719cc6-ab00-40eb-9b8e-9cc2e4fd0457.name', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.baseUrl', '"$PRIMARY_SITE_URL"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.handle', '"default"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.language', '"en-US"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.name', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.primary', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.siteGroup', '"47719cc6-ab00-40eb-9b8e-9cc2e4fd0457"');
INSERT INTO public.projectconfig (path, value) VALUES ('sites.bc661644-8fb6-4894-92fb-ba1b7b4be651.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.settings.path', '"@webroot/assets/blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.fromEmail', '"dev@bluemonkeymakes.com"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.fromName', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('email.transportType', '"craft\\mail\\transportadapters\\Sendmail"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.sortOrder', '2');
INSERT INTO public.projectconfig (path, value) VALUES ('system.name', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.live', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('system.schemaVersion', '"3.7.7"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.timeZone', '"America/Los_Angeles"');
INSERT INTO public.projectconfig (path, value) VALUES ('users.requireEmailVerification', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('users.allowPublicRegistration', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('users.defaultGroup', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('users.photoVolumeUid', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('users.photoSubpath', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.899ec41f-a06b-4b99-b1ec-5535da4c0061', '"Common"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.47719cc6-ab00-40eb-9b8e-9cc2e4fd0457', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.bc661644-8fb6-4894-92fb-ba1b7b4be651', '"craft-cms"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.titleTranslationMethod', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.gatsby-helper.edition', '"standard"');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.gatsby-helper.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('plugins.gatsby-helper.schemaVersion', '"2.0.0"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.type', '"craft\\volumes\\Local"');
INSERT INTO public.projectconfig (path, value) VALUES ('system.edition', '"pro"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.isPublic', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.name', '"Public Schema"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.publicToken.enabled', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.publicToken.expiryDate', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.68cee898-956f-4bd4-bd76-b686d303eb7c', '"Public Schema"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.39aad2d7-86f9-4511-8367-37b64c6c3efc', '"gatsby"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.a959b3c5-22ed-4707-af5b-00883b180a0e.url', '"@web/assets/blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.a959b3c5-22ed-4707-af5b-00883b180a0e', '"Blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.0', '"elements.drafts:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.1', '"elements.revisions:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.2', '"elements.inactive:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.3', '"sections.066dc17d-bd30-44a7-8c3c-547610375203:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.4', '"entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.5', '"sections.302f217a-712b-4e95-aaae-d676f147788c:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.6', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.7', '"sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.8', '"entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.9', '"sections.f50713ee-7c2c-4ee1-882f-40373efb623e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.10', '"entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.11', '"sections.53f0ffd8-c139-492a-aee7-aa9efce64503:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.12', '"entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.13', '"sections.1b633c96-41b8-4483-8799-e6a2ccae24de:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.14', '"entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.15', '"sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.16', '"entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.17', '"sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('globalSets.7f592455-840c-48d2-a416-99d62d097a6b.handle', '"mainMenu"');
INSERT INTO public.projectconfig (path, value) VALUES ('globalSets.7f592455-840c-48d2-a416-99d62d097a6b.name', '"main-menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('globalSets.7f592455-840c-48d2-a416-99d62d097a6b.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.7f592455-840c-48d2-a416-99d62d097a6b', '"main-menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.handle', '"test1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.name', '"test-1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', '"test-1/_entry"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"test-1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.fieldLayouts.713af9a6-efb9-403e-b7d6-b8a1b637fbd5.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.handle', '"test1"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.name', '"test-1"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.section', '"9d6b4418-84b8-4034-8b4b-fb4767d4ba56"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.9d6b4418-84b8-4034-8b4b-fb4767d4ba56', '"test-1"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.93ffb49d-4e2b-480c-afd2-0d96e7aa8039', '"test-1"');
INSERT INTO public.projectconfig (path, value) VALUES ('fieldGroups.c078a30a-5e1c-459a-9670-25e8932e68bd.name', '"global-fields"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.c078a30a-5e1c-459a-9670-25e8932e68bd', '"global-fields"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.columnSuffix', '"pzqpdxwe"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.contentColumnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.fieldGroup', '"c078a30a-5e1c-459a-9670-25e8932e68bd"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.handle', '"siteDescription"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.instructions', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.name', '"Site Description"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.searchable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.byteLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.charLimit', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.code', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.columnType', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.initialRows', '"4"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.multiline', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.settings.uiMode', '"normal"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.translationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.translationMethod', '"none"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c.type', '"craft\\fields\\PlainText"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.7f6a4fb5-d6bc-4cb3-ab48-0dd5989dda8c', '"Site Description"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.handle', '"blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.name', '"Blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"blog/{slug}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.302f217a-712b-4e95-aaae-d676f147788c.type', '"channel"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.fieldLayouts.83054daa-28ce-4c44-aa05-7246d9b5020c.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.handle', '"default"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.hasTitleField', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.name', '"Default"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.section', '"302f217a-712b-4e95-aaae-d676f147788c"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.titleFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.95e76f85-a82d-45f9-a11b-5b94312c641f.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.302f217a-712b-4e95-aaae-d676f147788c', '"Blog"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.95e76f85-a82d-45f9-a11b-5b94312c641f', '"Default"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\TitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.fieldLayouts.cb544ea8-3f58-4552-a05d-a63457117d2e.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.handle', '"test"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.name', '"test"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"test/{slug}"');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.structure.maxLevels', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('categoryGroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8.structure.uid', '"901f912e-4fef-41a7-841c-5c6e125dcf4d"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.c0efc2ac-2e91-45ea-8b95-f3f243a893d8', '"test"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.18', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.19', '"sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.20', '"entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.21', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.22', '"globalsets.7f592455-840c-48d2-a416-99d62d097a6b:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.23', '"usergroups.everyone:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.24', '"categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.68cee898-956f-4bd4-bd76-b686d303eb7c.scope.25', '"gatsby:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.fieldUid', '"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.elements.2.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.fieldLayouts.6afff9df-4370-4a1b-af5a-e02d53b4b74e.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.handle', '"jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.name', '"Jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.section', '"53f0ffd8-c139-492a-aee7-aa9efce64503"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.fieldUid', '"a249b291-d114-4c6e-bdfb-0fd253d9fc76"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.elements.2.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.fieldLayouts.f48be696-ca18-4162-961e-6bb9e62ae4b6.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.handle', '"home"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.name', '"Home"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.section', '"f50713ee-7c2c-4ee1-882f-40373efb623e"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.handle', '"home"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.name', '"Home"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"home"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.f50713ee-7c2c-4ee1-882f-40373efb623e.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f5f578b7-ee25-4e95-a6ff-fd2040336720.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.f50713ee-7c2c-4ee1-882f-40373efb623e', '"Home"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.702b10c3-ac47-4464-93cc-f7ddda7c0d56', '"Home"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.handle', '"locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.name', '"Locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.1b633c96-41b8-4483-8799-e6a2ccae24de.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.1b633c96-41b8-4483-8799-e6a2ccae24de', '"Locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.0802aec5-d8a5-4840-adfe-794b62ef580e', '"Locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.handle', '"menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.name', '"Menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('dateModified', '1629473176');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.fieldUid', '"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.elements.2.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.fieldLayouts.13a718b2-6129-47ae-8f0b-3d62d9884f06.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.handle', '"about"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.name', '"About"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.8ca45ec6-7c68-4dbb-be8e-697c487a0c55', '"Menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.8f256bea-8070-4819-a31d-98b8f74a0317', '"Menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.section', '"066dc17d-bd30-44a7-8c3c-547610375203"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.handle', '"featuredImages"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.name', '"featured-images"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.settings.path', '"@webroot/assets/images"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.sortOrder', '3');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.titleTranslationMethod', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.type', '"craft\\volumes\\Local"');
INSERT INTO public.projectconfig (path, value) VALUES ('volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98.url', '"@web/assets/images"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.1b434650-e683-41c4-a1f9-f84bf2a58c98', '"featured-images"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.f124a7e8-7872-4014-9550-ff289e764ed3.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.columnSuffix', '"cygqxalw"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.contentColumnType', '"text"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.fieldGroup', '"c078a30a-5e1c-459a-9670-25e8932e68bd"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.handle', '"mainMenu"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.instructions', '""');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.name', '"main menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.searchable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.multi', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.0.1', '"isMainMenu"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.1.0', '"value"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.1.1', '"isMainMenu"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.2.0', '"default"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.settings.options.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.translationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.translationMethod', '"none"');
INSERT INTO public.projectconfig (path, value) VALUES ('fields.8fdf0495-fa4a-4742-b84b-92de96b7ec42.type', '"craft\\fields\\Checkboxes"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.handle', '"about"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.name', '"About"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"about"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.066dc17d-bd30-44a7-8c3c-547610375203.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.066dc17d-bd30-44a7-8c3c-547610375203', '"About"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.f124a7e8-7872-4014-9550-ff289e764ed3', '"About"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.isPublic', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.name', '"gatsby"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.0', '"elements.drafts:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.1', '"elements.revisions:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.2', '"elements.inactive:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.3', '"sections.066dc17d-bd30-44a7-8c3c-547610375203:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.4', '"entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.5', '"sections.302f217a-712b-4e95-aaae-d676f147788c:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.6', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.7', '"sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.fieldUid', '"01f4fdce-7bc7-48a8-b723-1a5c46be0bdc"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.handle', '"catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.name', '"Catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.8', '"entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.9', '"sections.f50713ee-7c2c-4ee1-882f-40373efb623e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.10', '"entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.11', '"sections.53f0ffd8-c139-492a-aee7-aa9efce64503:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.12', '"entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.13', '"sections.1b633c96-41b8-4483-8799-e6a2ccae24de:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.14', '"entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.15', '"sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.16', '"entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.17', '"sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.18', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.19', '"sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.20', '"entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.21', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.22', '"volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.23', '"globalsets.7f592455-840c-48d2-a416-99d62d097a6b:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.24', '"usergroups.everyone:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.25', '"categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.26', '"gatsby:read"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.27', '"sections.066dc17d-bd30-44a7-8c3c-547610375203:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.28', '"entrytypes.f124a7e8-7872-4014-9550-ff289e764ed3:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.29', '"sections.302f217a-712b-4e95-aaae-d676f147788c:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.30', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.31', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:create"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.32', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.33', '"entrytypes.95e76f85-a82d-45f9-a11b-5b94312c641f:delete"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.34', '"sections.c5438cde-2d06-4c8f-982d-77f00dd0eb57:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.35', '"entrytypes.26af9948-63b1-456e-a6ac-553f5a3ea744:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.36', '"sections.f50713ee-7c2c-4ee1-882f-40373efb623e:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.37', '"entrytypes.702b10c3-ac47-4464-93cc-f7ddda7c0d56:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.38', '"sections.53f0ffd8-c139-492a-aee7-aa9efce64503:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.39', '"entrytypes.f5f578b7-ee25-4e95-a6ff-fd2040336720:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.c5438cde-2d06-4c8f-982d-77f00dd0eb57', '"Catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.26af9948-63b1-456e-a6ac-553f5a3ea744', '"Catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.40', '"sections.1b633c96-41b8-4483-8799-e6a2ccae24de:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.41', '"entrytypes.0802aec5-d8a5-4840-adfe-794b62ef580e:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.42', '"sections.8ca45ec6-7c68-4dbb-be8e-697c487a0c55:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.43', '"entrytypes.8f256bea-8070-4819-a31d-98b8f74a0317:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.44', '"sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.45', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.46', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:create"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.47', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.48', '"entrytypes.c428f464-3bf1-4f91-b39c-11360884c29c:delete"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.handle', '"jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.name', '"Jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.53f0ffd8-c139-492a-aee7-aa9efce64503.type', '"single"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.49', '"sections.9d6b4418-84b8-4034-8b4b-fb4767d4ba56:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.50', '"entrytypes.93ffb49d-4e2b-480c-afd2-0d96e7aa8039:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.51', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.52', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:create"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.53', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.54', '"volumes.a959b3c5-22ed-4707-af5b-00883b180a0e:delete"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.55', '"volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.56', '"volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:create"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.57', '"volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.58', '"volumes.1b434650-e683-41c4-a1f9-f84bf2a58c98:delete"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.59', '"globalsets.7f592455-840c-48d2-a416-99d62d097a6b:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.60', '"categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:edit"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.61', '"categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:save"');
INSERT INTO public.projectconfig (path, value) VALUES ('graphql.schemas.39aad2d7-86f9-4511-8367-37b64c6c3efc.scope.62', '"categorygroups.c0efc2ac-2e91-45ea-8b95-f3f243a893d8:delete"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.53f0ffd8-c139-492a-aee7-aa9efce64503', '"Jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.f5f578b7-ee25-4e95-a6ff-fd2040336720', '"Jobs"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.elements.2.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.fieldLayouts.63365d44-4ef7-4513-9e9c-92fcb6d095a1.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.handle', '"catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.name', '"Catering"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.section', '"c5438cde-2d06-4c8f-982d-77f00dd0eb57"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.26af9948-63b1-456e-a6ac-553f5a3ea744.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.defaultPlacement', '"end"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.enableVersioning', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.handle', '"privacyPolicy"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.name', '"Privacy Policy"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.0.0', '"label"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.0.1', '"Primary entry page"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.1.0', '"urlFormat"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.1.1', '"{url}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.2.0', '"refresh"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.previewTargets.0.__assoc__.2.1', '"1"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.propagationMethod', '"all"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.enabledByDefault', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.hasUrls', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.template', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.siteSettings.bc661644-8fb6-4894-92fb-ba1b7b4be651.uriFormat', '"privacy-policy/{slug}"');
INSERT INTO public.projectconfig (path, value) VALUES ('sections.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d.type', '"channel"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.fieldLayouts.b9631a97-912f-4c16-b80d-c0e92c3e3456.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.handle', '"default"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.hasTitleField', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.name', '"Default"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.section', '"b1d760de-3d49-4d40-9ffc-dc9e9f68b83d"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.titleFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.c428f464-3bf1-4f91-b39c-11360884c29c.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.b1d760de-3d49-4d40-9ffc-dc9e9f68b83d', '"Privacy Policy"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.c428f464-3bf1-4f91-b39c-11360884c29c', '"Default"');
INSERT INTO public.projectconfig (path, value) VALUES ('meta.__names__.8fdf0495-fa4a-4742-b84b-92de96b7ec42', '"main menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.autocapitalize', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.autocomplete', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.autocorrect', 'true');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.class', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.disabled', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.id', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.max', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.min', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.name', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.orientation', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.placeholder', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.readonly', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.requirable', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.size', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.step', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.0.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.fieldUid', '"8fdf0495-fa4a-4742-b84b-92de96b7ec42"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.instructions', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.label', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.required', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\CustomField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.fieldLayouts.1764e955-c45a-47fe-ac35-c1bbd169b1fa.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.handle', '"locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.name', '"Locations"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.section', '"1b633c96-41b8-4483-8799-e6a2ccae24de"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.0802aec5-d8a5-4840-adfe-794b62ef580e.titleTranslationMethod', '"site"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.tip', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.title', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.type', '"craft\\fieldlayoutelements\\EntryTitleField"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.warning', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.elements.1.width', '100');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.name', '"Content"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.fieldLayouts.6ec2524d-3e22-463f-9545-a86da9fe2dc9.tabs.0.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.handle', '"menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.hasTitleField', 'false');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.name', '"Menu"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.section', '"8ca45ec6-7c68-4dbb-be8e-697c487a0c55"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.sortOrder', '1');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.titleFormat', '"{section.name|raw}"');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.titleTranslationKeyFormat', 'null');
INSERT INTO public.projectconfig (path, value) VALUES ('entryTypes.8f256bea-8070-4819-a31d-98b8f74a0317.titleTranslationMethod', '"site"');


--
-- Data for Name: queue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: resourcepaths; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.resourcepaths (hash, path) VALUES ('563d00c5', '@craft/web/assets/installer/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('ee95c346', '@craft/web/assets/login/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('7f85c0ec', '@craft/web/assets/recententries/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('fda0e0bd', '@lib/vue');
INSERT INTO public.resourcepaths (hash, path) VALUES ('523a6b6e', '@craft/web/assets/pluginstore/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('764686b3', '@craft/web/assets/updater/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('5b415b13', '@craft/web/assets/cp/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('d04b43c8', '@lib/axios');
INSERT INTO public.resourcepaths (hash, path) VALUES ('7b5738f', '@lib/d3');
INSERT INTO public.resourcepaths (hash, path) VALUES ('aa2ac4ac', '@lib/element-resize-detector');
INSERT INTO public.resourcepaths (hash, path) VALUES ('34086409', '@lib/garnishjs');
INSERT INTO public.resourcepaths (hash, path) VALUES ('85ba6f59', '@bower/jquery/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('eb46f1c', '@lib/jquery-touch-events');
INSERT INTO public.resourcepaths (hash, path) VALUES ('94359824', '@lib/velocity');
INSERT INTO public.resourcepaths (hash, path) VALUES ('da9c0381', '@lib/jquery-ui');
INSERT INTO public.resourcepaths (hash, path) VALUES ('881237cc', '@lib/jquery.payment');
INSERT INTO public.resourcepaths (hash, path) VALUES ('91053de', '@lib/picturefill');
INSERT INTO public.resourcepaths (hash, path) VALUES ('5d6e7e5a', '@lib/selectize');
INSERT INTO public.resourcepaths (hash, path) VALUES ('e693748b', '@craft/web/assets/craftsupport/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('413f8282', '@craft/web/assets/updateswidget/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('d98649cf', '@craft/web/assets/feed/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a0c56f04', '@craft/web/assets/dashboard/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('11f85220', '@lib/fileupload');
INSERT INTO public.resourcepaths (hash, path) VALUES ('57023ad0', '@lib/xregexp');
INSERT INTO public.resourcepaths (hash, path) VALUES ('214eb037', '@lib/fabric');
INSERT INTO public.resourcepaths (hash, path) VALUES ('1d5b6d37', '@lib/iframe-resizer');
INSERT INTO public.resourcepaths (hash, path) VALUES ('9f1962f7', '@lib/timepicker');
INSERT INTO public.resourcepaths (hash, path) VALUES ('c177a5a7', '@craft/web/assets/craftsupport/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a7877c28', '@craft/web/assets/editentry/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('7fc062ef', '@craft/web/assets/updateswidget/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('fe6298e3', '@craft/web/assets/feed/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('8721be28', '@craft/web/assets/dashboard/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('64c8990', '@craft/web/assets/graphiql/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('75deba42', '@craft/web/assets/pluginstore/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('66fa8f6', '@craft/web/assets/fields/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('1b363d9', '@craft/web/assets/utilities/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('5523eee8', '@craft/web/assets/findreplace/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('3d2355fe', '@craft/web/assets/userpermissions/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f415023', '@craft/web/assets/admintable/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a44e0ef', '@lib/vue');
INSERT INTO public.resourcepaths (hash, path) VALUES ('6b9870f7', '@craft/web/assets/fieldsettings/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('3f4c83b4', '@craft/web/assets/utilities/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('417a2081', '@craft/web/assets/recententries/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('7ca58a3f', '@craft/web/assets/cp/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('27af439a', '@lib/axios');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f05173dd', '@lib/d3');
INSERT INTO public.resourcepaths (hash, path) VALUES ('5dcec4fe', '@lib/element-resize-detector');
INSERT INTO public.resourcepaths (hash, path) VALUES ('c3ec645b', '@lib/garnishjs');
INSERT INTO public.resourcepaths (hash, path) VALUES ('725e6f0b', '@bower/jquery/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('f9506f4e', '@lib/jquery-touch-events');
INSERT INTO public.resourcepaths (hash, path) VALUES ('63d19876', '@lib/velocity');
INSERT INTO public.resourcepaths (hash, path) VALUES ('e51f3f0e', '@craft/web/assets/editsection/dist');
INSERT INTO public.resourcepaths (hash, path) VALUES ('2d7803d3', '@lib/jquery-ui');
INSERT INTO public.resourcepaths (hash, path) VALUES ('7ff6379e', '@lib/jquery.payment');
INSERT INTO public.resourcepaths (hash, path) VALUES ('fef4538c', '@lib/picturefill');
INSERT INTO public.resourcepaths (hash, path) VALUES ('aa8a7e08', '@lib/selectize');
INSERT INTO public.resourcepaths (hash, path) VALUES ('e61c5272', '@lib/fileupload');
INSERT INTO public.resourcepaths (hash, path) VALUES ('a0e63a82', '@lib/xregexp');
INSERT INTO public.resourcepaths (hash, path) VALUES ('fbd665c7', '@lib/prismjs');
INSERT INTO public.resourcepaths (hash, path) VALUES ('d6aab065', '@lib/fabric');
INSERT INTO public.resourcepaths (hash, path) VALUES ('eabf6d65', '@lib/iframe-resizer');
INSERT INTO public.resourcepaths (hash, path) VALUES ('cbe082ab', '@craft/web/assets/dbbackup/dist');


--
-- Data for Name: revisions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (1, 3, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (2, 5, 1, 1, '');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (3, 7, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (4, 9, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (5, 11, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (6, 13, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (7, 15, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (8, 17, 1, 1, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (9, 17, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (10, 15, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (11, 9, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (12, 17, 1, 3, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (13, 15, 1, 3, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (14, 13, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (15, 13, 1, 3, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (16, 13, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (17, 7, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (18, 11, 1, 2, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (19, 11, 1, 3, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (20, 9, 1, 3, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (21, 7, 1, 3, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (22, 13, 1, 5, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (23, 15, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (24, 7, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (25, 17, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (26, 9, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (27, 11, 1, 4, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (28, 13, 1, 6, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (29, 13, 1, 7, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (30, 13, 1, 8, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (31, 13, 1, 9, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (32, 15, 1, 5, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (33, 15, 1, 6, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (34, 17, 1, 5, NULL);
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (35, 17, 1, 6, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (36, 13, 1, 10, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (37, 15, 1, 7, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (38, 7, 1, 5, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (39, 17, 1, 7, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (40, 9, 1, 5, 'Applied “Draft 1”');
INSERT INTO public.revisions (id, "sourceId", "creatorId", num, notes) VALUES (41, 11, 1, 5, 'Applied “Draft 1”');


--
-- Data for Name: searchindex; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'username', 0, 1, ' admin ', '''admin''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'firstname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'lastname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'fullname', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'email', 0, 1, ' dev bluemonkeymakes com ', '''bluemonkeymakes'' ''com'' ''dev''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (1, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (2, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'slug', 0, 1, ' test 1 ', '''1'' ''test''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (3, 'title', 0, 1, ' test 1 ', '''1'' ''test''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (5, 'slug', 0, 1, ' first blog post ', '''blog'' ''first'' ''post''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (5, 'title', 0, 1, ' first blog post ', '''blog'' ''first'' ''post''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (13, 'slug', 0, 1, ' about ', '''about''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (13, 'title', 0, 1, ' about ', '''about''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (15, 'slug', 0, 1, ' catering ', '''catering''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (15, 'title', 0, 1, ' catering ', '''catering''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (7, 'slug', 0, 1, ' home ', '''home''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (7, 'title', 0, 1, ' home ', '''home''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (17, 'slug', 0, 1, ' jobs ', '''jobs''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (17, 'title', 0, 1, ' jobs ', '''jobs''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (9, 'slug', 0, 1, ' locations ', '''locations''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (9, 'title', 0, 1, ' locations ', '''locations''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (11, 'slug', 0, 1, ' menu ', '''menu''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (11, 'title', 0, 1, ' menu ', '''menu''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (19, 'slug', 0, 1, ' main menu ', '''main'' ''menu''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (19, 'title', 0, 1, ' main menu ', '''main'' ''menu''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (31, 'filename', 0, 1, ' gsb breakfast jpg ', '''breakfast'' ''gsb'' ''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (31, 'extension', 0, 1, ' jpg ', '''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (31, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (31, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (31, 'title', 0, 1, ' gsb breakfast ', '''breakfast'' ''gsb''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (32, 'filename', 0, 1, ' gsb hero 1 extended 2 6 jpg ', '''1'' ''2'' ''6'' ''extended'' ''gsb'' ''hero'' ''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (32, 'extension', 0, 1, ' jpg ', '''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (32, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (32, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (32, 'title', 0, 1, ' gsb hero 1 extended 2 6 ', '''1'' ''2'' ''6'' ''extended'' ''gsb'' ''hero''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (33, 'filename', 0, 1, ' milesfortune jackmountain hotdogporkchop 112 of 283 jpg ', '''112'' ''283'' ''hotdogporkchop'' ''jackmountain'' ''jpg'' ''milesfortune'' ''of''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (33, 'extension', 0, 1, ' jpg ', '''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (33, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (33, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (33, 'title', 0, 1, ' milesfortune jackmountain hotdogporkchop 112 of 283 ', '''112'' ''283'' ''hotdogporkchop'' ''jackmountain'' ''milesfortune'' ''of''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (34, 'filename', 0, 1, ' jack mountain meats jpeg ', '''jack'' ''jpeg'' ''meats'' ''mountain''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (34, 'extension', 0, 1, ' jpeg ', '''jpeg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (34, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (34, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (34, 'title', 0, 1, ' jack mountain meats ', '''jack'' ''meats'' ''mountain''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (35, 'filename', 0, 1, ' parfait ice cream png ', '''cream'' ''ice'' ''parfait'' ''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (35, 'extension', 0, 1, ' png ', '''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (35, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (35, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (35, 'title', 0, 1, ' parfait ice cream ', '''cream'' ''ice'' ''parfait''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (36, 'filename', 0, 1, ' john fornander vedlcufli74 unsplash jpg ', '''fornander'' ''john'' ''jpg'' ''unsplash'' ''vedlcufli74''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (36, 'extension', 0, 1, ' jpg ', '''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (36, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (36, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (36, 'title', 0, 1, ' john fornander ved lc uf li74 unsplash ', '''fornander'' ''john'' ''lc'' ''li74'' ''uf'' ''unsplash'' ''ved''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (37, 'filename', 0, 1, ' chad montano gfcyhore48 unsplash jpg ', '''chad'' ''gfcyhore48'' ''jpg'' ''montano'' ''unsplash''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (37, 'extension', 0, 1, ' jpg ', '''jpg''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (37, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (37, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (37, 'title', 0, 1, ' chad montano gfc yho re48 unsplash ', '''chad'' ''gfc'' ''montano'' ''re48'' ''unsplash'' ''yho''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (38, 'filename', 0, 1, ' gsb breakfast png ', '''breakfast'' ''gsb'' ''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (38, 'extension', 0, 1, ' png ', '''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (38, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (38, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (38, 'title', 0, 1, ' gsb breakfast ', '''breakfast'' ''gsb''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (39, 'filename', 0, 1, ' gsb hero 1 extended png ', '''1'' ''extended'' ''gsb'' ''hero'' ''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (39, 'extension', 0, 1, ' png ', '''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (39, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (39, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (39, 'title', 0, 1, ' gsb hero 1 extended ', '''1'' ''extended'' ''gsb'' ''hero''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (40, 'filename', 0, 1, ' gsb breakfast png ', '''breakfast'' ''gsb'' ''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (40, 'extension', 0, 1, ' png ', '''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (40, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (40, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (40, 'title', 0, 1, ' gsb breakfast ', '''breakfast'' ''gsb''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (41, 'filename', 0, 1, ' gsb hero 1 extended png ', '''1'' ''extended'' ''gsb'' ''hero'' ''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (41, 'extension', 0, 1, ' png ', '''png''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (41, 'kind', 0, 1, ' image ', '''image''');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (41, 'slug', 0, 1, '', '');
INSERT INTO public.searchindex ("elementId", attribute, "fieldId", "siteId", keywords, keywords_vector) VALUES (41, 'title', 0, 1, ' gsb hero 1 extended ', '''1'' ''extended'' ''gsb'' ''hero''');


--
-- Data for Name: sections; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, NULL, 'test-1', 'test1', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 18:50:36', '2021-08-19 18:50:36', NULL, '9d6b4418-84b8-4034-8b4b-fb4767d4ba56');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, NULL, 'Blog', 'blog', 'channel', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 19:01:51', '2021-08-19 19:01:51', NULL, '302f217a-712b-4e95-aaae-d676f147788c');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, NULL, 'Home', 'home', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:22:50', '2021-08-19 23:22:50', NULL, 'f50713ee-7c2c-4ee1-882f-40373efb623e');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (4, NULL, 'Locations', 'locations', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:23:09', '2021-08-19 23:23:09', NULL, '1b633c96-41b8-4483-8799-e6a2ccae24de');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (5, NULL, 'Menu', 'menu', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:23:21', '2021-08-19 23:23:21', NULL, '8ca45ec6-7c68-4dbb-be8e-697c487a0c55');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (6, NULL, 'About', 'about', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:23:34', '2021-08-19 23:23:34', NULL, '066dc17d-bd30-44a7-8c3c-547610375203');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (7, NULL, 'Catering', 'catering', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:24:22', '2021-08-19 23:24:22', NULL, 'c5438cde-2d06-4c8f-982d-77f00dd0eb57');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (8, NULL, 'Jobs', 'jobs', 'single', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:24:35', '2021-08-19 23:24:35', NULL, '53f0ffd8-c139-492a-aee7-aa9efce64503');
INSERT INTO public.sections (id, "structureId", name, handle, type, "enableVersioning", "propagationMethod", "defaultPlacement", "previewTargets", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (9, NULL, 'Privacy Policy', 'privacyPolicy', 'channel', true, 'all', 'end', '[{"label":"Primary entry page","urlFormat":"{url}","refresh":"1"}]', '2021-08-19 23:25:00', '2021-08-19 23:25:00', NULL, 'b1d760de-3d49-4d40-9ffc-dc9e9f68b83d');


--
-- Data for Name: sections_sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (1, 1, 1, true, 'test-1', 'test-1/_entry', true, '2021-08-19 18:50:36', '2021-08-19 18:50:36', 'bed7d37a-82d3-44e3-adfe-06865223c062');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (2, 2, 1, true, 'blog/{slug}', NULL, true, '2021-08-19 19:01:51', '2021-08-19 19:01:51', 'a9cd0ae8-27ee-44f0-9c24-9c1f9b269f7c');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (3, 3, 1, true, 'home', NULL, true, '2021-08-19 23:22:50', '2021-08-19 23:22:50', '4703fed4-ffcd-42ab-aa51-ad307383c37c');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (4, 4, 1, true, 'locations', NULL, true, '2021-08-19 23:23:09', '2021-08-19 23:23:09', 'd925a06d-e18f-43b6-8d56-a1e05fb74ce3');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (5, 5, 1, true, 'menu', NULL, true, '2021-08-19 23:23:21', '2021-08-19 23:23:21', '77e076e5-bd39-4a48-a766-2707e86031ac');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (6, 6, 1, true, 'about', NULL, true, '2021-08-19 23:23:34', '2021-08-19 23:23:34', '309b11c2-e7d3-430d-9f03-13d18083dd46');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (7, 7, 1, true, 'catering', NULL, true, '2021-08-19 23:24:22', '2021-08-19 23:24:22', '1a101658-4654-4729-9b70-3a00200cf01f');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (8, 8, 1, true, 'jobs', NULL, true, '2021-08-19 23:24:35', '2021-08-19 23:24:35', '6ef7886a-247d-457d-b1fb-b8cdc402200a');
INSERT INTO public.sections_sites (id, "sectionId", "siteId", "hasUrls", "uriFormat", template, "enabledByDefault", "dateCreated", "dateUpdated", uid) VALUES (9, 9, 1, true, 'privacy-policy/{slug}', NULL, true, '2021-08-19 23:25:00', '2021-08-19 23:25:00', 'a3ce1163-fec7-45b1-81be-d9a0aa5e3525');


--
-- Data for Name: sequences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shunnedmessages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sitegroups; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sitegroups (id, name, "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 'craft-cms', '2021-08-19 17:44:41', '2021-08-19 17:44:41', NULL, '47719cc6-ab00-40eb-9b8e-9cc2e4fd0457');


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sites (id, "groupId", "primary", enabled, name, handle, language, "hasUrls", "baseUrl", "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, true, true, 'craft-cms', 'default', 'en-US', true, '$PRIMARY_SITE_URL', 1, '2021-08-19 17:44:41', '2021-08-19 17:44:41', NULL, 'bc661644-8fb6-4894-92fb-ba1b7b4be651');


--
-- Data for Name: structureelements; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.structureelements (id, "structureId", "elementId", root, lft, rgt, level, "dateCreated", "dateUpdated", uid) VALUES (1, 1, NULL, 1, 1, 4, 0, '2021-08-20 01:28:17', '2021-08-20 01:28:17', '6fee910c-bf5d-4c8c-9245-540842e6aed7');
INSERT INTO public.structureelements (id, "structureId", "elementId", root, lft, rgt, level, "dateCreated", "dateUpdated", uid) VALUES (2, 1, 19, 1, 2, 3, 1, '2021-08-20 01:28:17', '2021-08-20 01:28:17', 'c18f0d27-5d90-4c2c-91ea-9486746d6bff');


--
-- Data for Name: structures; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.structures (id, "maxLevels", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, '2021-08-19 22:21:34', '2021-08-19 22:21:34', NULL, '901f912e-4fef-41a7-841c-5c6e125dcf4d');


--
-- Data for Name: systemmessages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: taggroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: usergroups_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions_usergroups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpermissions_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: userpreferences; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.userpreferences ("userId", preferences) VALUES (1, '{"language":"en-US"}');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.users (id, username, "photoId", "firstName", "lastName", email, password, admin, locked, suspended, pending, "lastLoginDate", "lastLoginAttemptIp", "invalidLoginWindowStart", "invalidLoginCount", "lastInvalidLoginDate", "lockoutDate", "hasDashboard", "verificationCode", "verificationCodeIssuedDate", "unverifiedEmail", "passwordResetRequired", "lastPasswordChangeDate", "dateCreated", "dateUpdated", uid) VALUES (1, 'admin', NULL, NULL, NULL, 'dev@bluemonkeymakes.com', '$2y$13$ajFGnAvxVWm6TmJR6/h.T.gx9wEhDTlfIG4n3SQlMd0A/ydZf75.K', true, false, false, false, '2021-08-20 21:31:20', NULL, NULL, NULL, '2021-08-19 22:20:44', NULL, true, NULL, NULL, NULL, false, '2021-08-19 17:44:42', '2021-08-19 17:44:42', '2021-08-20 21:31:20', '2edf07a8-167a-41eb-840a-052ca5bb7695');


--
-- Data for Name: volumefolders; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (1, NULL, 1, 'images', '', '2021-08-19 18:33:27', '2021-08-19 18:33:27', '6cfa255d-a7db-48c6-9e24-6c38ca18aec3');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (2, NULL, NULL, 'Temporary source', NULL, '2021-08-19 19:06:56', '2021-08-19 19:06:56', '9e9e838d-dd85-4dff-afb4-198d759565c7');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (3, 2, NULL, 'user_1', 'user_1/', '2021-08-19 19:06:56', '2021-08-19 19:06:56', '95630efc-9245-4fcb-8d59-e0d11b4ab470');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (4, NULL, 2, 'Blog', '', '2021-08-19 19:08:08', '2021-08-19 19:08:08', '268ab9cb-f51e-4bc3-932d-2d2568dc3211');
INSERT INTO public.volumefolders (id, "parentId", "volumeId", name, path, "dateCreated", "dateUpdated", uid) VALUES (5, NULL, 3, 'featured-images', '', '2021-08-20 03:54:51', '2021-08-20 03:54:51', '1e96529b-337b-499f-823d-a6e2ed486a6b');


--
-- Data for Name: volumes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.volumes (id, "fieldLayoutId", name, handle, type, "hasUrls", url, "titleTranslationMethod", "titleTranslationKeyFormat", settings, "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (1, 1, 'images', 'images', 'craft\volumes\Local', true, '@web/assets/images', 'site', NULL, '{"path":"@webroot/assets/images"}', 1, '2021-08-19 18:33:27', '2021-08-19 18:33:27', '2021-08-19 19:07:20', '5c1a2784-1da6-4913-bdbd-3c5b6066fa66');
INSERT INTO public.volumes (id, "fieldLayoutId", name, handle, type, "hasUrls", url, "titleTranslationMethod", "titleTranslationKeyFormat", settings, "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (2, 5, 'Blog', 'blog', 'craft\volumes\Local', true, '@web/assets/blog', 'site', NULL, '{"path":"@webroot/assets/blog"}', 2, '2021-08-19 19:08:08', '2021-08-19 19:08:08', NULL, 'a959b3c5-22ed-4707-af5b-00883b180a0e');
INSERT INTO public.volumes (id, "fieldLayoutId", name, handle, type, "hasUrls", url, "titleTranslationMethod", "titleTranslationKeyFormat", settings, "sortOrder", "dateCreated", "dateUpdated", "dateDeleted", uid) VALUES (3, NULL, 'featured-images', 'featuredImages', 'craft\volumes\Local', true, '@web/assets/images', 'site', NULL, '{"path":"@webroot/assets/images"}', 3, '2021-08-20 03:54:51', '2021-08-20 03:54:51', NULL, '1b434650-e683-41c4-a1f9-f84bf2a58c98');


--
-- Data for Name: widgets; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (1, 1, 'craft\widgets\RecentEntries', 1, NULL, '{"siteId":1,"section":"*","limit":10}', true, '2021-08-19 17:47:25', '2021-08-19 17:47:25', 'c0475c1d-5b07-47df-85a4-923a3221f8a1');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (2, 1, 'craft\widgets\CraftSupport', 2, NULL, '[]', true, '2021-08-19 17:47:25', '2021-08-19 17:47:25', '0b6bded7-c1ee-4ad8-a790-0eebc3dcf88b');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (3, 1, 'craft\widgets\Updates', 3, NULL, '[]', true, '2021-08-19 17:47:25', '2021-08-19 17:47:25', '7016062c-9c91-4dcc-a645-26176cb046ef');
INSERT INTO public.widgets (id, "userId", type, "sortOrder", colspan, settings, enabled, "dateCreated", "dateUpdated", uid) VALUES (4, 1, 'craft\widgets\Feed', 4, NULL, '{"url":"https://craftcms.com/news.rss","title":"Craft News","limit":5}', true, '2021-08-19 17:47:25', '2021-08-19 17:47:25', 'ada6d9fa-e7f1-4053-af2e-1f649314e056');


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: assetindexdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assetindexdata_id_seq', 1, false);


--
-- Name: assettransformindex_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assettransformindex_id_seq', 1, false);


--
-- Name: assettransforms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assettransforms_id_seq', 1, false);


--
-- Name: categorygroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorygroups_id_seq', 1, true);


--
-- Name: categorygroups_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categorygroups_sites_id_seq', 1, true);


--
-- Name: content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.content_id_seq', 83, true);


--
-- Name: craftidtokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.craftidtokens_id_seq', 1, false);


--
-- Name: deprecationerrors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deprecationerrors_id_seq', 1, false);


--
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drafts_id_seq', 21, true);


--
-- Name: elementindexsettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elementindexsettings_id_seq', 1, false);


--
-- Name: elements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elements_id_seq', 83, true);


--
-- Name: elements_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.elements_sites_id_seq', 83, true);


--
-- Name: entrytypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.entrytypes_id_seq', 10, true);


--
-- Name: fieldgroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldgroups_id_seq', 2, true);


--
-- Name: fieldlayoutfields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayoutfields_id_seq', 17, true);


--
-- Name: fieldlayouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayouts_id_seq', 13, true);


--
-- Name: fieldlayouttabs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fieldlayouttabs_id_seq', 28, true);


--
-- Name: fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fields_id_seq', 4, true);


--
-- Name: gatsby_deletedelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gatsby_deletedelements_id_seq', 24, true);


--
-- Name: globalsets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.globalsets_id_seq', 1, false);


--
-- Name: gqlschemas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gqlschemas_id_seq', 2, true);


--
-- Name: gqltokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gqltokens_id_seq', 2, true);


--
-- Name: info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.info_id_seq', 1, false);


--
-- Name: matrixblocktypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matrixblocktypes_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.migrations_id_seq', 193, true);


--
-- Name: plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plugins_id_seq', 1, true);


--
-- Name: queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queue_id_seq', 211, true);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relations_id_seq', 1, false);


--
-- Name: revisions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.revisions_id_seq', 41, true);


--
-- Name: sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_id_seq', 9, true);


--
-- Name: sections_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sections_sites_id_seq', 9, true);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 7, true);


--
-- Name: shunnedmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shunnedmessages_id_seq', 1, false);


--
-- Name: sitegroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sitegroups_id_seq', 1, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sites_id_seq', 1, true);


--
-- Name: structureelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.structureelements_id_seq', 2, true);


--
-- Name: structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.structures_id_seq', 1, true);


--
-- Name: systemmessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.systemmessages_id_seq', 1, false);


--
-- Name: taggroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggroups_id_seq', 1, false);


--
-- Name: templatecacheelements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecacheelements_id_seq', 1, false);


--
-- Name: templatecachequeries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecachequeries_id_seq', 1, false);


--
-- Name: templatecaches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.templatecaches_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 1, false);


--
-- Name: usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usergroups_id_seq', 1, false);


--
-- Name: usergroups_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.usergroups_users_id_seq', 1, false);


--
-- Name: userpermissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_id_seq', 1, false);


--
-- Name: userpermissions_usergroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_usergroups_id_seq', 1, false);


--
-- Name: userpermissions_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.userpermissions_users_id_seq', 1, false);


--
-- Name: userpreferences_userId_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."userpreferences_userId_seq"', 1, false);


--
-- Name: volumefolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.volumefolders_id_seq', 5, true);


--
-- Name: volumes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.volumes_id_seq', 3, true);


--
-- Name: widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.widgets_id_seq', 4, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: assetindexdata assetindexdata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT assetindexdata_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: assettransformindex assettransformindex_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransformindex
    ADD CONSTRAINT assettransformindex_pkey PRIMARY KEY (id);


--
-- Name: assettransforms assettransforms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assettransforms
    ADD CONSTRAINT assettransforms_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categorygroups categorygroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT categorygroups_pkey PRIMARY KEY (id);


--
-- Name: categorygroups_sites categorygroups_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT categorygroups_sites_pkey PRIMARY KEY (id);


--
-- Name: changedattributes changedattributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT changedattributes_pkey PRIMARY KEY ("elementId", "siteId", attribute);


--
-- Name: changedfields changedfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT changedfields_pkey PRIMARY KEY ("elementId", "siteId", "fieldId");


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: craftidtokens craftidtokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT craftidtokens_pkey PRIMARY KEY (id);


--
-- Name: deprecationerrors deprecationerrors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deprecationerrors
    ADD CONSTRAINT deprecationerrors_pkey PRIMARY KEY (id);


--
-- Name: drafts drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- Name: elementindexsettings elementindexsettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elementindexsettings
    ADD CONSTRAINT elementindexsettings_pkey PRIMARY KEY (id);


--
-- Name: elements elements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT elements_pkey PRIMARY KEY (id);


--
-- Name: elements_sites elements_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT elements_sites_pkey PRIMARY KEY (id);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: entrytypes entrytypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT entrytypes_pkey PRIMARY KEY (id);


--
-- Name: fieldgroups fieldgroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldgroups
    ADD CONSTRAINT fieldgroups_pkey PRIMARY KEY (id);


--
-- Name: fieldlayoutfields fieldlayoutfields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fieldlayoutfields_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouts fieldlayouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouts
    ADD CONSTRAINT fieldlayouts_pkey PRIMARY KEY (id);


--
-- Name: fieldlayouttabs fieldlayouttabs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fieldlayouttabs_pkey PRIMARY KEY (id);


--
-- Name: fields fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fields_pkey PRIMARY KEY (id);


--
-- Name: gatsby_deletedelements gatsby_deletedelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gatsby_deletedelements
    ADD CONSTRAINT gatsby_deletedelements_pkey PRIMARY KEY (id);


--
-- Name: globalsets globalsets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT globalsets_pkey PRIMARY KEY (id);


--
-- Name: gqlschemas gqlschemas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqlschemas
    ADD CONSTRAINT gqlschemas_pkey PRIMARY KEY (id);


--
-- Name: gqltokens gqltokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT gqltokens_pkey PRIMARY KEY (id);


--
-- Name: info info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.info
    ADD CONSTRAINT info_pkey PRIMARY KEY (id);


--
-- Name: matrixblocks matrixblocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT matrixblocks_pkey PRIMARY KEY (id);


--
-- Name: matrixblocktypes matrixblocktypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT matrixblocktypes_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: searchindex pk_ibqfaejfbtcyyyfuhikpcmevxmibaxwetohk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.searchindex
    ADD CONSTRAINT pk_ibqfaejfbtcyyyfuhikpcmevxmibaxwetohk PRIMARY KEY ("elementId", attribute, "fieldId", "siteId");


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: projectconfig projectconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projectconfig
    ADD CONSTRAINT projectconfig_pkey PRIMARY KEY (path);


--
-- Name: queue queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queue
    ADD CONSTRAINT queue_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: resourcepaths resourcepaths_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resourcepaths
    ADD CONSTRAINT resourcepaths_pkey PRIMARY KEY (hash);


--
-- Name: revisions revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT revisions_pkey PRIMARY KEY (id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: sections_sites sections_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT sections_sites_pkey PRIMARY KEY (id);


--
-- Name: sequences sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sequences
    ADD CONSTRAINT sequences_pkey PRIMARY KEY (name);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shunnedmessages shunnedmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT shunnedmessages_pkey PRIMARY KEY (id);


--
-- Name: sitegroups sitegroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sitegroups
    ADD CONSTRAINT sitegroups_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: structureelements structureelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT structureelements_pkey PRIMARY KEY (id);


--
-- Name: structures structures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structures
    ADD CONSTRAINT structures_pkey PRIMARY KEY (id);


--
-- Name: systemmessages systemmessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.systemmessages
    ADD CONSTRAINT systemmessages_pkey PRIMARY KEY (id);


--
-- Name: taggroups taggroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT taggroups_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: templatecacheelements templatecacheelements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT templatecacheelements_pkey PRIMARY KEY (id);


--
-- Name: templatecachequeries templatecachequeries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries
    ADD CONSTRAINT templatecachequeries_pkey PRIMARY KEY (id);


--
-- Name: templatecaches templatecaches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches
    ADD CONSTRAINT templatecaches_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: usergroups usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups
    ADD CONSTRAINT usergroups_pkey PRIMARY KEY (id);


--
-- Name: usergroups_users usergroups_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT usergroups_users_pkey PRIMARY KEY (id);


--
-- Name: userpermissions userpermissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions
    ADD CONSTRAINT userpermissions_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_usergroups userpermissions_usergroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT userpermissions_usergroups_pkey PRIMARY KEY (id);


--
-- Name: userpermissions_users userpermissions_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT userpermissions_users_pkey PRIMARY KEY (id);


--
-- Name: userpreferences userpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT userpreferences_pkey PRIMARY KEY ("userId");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: volumefolders volumefolders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT volumefolders_pkey PRIMARY KEY (id);


--
-- Name: volumes volumes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT volumes_pkey PRIMARY KEY (id);


--
-- Name: widgets widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT widgets_pkey PRIMARY KEY (id);


--
-- Name: idx_aaazqdilqjcyrpypaifjjsqopmzebxmaecua; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aaazqdilqjcyrpypaifjjsqopmzebxmaecua ON public.widgets USING btree ("userId");


--
-- Name: idx_acfekksukhczdowfiyfncngnjihgcmbfqcpc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_acfekksukhczdowfiyfncngnjihgcmbfqcpc ON public.fieldlayouts USING btree (type);


--
-- Name: idx_aemmowovqjhuspotfthsighrclpmwfmyhhfj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aemmowovqjhuspotfthsighrclpmwfmyhhfj ON public.elements USING btree ("dateDeleted");


--
-- Name: idx_afadosesuwygibqhejkctatpdftlmjojqdnn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_afadosesuwygibqhejkctatpdftlmjojqdnn ON public.matrixblocks USING btree ("sortOrder");


--
-- Name: idx_agaimwknvpnmrktuootvfdaelzqvjsdouipr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agaimwknvpnmrktuootvfdaelzqvjsdouipr ON public.assets USING btree (filename, "folderId");


--
-- Name: idx_aqrbvrnfllfbztqttkxiaqujzbvctuynyggk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aqrbvrnfllfbztqttkxiaqujzbvctuynyggk ON public.assets USING btree ("folderId");


--
-- Name: idx_asqkfmiraftlpsuktgwtorreraunpffhhemo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_asqkfmiraftlpsuktgwtorreraunpffhhemo ON public.content USING btree (title);


--
-- Name: idx_atjljoezaomqserpqalvxlnisetdheagpzfp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_atjljoezaomqserpqalvxlnisetdheagpzfp ON public.gqltokens USING btree ("accessToken");


--
-- Name: idx_awwxzokovltwkfqubtsuyluekrljkhvrllms; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_awwxzokovltwkfqubtsuyluekrljkhvrllms ON public.relations USING btree ("targetId");


--
-- Name: idx_befklnaefkalmdtsavcshikdvtyertsizbcv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_befklnaefkalmdtsavcshikdvtyertsizbcv ON public.usergroups_users USING btree ("userId");


--
-- Name: idx_bgpahqqmldplfufvwvimoyevcoylfwhbirlz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bgpahqqmldplfufvwvimoyevcoylfwhbirlz ON public.entries USING btree ("expiryDate");


--
-- Name: idx_blatprmfwfxmjttxovdaeculjuwebqvdhkmv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_blatprmfwfxmjttxovdaeculjuwebqvdhkmv ON public.volumes USING btree (handle);


--
-- Name: idx_bzdxlbzgeyfwbzmbzhqlbbciocufunjxjmmr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bzdxlbzgeyfwbzmbzhqlbbciocufunjxjmmr ON public.announcements USING btree ("dateRead");


--
-- Name: idx_bzitmtiiulwyzpnlbjtsawmsmqajazvoeiap; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bzitmtiiulwyzpnlbjtsawmsmqajazvoeiap ON public.sessions USING btree ("dateUpdated");


--
-- Name: idx_cancftkzagegenrhfuvzykegddclibsrbgsa; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cancftkzagegenrhfuvzykegddclibsrbgsa ON public.relations USING btree ("fieldId", "sourceId", "sourceSiteId", "targetId");


--
-- Name: idx_cinjooiyxumvediajklxcvdexmhkxwjpvyln; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cinjooiyxumvediajklxcvdexmhkxwjpvyln ON public.userpermissions_usergroups USING btree ("groupId");


--
-- Name: idx_cirxtreveaiwltftmnmmmkmwdkimxkltiffx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cirxtreveaiwltftmnmmmkmwdkimxkltiffx ON public.elements USING btree (archived, "dateCreated");


--
-- Name: idx_cswvaoeejrerveigvixzizamflydergbsrir; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cswvaoeejrerveigvixzizamflydergbsrir ON public.volumefolders USING btree (name, "parentId", "volumeId");


--
-- Name: idx_cxskooujykspcnmsrqvvflbsiugptdowrrlo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cxskooujykspcnmsrqvvflbsiugptdowrrlo ON public.sections_sites USING btree ("sectionId", "siteId");


--
-- Name: idx_dfxqwtxflpxvqcspbsqyybcwlzgttihkqrks; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_dfxqwtxflpxvqcspbsqyybcwlzgttihkqrks ON public.systemmessages USING btree (key, language);


--
-- Name: idx_dodysouwkehovsgwogrkqubfxowplbkhzemg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_dodysouwkehovsgwogrkqubfxowplbkhzemg ON public.plugins USING btree (handle);


--
-- Name: idx_dofsxexcjyftcfbbhaqhrjjkcxhzrfoqkfvg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dofsxexcjyftcfbbhaqhrjjkcxhzrfoqkfvg ON public.sitegroups USING btree (name);


--
-- Name: idx_dxrmcskbxdrukmymvfiqjweibkdrwyycmxwm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dxrmcskbxdrukmymvfiqjweibkdrwyycmxwm ON public.matrixblocktypes USING btree (name, "fieldId");


--
-- Name: idx_dzobedqmaiqxonovdbhdfcqpqqocvgicxtwy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dzobedqmaiqxonovdbhdfcqpqqocvgicxtwy ON public.elements USING btree (type);


--
-- Name: idx_eftdqlzgyzrncrmysmjhtuoakvpmfspobzrw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eftdqlzgyzrncrmysmjhtuoakvpmfspobzrw ON public.users USING btree ("verificationCode");


--
-- Name: idx_emehdrkrjfnpnbhfqjtnrpnejiupusgrughm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_emehdrkrjfnpnbhfqjtnrpnejiupusgrughm ON public.sessions USING btree (uid);


--
-- Name: idx_emskzfriytrpbuwjnqgkiylvrxyivxzezses; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_emskzfriytrpbuwjnqgkiylvrxyivxzezses ON public.entrytypes USING btree ("fieldLayoutId");


--
-- Name: idx_eqevvxgnaujkrelegkvfqkowmrqxzligvazz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eqevvxgnaujkrelegkvfqkowmrqxzligvazz ON public.content USING btree ("siteId");


--
-- Name: idx_ernuvwxtjockcblchpldamyoezhvebxdhexl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ernuvwxtjockcblchpldamyoezhvebxdhexl ON public.globalsets USING btree ("fieldLayoutId");


--
-- Name: idx_etzqogdcxcgwexqtovvpddlewsgdzrbfubal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_etzqogdcxcgwexqtovvpddlewsgdzrbfubal ON public.entrytypes USING btree (handle, "sectionId");


--
-- Name: idx_ewssijividkftrhvzhgpxabvvzqtrduiifgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ewssijividkftrhvzhgpxabvvzqtrduiifgm ON public.matrixblocktypes USING btree ("fieldId");


--
-- Name: idx_eyjwvzelugchhebebztjrspfajrlzvsatyxa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_eyjwvzelugchhebebztjrspfajrlzvsatyxa ON public.relations USING btree ("sourceId");


--
-- Name: idx_famqwxurogmmuzutasbjqdpqigmeogcsiqhm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_famqwxurogmmuzutasbjqdpqigmeogcsiqhm ON public.fields USING btree (handle, context);


--
-- Name: idx_fljjfgrmvyoksdoycrsynnvfiwsrxxxsnssy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fljjfgrmvyoksdoycrsynnvfiwsrxxxsnssy ON public.templatecacheelements USING btree ("cacheId");


--
-- Name: idx_fswwkqqgeqvrxzvehjvpymckvqxpelwyhwsp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fswwkqqgeqvrxzvehjvpymckvqxpelwyhwsp ON public.drafts USING btree ("creatorId", provisional);


--
-- Name: idx_ftnmhvczjzvxaeicixrgkdhbixfxrqsxwucg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ftnmhvczjzvxaeicixrgkdhbixfxrqsxwucg ON public.structureelements USING btree (level);


--
-- Name: idx_goslsuiqkfsjnvbriqgqnwaqaquuemkpdzar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_goslsuiqkfsjnvbriqgqnwaqaquuemkpdzar ON public.sections USING btree (name);


--
-- Name: idx_gttipdcrtsjghsqzttqwlfmrslifkyodkhcv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gttipdcrtsjghsqzttqwlfmrslifkyodkhcv ON public.assets USING btree ("volumeId");


--
-- Name: idx_gxxqyutgiaogncdltigjljfgeggokantouwt; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gxxqyutgiaogncdltigjljfgeggokantouwt ON public.fieldlayoutfields USING btree ("layoutId", "fieldId");


--
-- Name: idx_gxzbwqglkssessfjavhzzgbagcfnmzfurdlr; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gxzbwqglkssessfjavhzzgbagcfnmzfurdlr ON public.content USING btree ("elementId", "siteId");


--
-- Name: idx_hhzxoosmzbejagvvxwferwkvheggtiiniomx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hhzxoosmzbejagvvxwferwkvheggtiiniomx ON public.assettransforms USING btree (handle);


--
-- Name: idx_hnheotxfcgcynncwmzasysxpswddmdfjtuak; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hnheotxfcgcynncwmzasysxpswddmdfjtuak ON public.elements USING btree (archived, "dateDeleted", "draftId", "revisionId");


--
-- Name: idx_hpotqclhzulbggtbfyuhuympvaqpzwxxjnym; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hpotqclhzulbggtbfyuhuympvaqpzwxxjnym ON public.volumefolders USING btree ("parentId");


--
-- Name: idx_hxkpxdeqfrbtfhosejlvtafinuupldouapsy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hxkpxdeqfrbtfhosejlvtafinuupldouapsy ON public.entrytypes USING btree (name, "sectionId");


--
-- Name: idx_hyjxifwjvaltokjyvmmqdqrtxaoxlhrrmvai; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hyjxifwjvaltokjyvmmqdqrtxaoxlhrrmvai ON public.volumes USING btree ("fieldLayoutId");


--
-- Name: idx_hzgrdlxqdavyqbeaubbcjcnequazfaxpbkfx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hzgrdlxqdavyqbeaubbcjcnequazfaxpbkfx ON public.changedfields USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_iavnelshsolycbtrulyfhrkdzhyjsefuzihj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iavnelshsolycbtrulyfhrkdzhyjsefuzihj ON public.fieldlayouttabs USING btree ("layoutId");


--
-- Name: idx_ildmakbmhffylczmmbfqshzhkeevqlinjajc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ildmakbmhffylczmmbfqshzhkeevqlinjajc ON public.fieldlayouts USING btree ("dateDeleted");


--
-- Name: idx_irqivmyljtefuzynayjiyafhwbydkyroqtcw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_irqivmyljtefuzynayjiyafhwbydkyroqtcw ON public.usergroups USING btree (handle);


--
-- Name: idx_itafxogxqvlpdcoajunkpnwsjkcoyymalnqd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_itafxogxqvlpdcoajunkpnwsjkcoyymalnqd ON public.fields USING btree (context);


--
-- Name: idx_iyxkhtltfiwivktvcnyqyjcnphhixkweumnn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_iyxkhtltfiwivktvcnyqyjcnphhixkweumnn ON public.templatecaches USING btree ("cacheKey", "siteId", "expiryDate", path);


--
-- Name: idx_izqnxarobohqobjomrjrgapzfxaguqjmhqvc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_izqnxarobohqobjomrjrgapzfxaguqjmhqvc ON public.users USING btree (lower((email)::text));


--
-- Name: idx_jjvqpzrdwweuafviksqyzhilcafqzcozxxtv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jjvqpzrdwweuafviksqyzhilcafqzcozxxtv ON public.fieldlayoutfields USING btree ("sortOrder");


--
-- Name: idx_jmndaqjlrackpaffmveupyixazddblsouboi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jmndaqjlrackpaffmveupyixazddblsouboi ON public.fieldgroups USING btree (name);


--
-- Name: idx_jslhgluglumqcgpzjmrhlmicclxdzytuqrzq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_jslhgluglumqcgpzjmrhlmicclxdzytuqrzq ON public.categorygroups_sites USING btree ("groupId", "siteId");


--
-- Name: idx_juofosqfrphwpyxpkcqmstyfdtgtemqnfglg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_juofosqfrphwpyxpkcqmstyfdtgtemqnfglg ON public.templatecachequeries USING btree (type);


--
-- Name: idx_jvgskrxchxcdylmfhphvhgvcjwfeqwrsnntt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jvgskrxchxcdylmfhphvhgvcjwfeqwrsnntt ON public.queue USING btree (channel, fail, "timeUpdated", delay);


--
-- Name: idx_kafzrgxeubythshkzoogqjhrgfgaqkzywffa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kafzrgxeubythshkzoogqjhrgfgaqkzywffa ON public.sessions USING btree (token);


--
-- Name: idx_keggstrqeypbtgxbfrlluezlzulnwsktjsaa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_keggstrqeypbtgxbfrlluezlzulnwsktjsaa ON public.entries USING btree ("authorId");


--
-- Name: idx_khqnhvcekhvxbgfkbmloecczpefnteddaaow; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_khqnhvcekhvxbgfkbmloecczpefnteddaaow ON public.gqltokens USING btree (name);


--
-- Name: idx_kzsomffzftnkfhrvxfwvkijcokvpmluexili; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kzsomffzftnkfhrvxfwvkijcokvpmluexili ON public.assetindexdata USING btree ("sessionId", "volumeId");


--
-- Name: idx_leftdauzswnaslnqzqjnbisvvjiaxdhzhjvm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_leftdauzswnaslnqzqjnbisvvjiaxdhzhjvm ON public.matrixblocks USING btree ("ownerId");


--
-- Name: idx_lnrlzrorxplvgupqdtijxeqbgqwthlwbjehw; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lnrlzrorxplvgupqdtijxeqbgqwthlwbjehw ON public.taggroups USING btree ("dateDeleted");


--
-- Name: idx_lofyskigbqyvvcmyayazgjdmxrphfgwdgxho; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lofyskigbqyvvcmyayazgjdmxrphfgwdgxho ON public.structureelements USING btree (rgt);


--
-- Name: idx_loqmakpvlmxearwzghrikpddlsznbejkksxw; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_loqmakpvlmxearwzghrikpddlsznbejkksxw ON public.elementindexsettings USING btree (type);


--
-- Name: idx_lotdhyddwyzytyoewptqccirqorirjcyqvaq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lotdhyddwyzytyoewptqccirqorirjcyqvaq ON public.sections USING btree ("dateDeleted");


--
-- Name: idx_lpnvqxlggxekkmezrlgovqtcdnhfbgkfrdkv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lpnvqxlggxekkmezrlgovqtcdnhfbgkfrdkv ON public.sessions USING btree ("userId");


--
-- Name: idx_lqdeemjdcuwiwkewncruodjmgjoqnloajpyj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lqdeemjdcuwiwkewncruodjmgjoqnloajpyj ON public.users USING btree (uid);


--
-- Name: idx_lrugquecjunehwusyvlxcbxqhkywjfjtndci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lrugquecjunehwusyvlxcbxqhkywjfjtndci ON public.searchindex USING gin (keywords_vector) WITH (fastupdate=yes);


--
-- Name: idx_lsyavkwssdqrpqkfkeaiwamwfglzraxronss; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lsyavkwssdqrpqkfkeaiwamwfglzraxronss ON public.tokens USING btree ("expiryDate");


--
-- Name: idx_lwrtfcfjmrydetkqovvfwmqhacdxlsamddpr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lwrtfcfjmrydetkqovvfwmqhacdxlsamddpr ON public.sites USING btree (handle);


--
-- Name: idx_lxbytxaestgbfbcojjaznrpxapqhljzpclel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lxbytxaestgbfbcojjaznrpxapqhljzpclel ON public.entrytypes USING btree ("dateDeleted");


--
-- Name: idx_lzntkktxhpwswdmzirbeuqwsprhdadeubghf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_lzntkktxhpwswdmzirbeuqwsprhdadeubghf ON public.structureelements USING btree (root);


--
-- Name: idx_maoprfwuymediebrdhioqccaymuvzawiplox; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_maoprfwuymediebrdhioqccaymuvzawiplox ON public.shunnedmessages USING btree ("userId", message);


--
-- Name: idx_mdivjpshfexnoeccshvgldndoykxfpgoecsg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mdivjpshfexnoeccshvgldndoykxfpgoecsg ON public.categorygroups USING btree ("structureId");


--
-- Name: idx_miotdqnyerlmzbkohhkgpmbqjswqyvkhidmf; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_miotdqnyerlmzbkohhkgpmbqjswqyvkhidmf ON public.deprecationerrors USING btree (key, fingerprint);


--
-- Name: idx_nqtmkmjvwdqysreaomxkvpaudzgxppjscwne; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_nqtmkmjvwdqysreaomxkvpaudzgxppjscwne ON public.userpermissions_usergroups USING btree ("permissionId", "groupId");


--
-- Name: idx_nzcxxrleidrbykmmmxyojitmlnyvdmllkjrm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_nzcxxrleidrbykmmmxyojitmlnyvdmllkjrm ON public.fieldlayoutfields USING btree ("fieldId");


--
-- Name: idx_ohohitqsplgrvvnxqpmkeqkanlerzyqmdmep; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ohohitqsplgrvvnxqpmkeqkanlerzyqmdmep ON public.elements_sites USING btree (lower((uri)::text), "siteId");


--
-- Name: idx_okfhoqsdmexbfdjpnyienhcvldmyiugcwufj; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_okfhoqsdmexbfdjpnyienhcvldmyiugcwufj ON public.categories USING btree ("groupId");


--
-- Name: idx_oncgvprxnjsqtlukxkjjmjtyxjgbzegbbege; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oncgvprxnjsqtlukxkjjmjtyxjgbzegbbege ON public.templatecaches USING btree ("cacheKey", "siteId", "expiryDate");


--
-- Name: idx_pbdogcfzlxuqatdceszvaozccnmimkatggjv; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_pbdogcfzlxuqatdceszvaozccnmimkatggjv ON public.elements_sites USING btree ("elementId", "siteId");


--
-- Name: idx_pxqanwqpaumhrfdrsszklgjowutzzxxybwdl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pxqanwqpaumhrfdrsszklgjowutzzxxybwdl ON public.elements_sites USING btree (slug, "siteId");


--
-- Name: idx_pxvqncndpcudahepdsckbbqitlxvlyhrumtg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pxvqncndpcudahepdsckbbqitlxvlyhrumtg ON public.users USING btree (lower((username)::text));


--
-- Name: idx_pzktsgnluceskzrmmrrpkrnisqsdhggxlgiu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pzktsgnluceskzrmmrrpkrnisqsdhggxlgiu ON public.elements USING btree ("fieldLayoutId");


--
-- Name: idx_qglmrbaxvrxfelgjegtdtctvjvdjiubrweum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qglmrbaxvrxfelgjegtdtctvjvdjiubrweum ON public.matrixblocktypes USING btree (handle, "fieldId");


--
-- Name: idx_qilybbcmbtlytzsimlaparxxpjbazknkmtgl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qilybbcmbtlytzsimlaparxxpjbazknkmtgl ON public.matrixblocks USING btree ("typeId");


--
-- Name: idx_qmfjtqnyritieinfbvdabzawjjsmbekltqtl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qmfjtqnyritieinfbvdabzawjjsmbekltqtl ON public.globalsets USING btree ("sortOrder");


--
-- Name: idx_rnmxmoweswyjbrfzcosdtinoviekrhllobem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rnmxmoweswyjbrfzcosdtinoviekrhllobem ON public.categorygroups USING btree ("dateDeleted");


--
-- Name: idx_rwvbnrkbbhqfjvwcmirpiktavsyewpqfbezq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rwvbnrkbbhqfjvwcmirpiktavsyewpqfbezq ON public.globalsets USING btree (handle);


--
-- Name: idx_rzkbyuadbiqnnakdxvikszqasfvudosbiekq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rzkbyuadbiqnnakdxvikszqasfvudosbiekq ON public.elements_sites USING btree ("siteId");


--
-- Name: idx_sfwwrptoytyrkleqfjsaoqeaurbwwfzcwdiy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sfwwrptoytyrkleqfjsaoqeaurbwwfzcwdiy ON public.taggroups USING btree (handle);


--
-- Name: idx_shzasyftbadjwevyzubqwcucqspvlhxhvedp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_shzasyftbadjwevyzubqwcucqspvlhxhvedp ON public.assettransforms USING btree (name);


--
-- Name: idx_slilohfkahojaryfutwvgpjnbwyroetdteoz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_slilohfkahojaryfutwvgpjnbwyroetdteoz ON public.volumes USING btree ("dateDeleted");


--
-- Name: idx_snhjebtbjdxcwjdmcpwwhjndzehwrcuxfbjy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_snhjebtbjdxcwjdmcpwwhjndzehwrcuxfbjy ON public.categorygroups USING btree ("fieldLayoutId");


--
-- Name: idx_ssqttaiaqauuzuluuiypotrmgrwrnilrpvbu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ssqttaiaqauuzuluuiypotrmgrwrnilrpvbu ON public.elements_sites USING btree (enabled);


--
-- Name: idx_tdteebduzzmipyztytpgygmvkjjembmeqkun; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tdteebduzzmipyztytpgygmvkjjembmeqkun ON public.taggroups USING btree (name);


--
-- Name: idx_tdvmjlnduphebhwtioypjxtnjbuefpdtnvci; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tdvmjlnduphebhwtioypjxtnjbuefpdtnvci ON public.changedattributes USING btree ("elementId", "siteId", "dateUpdated");


--
-- Name: idx_tgedkofguqefchmrmoenfgntgoiloyrayfnv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tgedkofguqefchmrmoenfgntgoiloyrayfnv ON public.elements USING btree (enabled);


--
-- Name: idx_tiqggukgcnjxzevjlxzrboibspvadjotdunf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tiqggukgcnjxzevjlxzrboibspvadjotdunf ON public.templatecachequeries USING btree ("cacheId");


--
-- Name: idx_toimpgoukwavcugxvcdiazcnptrxffbxjyol; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_toimpgoukwavcugxvcdiazcnptrxffbxjyol ON public.usergroups_users USING btree ("groupId", "userId");


--
-- Name: idx_tpeotmnlszktiwwsxzdmajfbedhwyxgqjdpe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tpeotmnlszktiwwsxzdmajfbedhwyxgqjdpe ON public.sections USING btree ("structureId");


--
-- Name: idx_trmweyzlkmdhghfeuqxflxbaulymbdljeres; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trmweyzlkmdhghfeuqxflxbaulymbdljeres ON public.matrixblocks USING btree ("fieldId");


--
-- Name: idx_udzevqhgwykahmuprgvnvozxiryrcjzyoooo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_udzevqhgwykahmuprgvnvozxiryrcjzyoooo ON public.matrixblocktypes USING btree ("fieldLayoutId");


--
-- Name: idx_ujmplkrqaoimshrqftfubdmgzrfgnkfajrze; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ujmplkrqaoimshrqftfubdmgzrfgnkfajrze ON public.entries USING btree ("typeId");


--
-- Name: idx_umfvhfcvvdakxmyyonedvgdkafgmootdreid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_umfvhfcvvdakxmyyonedvgdkafgmootdreid ON public.structures USING btree ("dateDeleted");


--
-- Name: idx_umyprmiqvnrisycyxrhaqbnjmivqzcycwaqi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_umyprmiqvnrisycyxrhaqbnjmivqzcycwaqi ON public.userpermissions_users USING btree ("userId");


--
-- Name: idx_unxmctilqwkanjqvnkvfxfhvezuzxkajqjet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unxmctilqwkanjqvnkvfxfhvezuzxkajqjet ON public.fields USING btree ("groupId");


--
-- Name: idx_uomuhedyanuuhiqdgiubgoquhphkmriajbzu; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uomuhedyanuuhiqdgiubgoquhphkmriajbzu ON public.sections_sites USING btree ("siteId");


--
-- Name: idx_usapvhlmwzsjnuljgtbbkkeolmaiwjihhkie; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usapvhlmwzsjnuljgtbbkkeolmaiwjihhkie ON public.announcements USING btree ("userId", unread, "dateRead", "dateCreated");


--
-- Name: idx_uunffbawrcvtfnkzbxgtherwvahsedcwsekx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uunffbawrcvtfnkzbxgtherwvahsedcwsekx ON public.relations USING btree ("sourceSiteId");


--
-- Name: idx_uurgsjjvlgtinhxkcmaxuihocicvisbxsosb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uurgsjjvlgtinhxkcmaxuihocicvisbxsosb ON public.sections USING btree (handle);


--
-- Name: idx_uxyzzjwkukollazkicvfiwdrdyjbuvrlpofl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uxyzzjwkukollazkicvfiwdrdyjbuvrlpofl ON public.usergroups USING btree (name);


--
-- Name: idx_uybmgtwrbyatnvtgvowjryztxdlctovyahww; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uybmgtwrbyatnvtgvowjryztxdlctovyahww ON public.systemmessages USING btree (language);


--
-- Name: idx_uzfbpowhilgcjgzjcvxccpjgaoavduvwvrzd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uzfbpowhilgcjgzjcvxccpjgaoavduvwvrzd ON public.templatecacheelements USING btree ("elementId");


--
-- Name: idx_uzfzfdxdnknkfpdbkrjniegkiurxqqhvovsd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uzfzfdxdnknkfpdbkrjniegkiurxqqhvovsd ON public.searchindex USING btree (keywords);


--
-- Name: idx_vbsjppxjimssvrwkdkyraviysvehjuqbhldn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vbsjppxjimssvrwkdkyraviysvehjuqbhldn ON public.globalsets USING btree (name);


--
-- Name: idx_vbuwbemncjgzwneyvcpinzbbupddtmrnswfc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vbuwbemncjgzwneyvcpinzbbupddtmrnswfc ON public.assettransformindex USING btree ("volumeId", "assetId", location);


--
-- Name: idx_voehxymzaotizojzoxxoeogziilbuaardzel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_voehxymzaotizojzoxxoeogziilbuaardzel ON public.templatecaches USING btree ("siteId");


--
-- Name: idx_vrosdkggvoasnufkijbmtyhckvmaxdjqzqyg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_vrosdkggvoasnufkijbmtyhckvmaxdjqzqyg ON public.revisions USING btree ("sourceId", num);


--
-- Name: idx_vtcodandmiqvisbtexbnxlzfszblrjnzdzjz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vtcodandmiqvisbtexbnxlzfszblrjnzdzjz ON public.fieldlayoutfields USING btree ("tabId");


--
-- Name: idx_wcmmgawmjvoghklvtjhbtjdjamvltbiehsbz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wcmmgawmjvoghklvtjhbtjdjamvltbiehsbz ON public.entrytypes USING btree ("sectionId");


--
-- Name: idx_wmrraimoymibwruhjxzxbdignrkzjhrxgfuc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wmrraimoymibwruhjxzxbdignrkzjhrxgfuc ON public.categorygroups_sites USING btree ("siteId");


--
-- Name: idx_wudtahqpnhfqwmileunxdehzirnvmddioopt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wudtahqpnhfqwmileunxdehzirnvmddioopt ON public.sites USING btree ("dateDeleted");


--
-- Name: idx_wyvykvdlpwbhmndaqruxutgiccmhwwjigjip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wyvykvdlpwbhmndaqruxutgiccmhwwjigjip ON public.fieldgroups USING btree ("dateDeleted", name);


--
-- Name: idx_wzwphqhrgmzviidjrvxiicpunilbcriifgdz; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wzwphqhrgmzviidjrvxiicpunilbcriifgdz ON public.entries USING btree ("sectionId");


--
-- Name: idx_xbbcahcgpxyxgffjohojujdqsuaqugbbarse; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xbbcahcgpxyxgffjohojujdqsuaqugbbarse ON public.migrations USING btree (track, name);


--
-- Name: idx_xirzomftbpjhfecnslsiilfvstfswgareoej; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xirzomftbpjhfecnslsiilfvstfswgareoej ON public.entries USING btree ("postDate");


--
-- Name: idx_xlgfbqwqrlitolfzlmnwsrpeowinbelfgncb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xlgfbqwqrlitolfzlmnwsrpeowinbelfgncb ON public.structureelements USING btree (lft);


--
-- Name: idx_xndzbzwfzdxiyhlqvjottadaomwwpyzxhkig; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xndzbzwfzdxiyhlqvjottadaomwwpyzxhkig ON public.drafts USING btree (saved);


--
-- Name: idx_xojqpuoqcrjedlduenaryioxvskpyobrecex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xojqpuoqcrjedlduenaryioxvskpyobrecex ON public.sites USING btree ("sortOrder");


--
-- Name: idx_xrprccotimoblwfwyemhmqktqvhzlmpfjjnl; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xrprccotimoblwfwyemhmqktqvhzlmpfjjnl ON public.categorygroups USING btree (handle);


--
-- Name: idx_xstwolkzpxbdqrmxuuziwraiisgzhzjaqgyg; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xstwolkzpxbdqrmxuuziwraiisgzhzjaqgyg ON public.userpermissions_users USING btree ("permissionId", "userId");


--
-- Name: idx_xtdqlpnfavznmiauairmgjftpyejngdduijm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xtdqlpnfavznmiauairmgjftpyejngdduijm ON public.fieldlayouttabs USING btree ("sortOrder");


--
-- Name: idx_xyjyprzroemfoyllvmvdqoiijbxthdtvltmc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xyjyprzroemfoyllvmvdqoiijbxthdtvltmc ON public.assetindexdata USING btree ("volumeId");


--
-- Name: idx_xyqscjfqyyuafajwbvwjiwgfmrcunvysgucp; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xyqscjfqyyuafajwbvwjiwgfmrcunvysgucp ON public.structureelements USING btree ("structureId", "elementId");


--
-- Name: idx_xzbrulybudlpgsfqszwtfumwrgdugqsjecjy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_xzbrulybudlpgsfqszwtfumwrgdugqsjecjy ON public.tokens USING btree (token);


--
-- Name: idx_yamkpkbxdtrncvnohpuzgxmtxrdbqurpjmfx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_yamkpkbxdtrncvnohpuzgxmtxrdbqurpjmfx ON public.gatsby_deletedelements USING btree ("elementId", "siteId");


--
-- Name: idx_ydxoopluvdoyyofdqiszzwbezpxdhlgmvqzq; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ydxoopluvdoyyofdqiszzwbezpxdhlgmvqzq ON public.structureelements USING btree ("elementId");


--
-- Name: idx_ykakevfyobvrgycbdqwgiewgrhjztxjnjzyh; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ykakevfyobvrgycbdqwgiewgrhjztxjnjzyh ON public.tags USING btree ("groupId");


--
-- Name: idx_yqntepvveambublqrksqpqxsmvxilrmdfqjp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yqntepvveambublqrksqpqxsmvxilrmdfqjp ON public.categorygroups USING btree (name);


--
-- Name: idx_ytlnjnojfzjkmtvdnuurowellxetzkqjlexv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ytlnjnojfzjkmtvdnuurowellxetzkqjlexv ON public.volumes USING btree (name);


--
-- Name: idx_ywxwhdyrmyknlblslokhyldhcyzlwrmarmle; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ywxwhdyrmyknlblslokhyldhcyzlwrmarmle ON public.userpermissions USING btree (name);


--
-- Name: idx_yyhkcpjhwonhkpvdoicpygicnyxtexhfrnmp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_yyhkcpjhwonhkpvdoicpygicnyxtexhfrnmp ON public.queue USING btree (channel, fail, "timeUpdated", "timePushed");


--
-- Name: idx_zqadmxtwxlzrwahqgkclwxvqrqhantxwqvax; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_zqadmxtwxlzrwahqgkclwxvqrqhantxwqvax ON public.volumefolders USING btree ("volumeId");


--
-- Name: templatecacheelements fk_acxaxfxcjexqtjjlqjmioqezznvewzuqlpie; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT fk_acxaxfxcjexqtjjlqjmioqezznvewzuqlpie FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: categorygroups_sites fk_agbiywalnzxvrrkcwgkmvjzsmzhurjpzzgfu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_agbiywalnzxvrrkcwgkmvjzsmzhurjpzzgfu FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assets fk_akouzaohvrzqpqgrvfcpnicypybtjfqmogho; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_akouzaohvrzqpqgrvfcpnicypybtjfqmogho FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: announcements fk_aqmxuaqdnpqimrscvsxvmcbyizuuczhxudzt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT fk_aqmxuaqdnpqimrscvsxvmcbyizuuczhxudzt FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: relations fk_aupfoqlwgvqamhpurhvdcsjxankhocowumeu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_aupfoqlwgvqamhpurhvdcsjxankhocowumeu FOREIGN KEY ("targetId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: entries fk_bmgvjpjtnlquiaoelnjkvnbudenuqkikvkgw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_bmgvjpjtnlquiaoelnjkvnbudenuqkikvkgw FOREIGN KEY ("authorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: usergroups_users fk_bqpwrdpiyxkczswqmdozzobppbplxlzhkcis; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_bqpwrdpiyxkczswqmdozzobppbplxlzhkcis FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: volumefolders fk_ciuscxxowyxxrlmegebzlpgbgxmilwvoaghz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_ciuscxxowyxxrlmegebzlpgbgxmilwvoaghz FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: assets fk_cjmymlkzyrgymygzxobesfrsvrkamgaelhqr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_cjmymlkzyrgymygzxobesfrsvrkamgaelhqr FOREIGN KEY ("uploaderId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: matrixblocks fk_cklazsukyavnwlommqgjwvopeweiqrtoxxrt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_cklazsukyavnwlommqgjwvopeweiqrtoxxrt FOREIGN KEY ("typeId") REFERENCES public.matrixblocktypes(id) ON DELETE CASCADE;


--
-- Name: elements_sites fk_dckbwthohmaoegcgukalfcoihqmlpfkusmgg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_dckbwthohmaoegcgukalfcoihqmlpfkusmgg FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gqltokens fk_dinqaqcuwxnxqgkxrvisnogmczgwnjmssfbh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gqltokens
    ADD CONSTRAINT fk_dinqaqcuwxnxqgkxrvisnogmczgwnjmssfbh FOREIGN KEY ("schemaId") REFERENCES public.gqlschemas(id) ON DELETE SET NULL;


--
-- Name: revisions fk_drvumycnkerapzddxgecojmxzmbwgdzvpykn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_drvumycnkerapzddxgecojmxzmbwgdzvpykn FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements fk_dtpqozepdpwgwmhnhjqvflmvcybugcajmhpz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_dtpqozepdpwgwmhnhjqvflmvcybugcajmhpz FOREIGN KEY ("draftId") REFERENCES public.drafts(id) ON DELETE CASCADE;


--
-- Name: entries fk_dvjplsnmokhjwrsdnuzgwesirubuhrcqnpxq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_dvjplsnmokhjwrsdnuzgwesirubuhrcqnpxq FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements fk_eakuvzxchuuizmcnrsexgmizzvmbrueunaii; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_eakuvzxchuuizmcnrsexgmizzvmbrueunaii FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: revisions fk_eauzwwyfbiufjgihuvesygiggiglkyudypnp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.revisions
    ADD CONSTRAINT fk_eauzwwyfbiufjgihuvesygiggiglkyudypnp FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: changedfields fk_ejdhpplhwrbcesjmymdioewfedmgmvobxccj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_ejdhpplhwrbcesjmymdioewfedmgmvobxccj FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matrixblocks fk_ffyxmtwbhynjfinrmhtzpipgywipdrnjkzsi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_ffyxmtwbhynjfinrmhtzpipgywipdrnjkzsi FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: craftidtokens fk_fnujdicqutvwpcgbjxgcgwswcyldckwbfdnq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.craftidtokens
    ADD CONSTRAINT fk_fnujdicqutvwpcgbjxgcgwswcyldckwbfdnq FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: entrytypes fk_ftlmhdvefpjntamiwgikkmmkddkwonxoxccw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_ftlmhdvefpjntamiwgikkmmkddkwonxoxccw FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: relations fk_gevyffdvstntnbrzspcmajwxsckosufgwdog; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_gevyffdvstntnbrzspcmajwxsckosufgwdog FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: changedattributes fk_hsgednwmaycmgfsrievnpdihpfsevebebfjp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_hsgednwmaycmgfsrievnpdihpfsevebebfjp FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: drafts fk_hsorrkdacyfdyxqjniiotqotqvzgwumppkxy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_hsorrkdacyfdyxqjniiotqotqvzgwumppkxy FOREIGN KEY ("creatorId") REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: structureelements fk_ihddupgmwdnrjcbqoonifablkinnxzklxgyw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_ihddupgmwdnrjcbqoonifablkinnxzklxgyw FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: changedattributes fk_ihfcnwawoqjzaijqgztewgqwywaoyalwpifd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_ihfcnwawoqjzaijqgztewgqwywaoyalwpifd FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: structureelements fk_ihffzyarvylcdxjqtztsbocxiiocuptndpit; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.structureelements
    ADD CONSTRAINT fk_ihffzyarvylcdxjqtztsbocxiiocuptndpit FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: announcements fk_ijljjnfztrnlsxttpvmzxobhgpbimsmltqjh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT fk_ijljjnfztrnlsxttpvmzxobhgpbimsmltqjh FOREIGN KEY ("pluginId") REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: fields fk_irykroikqevghkdfgurvfznkuunkauoqckak; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fk_irykroikqevghkdfgurvfznkuunkauoqckak FOREIGN KEY ("groupId") REFERENCES public.fieldgroups(id) ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_jpcmtvjjpkdrafzehyygtdpgdwmbfxvedoni; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_jpcmtvjjpkdrafzehyygtdpgdwmbfxvedoni FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_juqebdmscimmiogexdqfqrlfjjnewabokejn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_juqebdmscimmiogexdqfqrlfjjnewabokejn FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: globalsets fk_kyxvjybqatiboxovylyccwwdgtpadjffbnxa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_kyxvjybqatiboxovylyccwwdgtpadjffbnxa FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: sections_sites fk_lmwtlwlesouzqwxduvqdpnnsuhhmpntflejd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_lmwtlwlesouzqwxduvqdpnnsuhhmpntflejd FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: userpermissions_usergroups fk_luuuohfvmninboviwxbaxigfsjphnehtktdg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_luuuohfvmninboviwxbaxigfsjphnehtktdg FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: relations fk_lykkzcggrzxkebcubncsghvidodtnfihoers; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_lykkzcggrzxkebcubncsghvidodtnfihoers FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: userpermissions_users fk_mbrpcdjyixpjaclqtacfxgapapganijfvihb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_mbrpcdjyixpjaclqtacfxgapapganijfvihb FOREIGN KEY ("permissionId") REFERENCES public.userpermissions(id) ON DELETE CASCADE;


--
-- Name: sections_sites fk_mjmihenbuiplvjnjbkkjbnehsfoowgdbmrix; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections_sites
    ADD CONSTRAINT fk_mjmihenbuiplvjnjbkkjbnehsfoowgdbmrix FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categorygroups_sites fk_mvgvnxgvxxwgblfwrwauyvzoicmiodtgmrak; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups_sites
    ADD CONSTRAINT fk_mvgvnxgvxxwgblfwrwauyvzoicmiodtgmrak FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: volumes fk_ngkwaoeabestgpagxvtoyrlhpvlbkqncljca; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumes
    ADD CONSTRAINT fk_ngkwaoeabestgpagxvtoyrlhpvlbkqncljca FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: content fk_nidumidsiewxyyvfeffxiysufknpidxmyaiy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_nidumidsiewxyyvfeffxiysufknpidxmyaiy FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: templatecacheelements fk_njwqhymentkgvlkbbhzaionwizykpnlbepiq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecacheelements
    ADD CONSTRAINT fk_njwqhymentkgvlkbbhzaionwizykpnlbepiq FOREIGN KEY ("cacheId") REFERENCES public.templatecaches(id) ON DELETE CASCADE;


--
-- Name: userpermissions_users fk_nvdotwjasidwkjpaectcqnpkuuuselhwcyqa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_users
    ADD CONSTRAINT fk_nvdotwjasidwkjpaectcqnpkuuuselhwcyqa FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_nxjvvnrctnaddmmjbhlvrjcbjzzsrvrrmkek; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_nxjvvnrctnaddmmjbhlvrjcbjzzsrvrrmkek FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: elements fk_okiwlyljoydzqfiopxvngyeqjbxghcacxcrk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_okiwlyljoydzqfiopxvngyeqjbxghcacxcrk FOREIGN KEY ("canonicalId") REFERENCES public.elements(id) ON DELETE SET NULL;


--
-- Name: entries fk_ozzvxvqatugjglpimzlafgflpakcgashswjn; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_ozzvxvqatugjglpimzlafgflpakcgashswjn FOREIGN KEY ("sectionId") REFERENCES public.sections(id) ON DELETE CASCADE;


--
-- Name: fieldlayoutfields fk_paboxjelhgvqweoyxdozedjapmtccjiiidge; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayoutfields
    ADD CONSTRAINT fk_paboxjelhgvqweoyxdozedjapmtccjiiidge FOREIGN KEY ("tabId") REFERENCES public.fieldlayouttabs(id) ON DELETE CASCADE;


--
-- Name: templatecachequeries fk_pbyhvxitbspbjzopgznzkineutulhhqrwrlg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecachequeries
    ADD CONSTRAINT fk_pbyhvxitbspbjzopgznzkineutulhhqrwrlg FOREIGN KEY ("cacheId") REFERENCES public.templatecaches(id) ON DELETE CASCADE;


--
-- Name: sites fk_pmcnfhddlfacarmsefpsmmqtnmbjrfahwyoq; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT fk_pmcnfhddlfacarmsefpsmmqtnmbjrfahwyoq FOREIGN KEY ("groupId") REFERENCES public.sitegroups(id) ON DELETE CASCADE;


--
-- Name: categories fk_pwslbpmqxenyjfumtcyygpohjrgzltnzvgsv; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_pwslbpmqxenyjfumtcyygpohjrgzltnzvgsv FOREIGN KEY ("groupId") REFERENCES public.categorygroups(id) ON DELETE CASCADE;


--
-- Name: users fk_qaufqqbzvcihylotynbhaklkkxcvqgxcexeb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_qaufqqbzvcihylotynbhaklkkxcvqgxcexeb FOREIGN KEY ("photoId") REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: sections fk_qjnmqaoysnsclstuelzmnfqgjllftubspnqh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sections
    ADD CONSTRAINT fk_qjnmqaoysnsclstuelzmnfqgjllftubspnqh FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE SET NULL;


--
-- Name: categorygroups fk_quleicrlgcrlsppiwiwmnnjujchundmjdzds; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_quleicrlgcrlsppiwiwmnnjujchundmjdzds FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: taggroups fk_rfbvlyvomaomvcrkunqrlujnutydirvfkexw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggroups
    ADD CONSTRAINT fk_rfbvlyvomaomvcrkunqrlujnutydirvfkexw FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: changedfields fk_rgzsifmejgakkmwhqnljdgsltjnayvbyfxnp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_rgzsifmejgakkmwhqnljdgsltjnayvbyfxnp FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: relations fk_rxwsgrrabqauobtniihhfdtvhokpeopieczb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT fk_rxwsgrrabqauobtniihhfdtvhokpeopieczb FOREIGN KEY ("sourceSiteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: changedattributes fk_sargbrtjmttpatxcahawzpyfbjnclzyucyjd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedattributes
    ADD CONSTRAINT fk_sargbrtjmttpatxcahawzpyfbjnclzyucyjd FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: matrixblocktypes fk_skpmedomozgqqizdjspcbldhqbiodqfieugp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_skpmedomozgqqizdjspcbldhqbiodqfieugp FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: shunnedmessages fk_srfgiddvjymfbflxftbpgepmzjhsvkefwjrw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shunnedmessages
    ADD CONSTRAINT fk_srfgiddvjymfbflxftbpgepmzjhsvkefwjrw FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: changedfields fk_stksspvxpvtooinomkyhkvmoygjynlakruhr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changedfields
    ADD CONSTRAINT fk_stksspvxpvtooinomkyhkvmoygjynlakruhr FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: categories fk_svwysmmpuvvugselvlkudekgkerplhntdhpw; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_svwysmmpuvvugselvlkudekgkerplhntdhpw FOREIGN KEY ("parentId") REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: tags fk_tcnurdcjhddlewwhqewitguptqtgkhnnvtxd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_tcnurdcjhddlewwhqewitguptqtgkhnnvtxd FOREIGN KEY ("groupId") REFERENCES public.taggroups(id) ON DELETE CASCADE;


--
-- Name: users fk_tramutmeimtjhtvokwfitjdlchnjfsuamops; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_tramutmeimtjhtvokwfitjdlchnjfsuamops FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: elements fk_uldjwarpoccvkhhynbzwjnzudetualfjiakp; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements
    ADD CONSTRAINT fk_uldjwarpoccvkhhynbzwjnzudetualfjiakp FOREIGN KEY ("revisionId") REFERENCES public.revisions(id) ON DELETE CASCADE;


--
-- Name: categorygroups fk_umlfohxobvrqetcbiimtagbcnfhgdfugkhgs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categorygroups
    ADD CONSTRAINT fk_umlfohxobvrqetcbiimtagbcnfhgdfugkhgs FOREIGN KEY ("structureId") REFERENCES public.structures(id) ON DELETE CASCADE;


--
-- Name: drafts fk_unfrhsspkbbsngfghhmaajrekexiozxlxbss; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drafts
    ADD CONSTRAINT fk_unfrhsspkbbsngfghhmaajrekexiozxlxbss FOREIGN KEY ("sourceId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: userpermissions_usergroups fk_urbngthzeficfsichcfrxidjcewvnmwhhvdm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpermissions_usergroups
    ADD CONSTRAINT fk_urbngthzeficfsichcfrxidjcewvnmwhhvdm FOREIGN KEY ("groupId") REFERENCES public.usergroups(id) ON DELETE CASCADE;


--
-- Name: usergroups_users fk_vgmhbqsuhfcoucvxojvdhnhozazeasdbjter; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usergroups_users
    ADD CONSTRAINT fk_vgmhbqsuhfcoucvxojvdhnhozazeasdbjter FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fieldlayouttabs fk_vihzqihjzqguuzicqsrugfixmhghuojxwfmg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fieldlayouttabs
    ADD CONSTRAINT fk_vihzqihjzqguuzicqsrugfixmhghuojxwfmg FOREIGN KEY ("layoutId") REFERENCES public.fieldlayouts(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_whklxdrrduxsufxpotuabyssnlmiohozdcsh; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_whklxdrrduxsufxpotuabyssnlmiohozdcsh FOREIGN KEY ("fieldId") REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: entries fk_whnvgusapbazwmetxsbzuusbvnckqjiwijjx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_whnvgusapbazwmetxsbzuusbvnckqjiwijjx FOREIGN KEY ("typeId") REFERENCES public.entrytypes(id) ON DELETE CASCADE;


--
-- Name: entries fk_whodbooinwmvqcegyryqhssncurxmndljafe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT fk_whodbooinwmvqcegyryqhssncurxmndljafe FOREIGN KEY ("parentId") REFERENCES public.entries(id) ON DELETE SET NULL;


--
-- Name: tags fk_xatrztzvcsjhjiwgiojkeqywzhrotxeijody; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_xatrztzvcsjhjiwgiojkeqywzhrotxeijody FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: templatecaches fk_xfetygmslslakvhthfwvyhnycdpkskqopogk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.templatecaches
    ADD CONSTRAINT fk_xfetygmslslakvhthfwvyhnycdpkskqopogk FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions fk_xuekehbkpnykgsylpklrhgpobsjeghxlripr; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT fk_xuekehbkpnykgsylpklrhgpobsjeghxlripr FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assetindexdata fk_yadqfkcdthefjducjecxxknixwxagdvdqmuz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assetindexdata
    ADD CONSTRAINT fk_yadqfkcdthefjducjecxxknixwxagdvdqmuz FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: assets fk_yetyuoopmmtpogsgsopvhpynmprvglgjdcns; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_yetyuoopmmtpogsgsopvhpynmprvglgjdcns FOREIGN KEY ("folderId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: matrixblocktypes fk_ygvywmvffkcptcuyjubzwsbbrvwqzglravjy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocktypes
    ADD CONSTRAINT fk_ygvywmvffkcptcuyjubzwsbbrvwqzglravjy FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: volumefolders fk_ypltwezcmgpftiaucxucgwduhonidsbfpddt; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volumefolders
    ADD CONSTRAINT fk_ypltwezcmgpftiaucxucgwduhonidsbfpddt FOREIGN KEY ("parentId") REFERENCES public.volumefolders(id) ON DELETE CASCADE;


--
-- Name: entrytypes fk_yurtmdkdpzsxmrfnsewpfoqvevmrrfucjyby; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entrytypes
    ADD CONSTRAINT fk_yurtmdkdpzsxmrfnsewpfoqvevmrrfucjyby FOREIGN KEY ("fieldLayoutId") REFERENCES public.fieldlayouts(id) ON DELETE SET NULL;


--
-- Name: elements_sites fk_yvbhlotpisehkijlewmisogugfqkbagooooi; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.elements_sites
    ADD CONSTRAINT fk_yvbhlotpisehkijlewmisogugfqkbagooooi FOREIGN KEY ("elementId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: userpreferences fk_yvkiysdtrpvpxkgibcxlafydeappyponaxkz; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.userpreferences
    ADD CONSTRAINT fk_yvkiysdtrpvpxkgibcxlafydeappyponaxkz FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: content fk_zaefdgalobzpbsmmbjzysolznozbtayoevsg; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content
    ADD CONSTRAINT fk_zaefdgalobzpbsmmbjzysolznozbtayoevsg FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: widgets fk_zmmqyeabxgvybmfcrcdhaarefagxmlfouhnj; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.widgets
    ADD CONSTRAINT fk_zmmqyeabxgvybmfcrcdhaarefagxmlfouhnj FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories fk_zmvnnomsrnoettgcgcidszpjslyvvjtcdhrs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT fk_zmvnnomsrnoettgcgcidszpjslyvvjtcdhrs FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: assets fk_zotjryttfurumkbpkztsxjsvnerofxnxyujx; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_zotjryttfurumkbpkztsxjsvnerofxnxyujx FOREIGN KEY ("volumeId") REFERENCES public.volumes(id) ON DELETE CASCADE;


--
-- Name: matrixblocks fk_zqqeoerktxwqmsjuaatpooqoefbyknscjaaf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matrixblocks
    ADD CONSTRAINT fk_zqqeoerktxwqmsjuaatpooqoefbyknscjaaf FOREIGN KEY ("ownerId") REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- Name: globalsets fk_zvynuobptdmklsesnpixggbolodvnkuqgvut; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.globalsets
    ADD CONSTRAINT fk_zvynuobptdmklsesnpixggbolodvnkuqgvut FOREIGN KEY (id) REFERENCES public.elements(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

